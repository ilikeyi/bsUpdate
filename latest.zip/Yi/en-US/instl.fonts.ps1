# Please set the directory to be searched
$DirectoryStructure = @(
    "Yi\Fonts"
    "Fonts"
)

# Please set the search file type
$type = @(
    "*.otf"
    "*.ttf"
)

#region functions
function Install-Fonts {
    param (
        [string]$fontFile,
        [string]$shortname
    )
    
    if ((Test-Path "$env:SystemDrive\Windows\fonts\$shortname") -or 
        (Test-Path "$env:LOCALAPPDATA\Microsoft\Windows\Fonts\$shortname")) {
        Write-Host "   'Installed'  - $($fontFile)" -ForegroundColor Red
    } else {
        Write-Host "   'installing' - $($fontFile)" -ForegroundColor Green

        (New-Object -ComObject Shell.Application).Namespace(0x14).CopyHere($_.FullName) | Out-Null
        Write-Host "    - complete.`n" -ForegroundColor Green
    }
}
#endregion

Write-host "`n   Installing Fonts
   ---------------------------------------------------"

# install fonts
$drives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[a-z]$'
foreach ($drive in $drives){
    foreach ($nsf in $DirectoryStructure) {
        Get-ChildItem "${drive}:\${nsf}" -Recurse -Include ($type) -ErrorAction SilentlyContinue | Foreach-Object {
            Install-Fonts -fontFile $_.FullName -shortname $_.Name
        }
    }
}