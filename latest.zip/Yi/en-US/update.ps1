[CmdletBinding()]
param(
	[parameter(Mandatory = $false, HelpMessage = "Forced, no need to ask")]
	[Switch]$Force
)

# The version of this Auto Updater
$auver = "5.1.0.1"

Write-host "
   Author: Yi ( https://fengyi.tel )

   From: Yi's Solution
   buildstring: 5.1.0.1.bk_release.210120-1208

   ver: $($auver)
"

# Please set the Server List
# Configuration: domain name + structure
$ServerList = @(
    ('https://fengyi.tel',
     '/download/bk/v5/latest.xml' ),
    ('https://github.com',
     '/ilikeyi/Update/raw/main/latest.xml' ),
    ('https://gitee.com',
     '/ilikeyi/bk.update/raw/master/latest.xml' )
)

function Test-URI {
    Param(
        [Parameter(Position=0,Mandatory,HelpMessage="HTTP or HTTPS")]
        [ValidatePattern( "^(http|https)://" )]
        [Alias("url")]
        [string]$URI,
        [Parameter(ParameterSetName="Detail")]
        [Switch]$Detail,
        [ValidateScript({$_ -ge 0})]
        [int]$Timeout = 30
    )
    Process {
        Try {
            $paramHash = @{
                UseBasicParsing = $True
                DisableKeepAlive = $True
                Uri = $uri
                Method = 'Head'
                ErrorAction = 'stop'
                TimeoutSec = $Timeout
            }
            $test = Invoke-WebRequest @paramHash
            if ($Detail) {
                $test.BaseResponse | Select ResponseURI,ContentLength,ContentType,LastModified, @{Name="Status";Expression={$Test.StatusCode}}
            } else {
                if ($test.statuscode -ne 200) { $False } else { $True }
            }
        } Catch {
            write-verbose -message $_.exception
            if ($Detail) {
                $objProp = [ordered]@{
                    ResponseURI = $uri
                    ContentLength = $null
                    ContentType = $null
                    LastModified = $null
                    Status = 404
                }
                New-Object -TypeName psobject -Property $objProp
            } else { $False }
        }
    }
}

$ServerTest = $false

Write-host "   Test whether the linked server is available...
   ---------------------------------------------------"

foreach ($list in $ServerList | Sort-Object { Get-Random } ) {
    $fullurl = $list[0] + $list[1]

    Write-Host "   * Testing ( $($list[0]) )"

    if(test-uri $fullurl){
        $versionxmlloc = $fullurl
        $ServerTest = $true
        Write-Host "     - Available: $($list[0])" -ForegroundColor Green
        break
    } else {
        Write-Host "     - Unavailable: $($list[0])`n" -ForegroundColor Red
    }
}

if ($ServerTest) {
    Write-Host "     - Server test passed..." -ForegroundColor Green
} else {
    Write-Host "     - Failed server test...
   ---------------------------------------------------" -ForegroundColor Red
    If ($Force) {
	    exit
    } else {
	    Wait-Exit -wait 2
    }
}

# Location of current version xml
$x = Split-Path -Parent $MyInvocation.MyCommand.Definition
cd $x
$locver = "..\version.xml"

function Get-Zip {
    # 7zip
    $script:Zip = "default"

	if (Test-Path "$env:ProgramFiles\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles\7-Zip\7z.exe"
		return
	}

	if (Test-Path "$env:ProgramFiles(x86)\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles(x86)\7-Zip\7z.exe"
		return
	}

	if (Test-Path "$env:SystemDrive\Yi\Yi\AIO\7z.exe") {
		$script:Zip = "$env:SystemDrive\Yi\Yi\AIO\7z.exe"
		return
	}
	$script:Zip = "No"
}

Get-Zip

Write-host "`n   Querying for update..."

if (-not (Test-Path $locver)) {
	Write-host "`n   The local version of the version.xml file was not found,
   Check update has been aborted.`n"

	If ($Force) {
		return
	} else {
		Wait-Exit -wait 6
	}
}

# Check if remote version xml is available to the client
$error.Clear()
$time = Measure-Command { $request = Invoke-WebRequest -Uri $versionxmlloc } 2>$null

if ($error.Count -eq 0) {
	Write-host "`n   Checking if the latest version is available,
   time-consuming connection $($time.TotalMilliseconds) millisecond."
} else {
	Write-host "`n   Unable to connect to the remote server.
   Check update has been aborted.`n"

	If ($Force) {
		return
	} else {
		Wait-Exit -wait 6
	}
}

# Load both version xmls
[xml]$curver = Get-content $locver
$wc = New-Object System.Net.WebClient
$wc.Encoding = [System.Text.Encoding]::utf8
[xml]$remotever = $wc.DownloadString($versionxmlloc)

$counter = 0
$IsCorrectAuVer = $false
foreach ($num in $remotever.versioninfo.version.minau.Split('.')) {
	if ($auver.Split('.')[$counter] -ge $num) {
		$IsCorrectAuVer = $true
	} else {
		$IsCorrectAuVer = $false
		break
	}
	$counter++
}

# This block will be executed when the minimum automatic update program version requirements are met.
if ($IsCorrectAuVer) {
	Write-host "`n   Meet the minimum update program version requirements,
   Minimum required version: $($curver.versioninfo.version.minau)"
	$counter = 0
	$IsUpdateAvailable = $false
	foreach ($num in $remotever.versioninfo.version.version.Split('.')) {
		if ($curver.versioninfo.version.version.Split('.')[$counter] -ge $num) {
			$IsUpdateAvailable = $false
		} else {
			$IsUpdateAvailable = $true
			break
		}
		$counter++
	}
	if ($IsUpdateAvailable) {
		Write-host "
   Found a new version available!
		
   Currently used version:   $($curver.versioninfo.version.version) - $($curver.versioninfo.version.buildstring)
   Latest version available: $($remotever.versioninfo.version.version) - $($remotever.versioninfo.version.buildstring)

   $($remotever.versioninfo.changelog.title)
   $('=' * ($remotever.versioninfo.changelog.title).Length)
$($remotever.versioninfo.changelog.'#text')"
		If ($Force) {
			$title = "   The update is being forced."
			Write-host ""
			$url = $remotever.versioninfo.download.url
			$output = "$env:SystemDrive\Yi\Yi\latest.zip"
			$start_time = Get-Date
			if ((Test-Path $output)) { remove-item -path $output -force }
			Import-Module BitsTransfer
			Start-BitsTransfer -Source $url -Destination $output
			Write-Output "   Time used: $((Get-Date).Subtract($start_time).Seconds) second(s)"
			if ((Test-Path $output -PathType Leaf)) {
				Write-host "`n   Unpacking: $output"
				$arguments = "x ""$output"" ""-o$env:SystemDrive\Yi"" -r -y";
				if ((Test-Path "$Zip" -PathType Leaf)) {
					Write-host "   Use $Zip decompression software"
					Start-Process $Zip "$arguments" -Wait -WindowStyle Minimized
				} else {
					Write-host "   Use the system's own decompression software"
					Expand-Archive -LiteralPath $output -DestinationPath "$env:SystemDrive\Yi" -force
				}
				$PPocess = "..\Post.Processing.bat"
				if ((Test-Path $PPocess -PathType Leaf)) {
					Write-host "`n   Post-processing is in progress:"
					Start-Process -FilePath $PPocess -wait -WindowStyle Minimized
					remove-item -path $PPocess -force
					Write-host "   - Finish..."
				}

				Write-host "`n   Yi's Bundled solution Successfully updated!`n"
				if ((Test-Path $output)) {
					remove-item -path $output -force
				} else {
					Write-host "`n   An error occurred while downloading the update,
   The update process is aborted."
				}
			}
		} else {
			$title = "Do you want to install this update ?"
			$message = "Yes, the above update will be installed,`notherwise, the update will not be installed."
			$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Yes"
			$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "No"
			$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
			$choice=$host.ui.PromptForChoice($title, $message, $options, 0)
			if ($choice -eq 0) {
				Write-host ""
				$url = $remotever.versioninfo.download.url
				$output = "$env:SystemDrive\Yi\Yi\latest.zip"
				$start_time = Get-Date
				if ((Test-Path $output)) { remove-item -path $output -force }
				Import-Module BitsTransfer
				Start-BitsTransfer -Source $url -Destination $output
				Write-Output "   Time used: $((Get-Date).Subtract($start_time).Seconds) second(s)"
				if ((Test-Path $output -PathType Leaf)) {
					Write-Output "`n   Unpacking: $output"
					$arguments = "x ""$output"" ""-o$env:SystemDrive\Yi"" -r -y";
					if ((Test-Path "$Zip" -PathType Leaf)) {
						Write-Output "   Use $Zip decompression software"
						Start-Process $Zip "$arguments" -Wait -WindowStyle Minimized
					} else {
						Write-Output "   Use the system's own decompression software"
						Expand-Archive -LiteralPath $output -DestinationPath "$env:SystemDrive\Yi" -force
					}
					$PPocess = "..\Post.Processing.bat"
					if ((Test-Path $PPocess -PathType Leaf)) {
						Write-Output "`n   Post-processing is in progress:"
						Start-Process -FilePath $PPocess -wait -WindowStyle Minimized 
						remove-item -path $PPocess -force
						Write-Output "   Finish post processing..."
					}
					Write-host "`n   Yi's Bundled solution Successfully updated!`n"
					if ((Test-Path $output)) { remove-item -path $output -force }
				} else {
					Write-host "`n   An error occurred while downloading the update,
   The update process is aborted."
				}
			}
		}
	} else {
		Write-host "`n   No update available.

   You are running the latest available version of Yi's Bundled solution."
	}
} else {
	Write-host "`n   Does not meet the minimum update program version requirements,

   Minimum required version: $($curver.versioninfo.version.minau)

   Please re-download a copy of Yi's Bundled solution to update this tool.

   Check update has been aborted."
}

function Wait-Exit {
    param(
        [int]$wait
    )
    Write-Host "`n   Tip: The installation script will automatically exit after $wait seconds..." -ForegroundColor Red
    Start-Sleep -s $wait
    exit
}

If ($Force) {
	return
} else {
	Wait-Exit -wait 6
}