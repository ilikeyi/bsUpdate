# ������Ҫ������Ŀ¼
$DirectoryStructure = @(
    "Yi\Fonts"
    "Fonts"
)

# �����������ļ�����
$type = @(
    "*.otf"
    "*.ttf"
)

#region functions
function Install-Fonts {
    param (
        [string]$fontFile,
        [string]$shortname
    )
    
    if ((Test-Path "$env:SystemDrive\Windows\fonts\$shortname") -or 
        (Test-Path "$env:LOCALAPPDATA\Microsoft\Windows\Fonts\$shortname")) {
        Write-Host "   '�Ѱ�װ' - $($fontFile)" -ForegroundColor Red
    } else {
        Write-Host "   '��װ��' - $($fontFile)" -ForegroundColor Green
        
        (New-Object -ComObject Shell.Application).Namespace(0x14).CopyHere($_.FullName) | Out-Null
        Write-Host "    - ���.`n" -ForegroundColor Green
    }
}
#endregion

Write-host "`n   ���ڰ�װ����
   ---------------------------------------------------"

# install fonts
$drives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[A-z]$'
foreach ($drive in $drives){
    foreach ($nsf in $DirectoryStructure) {
        Get-ChildItem "${drive}:\${nsf}" -Recurse -Include ($type) -ErrorAction SilentlyContinue | Foreach-Object {
            Install-Fonts -fontFile $_.FullName -shortname $_.Name
        }
    }
}