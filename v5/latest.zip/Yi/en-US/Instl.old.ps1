﻿#
#    Warning: In order to prevent overwriting after updating, please save as and then modify.
#
#    You are welcome to install the software using PowerShell
#
#    The main function:
#      1. The installation package does not exist locally, activate the download;
#      2. You can specify the drive letter of the software package, if not specified, search in the order of [d-z],
#         Only the available disks are searched, and the default current system disk is not searched;
#      3. Search file name supports fuzzy search, wildcard *;
#      4. Support decompression package processing, etc.
#
#    Prerequisites:
#      - PowerShell 5.1 Or higher
#
#    Source code:
#    https://github.com/ilikeyi/powershell.install.software
#    https://gitee.com/ilikeyi/powershell.install.software
#

# Get script parameters ( if any )
[CmdletBinding()]
param(
	[parameter(Mandatory = $false, HelpMessage = "Silent")]
	[Switch]$Force
)

# All software configurations
$app = @(
	("Nvidia GEFORCE GAME READY DRIVER",                  # Package name
	 "Disable",                                           # Status: Enable = enabled, Disable = disabled
	 "Install",                                           # Action: Install = install, NoInst = do not install after download, Unzip = only compress after download
	 "wait",                                              # Operating mode: Wait = wait for the end of the run, Fast = run directly
	 "exe",                                               # File type: exe, zip, bat, ps1
	 "auto",                                              # Drive letter: Auto = full disk search, A-Z = designated drive letter or custom path
	 "Yi\Software package\Drive",                         # Directory structure, for example: change AUTO to C, merge result: C:\Yi\Software package\Drive
	 "*-desktop-win10-*-international-dch-whql",          # Match file name, support fuzzy function (*)
	 "460.89-desktop-win10-64bit-international-dch-whql", # The absolute file name of the website download, please do not fill in the suffix
	 "https://us.download.nvidia.cn/Windows/460.89/",     # Site path prefix, ending with /
	 "-s -clean -noreboot -noeula"),                      # Operating parameters
	("VisualCppRedist AIO",
	 "Disable",
	 "Install",
	 "wait",
	 "zip",
	 "auto",
	 "Yi\Software package\AIO",
	 "VisualCppRedist_AIO_x86_x64",
	 "VisualCppRedist_AIO_x86_x64_43",
	 "https://github.com/abbodi1406/vcredist/releases/download/v0.43.0/",
	 "/y"),
	("Gpg4win",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\AIO",
	 "gpg4win-*",
	 "gpg4win-3.1.15",
	 "https://files.gpg4win.org/",
	 "/S"),
	("Python",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\AIO",
	 "python-*",
	 "python-3.9.1-amd64",
	 "https://www.python.org/ftp/python/3.9.1/",
	 "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0"),
	("kugou music",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\Music",
	 "kugou*",
	 "kugou9175",
	 "https://downmini.yun.kugou.com/web",
	 "/S"),
	("NetEase Cloud Music",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\Music",
	 "cloudmusicsetup*",
	 "cloudmusicsetup2.7.5.198554",
	 "https://d1.music.126.net/dmusic/",
	 "/S"),
	("QQ music",
	 "Disable",
	 "Install",
	 "fast",
	 "exe",
	 "auto",
	 "Yi\Software package\Music",
	 "QQMusicSetup",
	 "QQMusicSetup",
	 "https://dldir1.qq.com/music/clntupate/",
	 "/S"),
	("Tencent QQ 2020",
	 "Enable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\social",
	 "PCQQ2020",
	 "PCQQ2020",
	 "https://down.qq.com/qqweb/PCQQ/PCQQ_EXE/",
	 "/S"),
	("WeChat",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\social",
	 "WeChatSetup",
	 "WeChatSetup",
	 "https://dldir1.qq.com/weixin/Windows/",
	 "/S")
)

function Test-Disk {
	param (
		[string]$Path
	)
	$test_tmp_filename = "writetest-"+[guid]::NewGuid()
	$test_filename = $Path + ":\" + $test_tmp_filename
	try {
		[io.file]::OpenWrite($test_filename).close()

		if ((Test-Path -Path $test_filename)) {
			Remove-Item $test_filename -ErrorAction SilentlyContinue
			return $true
		}
		$false
	} catch {
		return $false
	}
}

function Get-Version {
	param(
		$appname,
		$status,
		$act,
		$pp,
		$types,
		$todisk,
		$structure,
		$filename,
		$packer,
		$url,
		$param
	)

	Switch ($status)
	{
		Enable {
			Write-Host "   'Installing'   - $($appname)" -ForegroundColor Green
		}
		Disable {
			Write-Host "   'Skip install' - $($appname)" -ForegroundColor Red
			return
		}
	}

	$url = $url + $packer + "." + $types

	switch -regex ($todisk)
	{
		"auto" { break }
		"^[a-z]$" { break }
		default {
			$todisk = "auto"
		}
	}

	Switch ($todisk)
	{
		auto {
			$drives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[a-z]$'
			$newdrives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[d-z]$'
			foreach ($drive in $drives) {
				$newpath = "$($drive):\$($structure)\$($filename).$($types)"
				$tempoutputfoldoer = "$($drive):\$($structure)"
				Get-ChildItem $tempoutputfoldoer -Recurse -Include "*$($filename)*" -ErrorAction SilentlyContinue | Foreach-Object {
					$output = $_.fullname
					$outputfoldoer = "$($drive):\$($structure)"
					break
				}

				foreach ($drive in $newdrives) {
					if(Test-Disk -Path $drive) {
						$output = "$($drive):\$($structure)\$($packer).$($types)"
						$outputfoldoer = "$($drive):\$($structure)"
						break
					} else {
						$output = "$($env:SystemDrive)\$($structure)\$($packer).$($types)"
						$outputfoldoer = "$($env:SystemDrive)\$($structure)"
					}
				}
			}
		}
		default {
			$output = "$($todisk):\$($structure)\$($packer).$($types)"
			$outputfoldoer = "$($todisk):\$($structure)"
		}
	}

	if(!(Test-Path $outputfoldoer -PathType Container)) {
		New-Item -Path $outputfoldoer -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
		if(!(Test-Path $outputfoldoer -PathType Container)) {
			Write-Host "    - Failed to create directory: $($outputfoldoer)`n" -ForegroundColor Red
			return
		}
	}
	
	Switch ($types)
	{
		exe {
			if ((Test-Path $output -PathType Leaf)) {
				Get-RunApp -filename $output -param $param -pp $pp -sel 1
			} else {
				Write-Host "`    * Start download
    - Download link: $url"
				try {
				    Write-Host "`    - Save the file to: $output"
					(New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
                    Get-RunApp -filename $output -param $param -pp $pp -sel 1
				} catch {
					Write-Host "     - Status: Not available`n" -ForegroundColor Red
				}
			}
		}
		zip {
			$tmpnewpathexe = "$($todisk)\$($structure)\$($packer).exe"
			$tmpnewpathzip = "$($todisk)\$($structure)\$($packer).zip"

			if ((Test-Path $tmpnewpathexe -PathType Leaf)) {
				Get-RunApp -filename $tmpnewpathexe -param $param -pp $pp -sel 1
			} else {
				if ((Test-Path $tmpnewpathzip -PathType Leaf)) {
					Write-Host "    - Locally exist: $tmpnewpathzip"
					Switch ($act)
					{
						Unzip {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - Unzip only"
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								return
							}
						}
						Install {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - Unzip after download"
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								Get-RunApp -filename $tmpnewpathexe -param $param -pp $pp -sel 1
								return
							}
						}
					}
				} else {
					Write-Host "    * Start download
    - Connection address: $url"
				    try {
                        Write-Host "`    - Save the file to: $output"
					(New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
				    } catch {
					    Write-Host "     - Status: Not available`n" -ForegroundColor Red
					    break
				    }
					Switch ($act)
					{
						Unzip {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - Unzip only"
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								return
							}
						}
						Install {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - Run after decompression"
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								Get-RunApp -filename $tmpnewpathexe -param $param -pp $pp -sel 1
								return
							}
						}
					}
				}
			}
		}
		bat {
			if ((Test-Path $output -PathType Leaf)) {
				Get-RunApp -filename $output -param $param -pp $pp -sel 2
			} else {
				Write-Host "`n    * Start download
    - Connection address: $url"
				try {
                    Write-Host "`    - Save the file to: $output"
				(New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
				Get-RunApp -filename $output -param $param -pp $pp -sel 2
                } catch {
                    Write-Host "     - Status: Not available`n" -ForegroundColor Red
                    break
                }
			}
		}
		ps1 {
			if ((Test-Path $output -PathType Leaf)) {
				Get-RunApp -filename $output -param $param -pp $pp -sel 3
			} else {
				Write-Host "`n    * Start download
    - Connection address: $url"
				try {
                    Write-Host "`    - Save the file to: $output"
                    (New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
				    Get-RunApp -filename $output -param $param -pp $pp -sel 3
                } catch {
                    Write-Host "     - Status: Not available`n" -ForegroundColor Red
                }
			}
		}
	}
}

function Get-RunApp {
	param(
		$filename,
		$param,
		$pp,
		$sel
	)

	if ((Test-Path $filename -PathType Leaf)) {
		Switch ($pp)
		{
			Fast {
				Write-Host "    - Fast running: $filename
    - Parameter: $param"
				if ($param -eq "") {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename }
						2 { Start-Process $filename }
						3 { Start-Process powershell -argument "$filename" }
					}
				} else {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename -ArgumentList $param }
						2 { Start-Process $filename }
						3 { Start-Process powershell -argument "$filename $param" }
					}
				}
			}
			Wait {
				Write-Host "    - Waiting to run: $filename
    - Parameter: $param"
				if ($param -eq "") {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename -Wait }
						2 { Start-Process $filename -Wait }
						3 { Start-Process powershell -argument "$filename" -Wait }
					}
				} else {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename -ArgumentList $param -Wait }
						2 { Start-Process $filename -Wait }
						3 { Start-Process powershell -argument "$filename $param" -Wait }
					}
				}
			}
		}
		Write-Host ""
	} else {
        Write-Host "    - No installation files were found,`n      please check the integrity: $filename" -ForegroundColor Red
	}
}

cls
Write-Host "`n   Author: Yi ( http://fengyi.tel )

   From: Yi's Solution
   buildstring: 5.1.2.1.bk_release.210120-1208

   Installed software list ( total $($app.Count) items )
   ---------------------------------------------------"
for ($i=0; $i -lt $app.Count; $i++) {
	Switch ($app[$i][1])
	{
		Enable {
			Write-Host "   'Wait install' - $($app[$i][0])" -ForegroundColor Green
		}
		Disable {
			Write-Host "   'Skip install' - $($app[$i][0])" -ForegroundColor Red
		}
	}
}
Write-Host "   ---------------------------------------------------"

function Wait-Exit {
	param(
		[int]$wait
	)
    Write-Host "`n   Tip: The installation script will automatically exit after $wait seconds..." -ForegroundColor Red
	Start-Sleep -s $wait
	exit
}

function Install-start {
	Write-Host "`n   Installing software..."
	Write-Host "   ---------------------------------------------------"
	for ($i=0; $i -lt $app.Count; $i++) {
		Get-Version -appname $app[$i][0] -status $app[$i][1] -act $app[$i][2] -pp $app[$i][3] -types $app[$i][4] -todisk $app[$i][5] -structure $app[$i][6] -filename $app[$i][7] -packer $app[$i][8] -url $app[$i][9] -param $app[$i][10]
	}
}

function Process-other {
	Write-Host "`n    Processing other:" -ForegroundColor Green

	Write-Host "    - Delete startup items"
	Remove-ItemProperty -ErrorAction SilentlyContinue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "Wechat" | Out-Null

	Write-Host "    - Delete redundant shortcuts"
	Set-Location "$env:public\Desktop"
	Remove-Item -Force -ErrorAction SilentlyContinue ".\Kleopatra.lnk" | Out-Null

	Write-Host "    - Rename"
	#Rename-Item -Path ".\Google Chrome.lnk" -NewName "New Browser.lnk" -ErrorAction SilentlyContinue | Out-Null
}

If ($Force) {
	Install-start
	Process-other
} else {
	Write-Host "   Do you want to install the above software?" -ForegroundColor Green

    $caption="Please confirm before installing the software."
    $message="Continue installation (Y)`nCancel the installation (N)"
	$choices = @("&Yes","&No")
	$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription] 
	$choices | foreach  { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))} 
	$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 1)
	Switch ($prompt)
	{
		0 {
			Install-start
			Process-other
			Wait-Exit -wait 6
		}
		1 {
			Write-Host "`n   Cancel the installation."
			Wait-Exit -wait 2
		}
	}
}