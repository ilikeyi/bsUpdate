# Set main language: en-US
$langlist = New-WinUserLanguageList en-US

# Clears the other input methods from the displayed language
$langlist[0].InputMethodTips.Clear()

# English (United States)
$langlist[0].InputMethodTips.add('0409:00000409')

# Chinese (Simplified Chinese): Pinyin
$langlist[0].InputMethodTips.add('0804:{81D4E9C9-1D3B-41BC-9E6C-4B40BF79E35E}{FA550B04-5AD7-411f-A5AC-CA038EC515D7}')

# Chinese (Simplified Chinese): Wubi
$langlist[0].InputMethodTips.add('0804:{6a498709-e00b-4c45-a018-8f9e4081ae40}{82590C13-F4DD-44f4-BA1D-8667246FDF8E}')

# Apply the changes made on the system (and force to avoid the prompt  message)
Set-WinUserLanguageList $langlist -Force

# Keyboard default language: en-US
Set-WinDefaultInputMethodOverride -InputTip "0409:00000409"

# Set the locale for the region and language, for example, to zh-CN:
Set-WinSystemLocale zh-CN

# Set the system time zone
Set-TimeZone -Id "China Standard Time" -PassThru | Out-Null

exit