﻿#Requires -version 5.0

[CmdletBinding()]
param(
	[parameter(Mandatory = $false, HelpMessage = "Forced, no need to ask")]
	[switch]$Force,
	[switch]$IsProcess
)

$Host.UI.RawUI.WindowTitle = "Yi's Solutions, automatic update"

# Please set the server list
# Configuration: domain name + structure
$ServerList = @(
	('https://fengyi.tel',
	 '/download/bs/v5/latest.xml' ),
	('https://github.com',
	 '/ilikeyi/bsUpdate/raw/main/v5/latest.xml' ),
	('https://gitee.com',
	 '/ilikeyi/BsUpdate/raw/master/v5/latest.xml' )
)

function Test-URI {
	Param(
		[Parameter(Position=0,Mandatory,HelpMessage="HTTP or HTTPS")]
		[ValidatePattern( "^(http|https)://" )]
		[Alias("url")]
		[string]$URI,
		[Parameter(ParameterSetName="Detail")]
		[Switch]$Detail,
		[ValidateScript({$_ -ge 0})]
		[int]$Timeout = 30
	)
	Process {
		Try {
			$paramHash = @{
				UseBasicParsing = $True
				DisableKeepAlive = $True
				Uri = $uri
				Method = 'Head'
				ErrorAction = 'stop'
				TimeoutSec = $Timeout
			}
			$test = Invoke-WebRequest @paramHash
			if ($Detail) {
				$test.BaseResponse | Select ResponseURI,ContentLength,ContentType,LastModified, @{Name="Status";Expression={$Test.StatusCode}}
			} else {
				if ($test.statuscode -ne 200) { $False } else { $True }
			}
		} Catch {
			write-verbose -message $_.exception
			if ($Detail) {
				$objProp = [ordered]@{
					ResponseURI = $uri
					ContentLength = $null
					ContentType = $null
					LastModified = $null
					Status = 404
				}
				New-Object -TypeName psobject -Property $objProp
			} else { $False }
		}
	}
}

function Wait-Exit {
	param(
		[int]$wait
	)
	Write-Host "`n   The automatic update script will automatically exit after $wait seconds." -ForegroundColor Red
	Start-Sleep -s $wait
	exit
}

function Archive-Unzip {
	param(
		$filename,
        $to
	)

    if (Get-Zip) {
        $arguments = "x ""-r"" ""-tzip"" ""$filename"" ""-o$to"" ""-y""";
        Start-Process $script:Zip "$arguments" -Wait -WindowStyle Minimized
    } else {
        Expand-Archive -LiteralPath $filename -DestinationPath $to -force
    }
}

function Get-Zip {
	if (Test-Path "$env:ProgramFiles\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:ProgramFiles(x86)\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles(x86)\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:SystemDrive\Yi\Yi\AIO\7z.exe") {
		$script:Zip = "$env:SystemDrive\Yi\Yi\AIO\7z.exe"
		return $true
	}
	return $false
}

Write-host "`n   Author: Yi ( https://fengyi.tel )

   From: Yi's Solutions
   buildstring: 5.3.1.3.bs_release.210120-1208`n"

$locver = "$PSScriptRoot\..\version.xml"
$ServerTest = $false
if ((Test-Path $locver)) {
	[xml]$curver = Get-content $locver
	write-host "   ver: $($curver.versioninfo.version.version)`n"
} else {
	Write-host "   The version.xml file of the local version was not found,`n   the check update has been aborted.`n"

	If ($Force) {
		return
	} else {
		Wait-Exit -wait 6
	}
}

Write-host "   Check server status ( Total $($ServerList.Count) optional )
   ---------------------------------------------------"

foreach ($list in $ServerList | Sort-Object { Get-Random } ) {
	$fullurl = $list[0] + $list[1]

	Write-Host "   * Server address: $($list[0])"

	if(test-uri $fullurl){
		$versionxmlloc = $fullurl
		$ServerTest = $true
		Write-Host "     - Status: Available" -ForegroundColor Green
		break
	} else {
		Write-Host "     - Status: Not available`n" -ForegroundColor Red
	}
}

if ($ServerTest) {
	Write-Host "   ---------------------------------------------------"
	Write-Host "     - Set as priority" -ForegroundColor Green
} else {
	Write-Host "     - Failed server status test" -ForegroundColor Red
	Write-Host "   ---------------------------------------------------"

	If ($Force) {
		exit
	} else {
		Wait-Exit -wait 6
	}
}

Write-host "`n   Querying and updating..."

# Check if remote version xml is available to the client
$error.Clear()
$time = Measure-Command { $request = Invoke-WebRequest -Uri $versionxmlloc } 2>$null

if ($error.Count -eq 0) {
	Write-host "`n   Checking whether the latest version is available,`n   time-consuming connection $($time.TotalMilliseconds) millisecond."
} else {
	Write-host "`n   Unable to connect to the remote server,`n   check update has been aborted.`n"

	If ($Force) {
		return
	} else {
		Wait-Exit -wait 6
	}
}

$getSerVer = (Invoke-WebRequest -Uri $versionxmlloc -Body $body -Method:Get -Headers $head -ContentType "application/xml" -TimeoutSec 15 -ErrorAction:stop)
$IsCorrectAuVer = $false
$chkLocalver = $($curver.versioninfo.version.minau)
$chkRemovever = ([xml]$getSerVer.Content).versioninfo.version.minau
$PPocess = "$PSScriptRoot\..\Post.Processing.bat"
$PsPocess = "$PSScriptRoot\..\Post.Processing.ps1"

If([String]::IsNullOrEmpty($chkRemovever)){
	$IsCorrectAuVer = $false
} else {
	if ($chkRemovever -ge $chkLocalver) {
		$IsCorrectAuVer = $true
	} else {
		$IsCorrectAuVer = $false
	}
}

# When the minimum automatic update program version requirements are met, execution will continue.
if ($IsCorrectAuVer) {
	Write-host "`n   Meet the minimum update program version requirements,`n   the minimum required version: $($curver.versioninfo.version.minau)"
	$IsUpdateAvailable = $false
	$url = ([xml]$getSerVer.Content).versioninfo.download.url
	$output = "$PSScriptRoot\..\latest.zip"

	if (([xml]$getSerVer.Content).versioninfo.version.version -gt $($curver.versioninfo.version.version)) {
		$IsUpdateAvailable = $true
	} else {
		$IsUpdateAvailable = $false
	}

	if ($IsUpdateAvailable) {
		Write-host "`n   Verify that the address is available
   ---------------------------------------------------"

		Write-Host "   * Download link: $($url)"
		if(test-uri $url){
			Write-Host "     - Available" -ForegroundColor Green
			Write-Host "   ---------------------------------------------------"
		} else {
			Write-Host "     - Unavailable" -ForegroundColor Red
			Write-Host "   ---------------------------------------------------"
			If ($Force) {
				exit
			} else {
				Wait-Exit -wait 6
			}
		}

		Write-host "`n     Currently used version: $($curver.versioninfo.version.version) - $($curver.versioninfo.version.buildstring)
   Latest version available: $(([xml]$getSerVer.Content).versioninfo.version.version) - $(([xml]$getSerVer.Content).versioninfo.version.buildstring)
   
   $(([xml]$getSerVer.Content).versioninfo.changelog.title)
   $('-' * (([xml]$getSerVer.Content).versioninfo.changelog.title).Length)
$(([xml]$getSerVer.Content).versioninfo.changelog.'#text')"

		Write-host "   Found a new version available!`n" -ForegroundColor Green
		If ($Force) {
			$title = "   The update is being forced."
			$start_time = Get-Date
			if ((Test-Path $output)) { remove-item -path $output -force -ErrorAction SilentlyContinue }
			Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
			Write-Output "`n   Time used: $((Get-Date).Subtract($start_time).Seconds) second(s)"
		} else {
			$title = "Do you want to install this update?"
			$message = "Yes, the above update will be installed`nNo, the update will not be installed"
			$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Yes"
			$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "No"
			$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
			$prompt=$host.ui.PromptForChoice($title, $message, $options, 0)
			Switch ($prompt)
			{
				0 {
					$start_time = Get-Date
					remove-item -path $output -force -ErrorAction SilentlyContinue
					Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
					Write-Output "`n   Time used: $((Get-Date).Subtract($start_time).Seconds) second(s)"
				}
				1 {
					Write-Host "`n   The user has cancelled the update."
					Wait-Exit -wait 2
				}
			}
		}
		if ((Test-Path $output -PathType Leaf)) {
			Archive-Unzip -filename $output -to "$PSScriptRoot\..\..\"
			Write-Host "`n   * Post-processing"
			if ($IsProcess) {
				Write-Host "     - Not executed" -ForegroundColor red
			} else {
				if ((Test-Path $PPocess -PathType Leaf)) {
					Start-Process -FilePath $PPocess -wait -WindowStyle Minimized
					remove-item -path $PPocess -force
					Write-Host "     - Complete" -ForegroundColor Green
				} else {
					Write-Host "     - No standby" -ForegroundColor red
				}
				if ((Test-Path $PsPocess -PathType Leaf)) {
					Start-Process powershell -ArgumentList "-file $($PsPocess)" -wait -WindowStyle Minimized
					remove-item -path $PsPocess -force
					Write-Host "     - Complete" -ForegroundColor Green
				} else {
					Write-Host "     - No standby" -ForegroundColor red
				}
			}
			Write-host "`n   Yi's Solutions Successfully updated!`n"
		} else {
			Write-host "`n   An error occurred while downloading the update,`n   The update process is aborted."
		}
		remove-item -path $output -force -ErrorAction SilentlyContinue
	} else {
		Write-host "`n   No update available.`n`n   You are running the latest available version of Yi's Solutions.`n"
	}
} else {
	Write-host "`n   Does not meet the minimum update program version requirements,

   Minimum required version: $($curver.versioninfo.version.minau)

   Please re-download a copy of Yi's Solutions to update this tool.

   Check update has been aborted.`n"
}

If ($Force) {
	return
} else {
	Wait-Exit -wait 6
}