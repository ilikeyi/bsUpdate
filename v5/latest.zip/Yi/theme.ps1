﻿#
# Author: Yi ( https://fengyi.tel )
#
# From: Yi's Solution
# buildstring: 5.1.1.2.bk_release.210120-1208
#
# Description:
#
# Change the icon every 5 minutes, skip if there is no change
#

$SysTheme = 'HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
$YiTheme = 'HKCU\SOFTWARE\Yi'


# Registry initialization
if (Test-Path "Registry::$YiTheme") {
    Write-Output "The path exists: $($YiTheme)"

    if ((get-item "Registry::$YiTheme").getValue("isDark") -ne $null) {
        Write-Output "There is isDark, skip creating!"
    }
    else {
        Write-Output "Do not save isDark, create!"
        New-Itemproperty -path "Registry::$YiTheme" -name "isDark" -value "" | Out-Null
    }
} else {
    Write-Output 'The path does not exist!'

    Write-Output "Create the registry path: $($YiTheme)"
    New-Item -Path "Registry::$YiTheme" | Out-Null
    New-Itemproperty -path "Registry::$YiTheme" -name "isDark" -value "" | Out-Null
}

$resultSysTheme = (Get-ItemProperty -Path "Registry::$SysTheme" -ErrorAction Stop).AppsUseLightTheme
$resultYiTheme = (Get-ItemProperty -Path "Registry::$YiTheme" -ErrorAction Stop).isDark

switch($resultSysTheme)
{
	"0" {
			echo "Dark mode process"
			switch($resultYiTheme)
			{
				"0" {
					echo "1. Jump over..."
				}
				"1" {
					echo "2. Change"
					Start-Process -FilePath "$env:SystemDrive\Yi\Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi"" /S=.ShellClassInfo /L=IconResource=""$env:SystemDrive\Yi\Yi\icons\Yi.Dark.ico,0"""
					Set-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\Directory\Background\shell\Yi" -Name Icon -Value "$env:SystemDrive\\Yi\\Yi\\icons\\Yi.Dark.ico" -Type String
					Set-ItemProperty -Path "Registry::$YiTheme" -Name "isDark" -Value 0
				}
				default {
					echo "3. Change"
					Start-Process -FilePath "$env:SystemDrive\Yi\Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi"" /S=.ShellClassInfo /L=IconResource=""$env:SystemDrive\Yi\Yi\icons\Yi.Dark.ico,0"""
					Set-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\Directory\Background\shell\Yi" -Name Icon -Value "$env:SystemDrive\\Yi\\Yi\\icons\\Yi.Dark.ico" -Type String
					Set-ItemProperty -Path "Registry::$YiTheme" -Name "isDark" -Value 0
				}
			}
	}
	"1" {
			echo "Light mode process"
			switch($resultYiTheme)
			{
				"0" {
					echo "4. Change"
					Start-Process -FilePath "$env:SystemDrive\Yi\Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi"" /S=.ShellClassInfo /L=IconResource=""$env:SystemDrive\Yi\Yi\icons\Yi.ico,0"""
					Set-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\Directory\Background\shell\Yi" -Name Icon -Value "$env:SystemDrive\\Yi\\Yi\\icons\\Yi.ico" -Type String
					Set-ItemProperty -Path "Registry::$YiTheme" -Name "isDark" -Value 1
				}
				"1" {
					echo "5. Jump over..."
				}
				default
				{
					echo "6. Change"
					Start-Process -FilePath "$env:SystemDrive\Yi\Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi"" /S=.ShellClassInfo /L=IconResource=""$env:SystemDrive\Yi\Yi\icons\Yi.ico,0"""
					Set-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\Directory\Background\shell\Yi" -Name Icon -Value "$env:SystemDrive\\Yi\\Yi\\icons\\Yi.ico" -Type String
					Set-ItemProperty -Path "Registry::$YiTheme" -Name "isDark" -Value 1
				}
			}
	}
}

exit