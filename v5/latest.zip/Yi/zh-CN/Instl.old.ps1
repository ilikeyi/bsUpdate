﻿#
#    警告：为防止更新后覆盖，请另存为后再修改。
#
#    欢迎您使用 PowerShell 安装软件
#
#    主要功能：
#      1. 本地不存在安装包，激活下载；
#      2. 可指定软件包盘符，未指定则按 [d-z] 顺序搜索，
#         仅搜索可用盘，未搜索到默认当前系统盘；
#      3. 搜索文件名支持模糊查找，通配符 *；
#      4. 支持解压包处理等。
#
#    先决条件：
#      - PowerShell 5.1 或更高
#
#    源代码：
#    https://github.com/ilikeyi/powershell.install.software
#    https://gitee.com/ilikeyi/powershell.install.software
#

# 获取脚本参数（如果有）
[CmdletBinding()]
param(
	[parameter(Mandatory = $false, HelpMessage = "静默")]
	[Switch]$Force
)

# 所有软件配置
$app = @(
	("Nvidia GEFORCE GAME READY DRIVER",                  # 软件包名称
	 "Disable",                                           # 状态：Enable = 启用，Disable = 禁用
	 "Install",                                           # 动作：Install = 安装，NoInst = 下载后不安装，Unzip = 下载后仅压缩
	 "wait",                                              # 运行方式：Wait = 等待运行结束，Fast = 直接运行
	 "exe",                                               # 文件类型： exe, zip, bat, ps1
	 "auto",                                              # 盘符：Auto = 全盘搜索，A-Z = 指定盘符或自定义路径
	 "Yi\Software package\Drive",                         # 目录结构，例如：AUTO 改成 C，合并结果：C:\Yi\Software package\Drive
	 "*-desktop-win10-*-international-dch-whql",          # 匹配文件名，支持模糊功能（*）
	 "460.89-desktop-win10-64bit-international-dch-whql", # 网站下载绝对文件名，请勿填后缀
	 "https://us.download.nvidia.cn/Windows/460.89/",     # 网站路径前缀，/ 号结尾
	 "-s -clean -noreboot -noeula"),                      # 运行参数
	("VisualCppRedist AIO",
	 "Disable",
	 "Install",
	 "wait",
	 "zip",
	 "auto",
	 "Yi\Software package\AIO",
	 "VisualCppRedist_AIO_x86_x64",
	 "VisualCppRedist_AIO_x86_x64_43",
	 "https://github.com/abbodi1406/vcredist/releases/download/v0.43.0/",
	 "/y"),
	("Gpg4win",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\AIO",
	 "gpg4win-*",
	 "gpg4win-3.1.15",
	 "https://files.gpg4win.org/",
	 "/S"),
	("Python",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\AIO",
	 "python-*",
	 "python-3.9.1-amd64",
	 "https://www.python.org/ftp/python/3.9.1/",
	 "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0"),
	("酷狗音乐",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\Music",
	 "kugou*",
	 "kugou9175",
	 "https://downmini.yun.kugou.com/web",
	 "/S"),
	("网易云音乐",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\Music",
	 "cloudmusicsetup*",
	 "cloudmusicsetup2.7.5.198554",
	 "https://d1.music.126.net/dmusic/",
	 "/S"),
	("QQ 音乐",
	 "Disable",
	 "Install",
	 "fast",
	 "exe",
	 "auto",
	 "Yi\Software package\Music",
	 "QQMusicSetup",
	 "QQMusicSetup",
	 "https://dldir1.qq.com/music/clntupate/",
	 "/S"),
	("腾讯 QQ 2020",
	 "Enable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\social",
	 "PCQQ2020",
	 "PCQQ2020",
	 "https://down.qq.com/qqweb/PCQQ/PCQQ_EXE/",
	 "/S"),
	("微信",
	 "Disable",
	 "Install",
	 "wait",
	 "exe",
	 "auto",
	 "Yi\Software package\social",
	 "WeChatSetup",
	 "WeChatSetup",
	 "https://dldir1.qq.com/weixin/Windows/",
	 "/S")
)

function Test-Disk {
	param (
		[string]$Path
	)
	$test_tmp_filename = "writetest-"+[guid]::NewGuid()
	$test_filename = $Path + ":\" + $test_tmp_filename
	try {
		[io.file]::OpenWrite($test_filename).close()

		if ((Test-Path -Path $test_filename)) {
			Remove-Item $test_filename -ErrorAction SilentlyContinue
			return $true
		}
		$false
	} catch {
		return $false
	}
}

function Get-Version {
	param(
		$appname,
		$status,
		$act,
		$pp,
		$types,
		$todisk,
		$structure,
		$filename,
		$packer,
		$url,
		$param
	)

	Switch ($status)
	{
		Enable {
			Write-Host "   '正在安装' - $($appname)" -ForegroundColor Green
		}
		Disable {
			Write-Host "   '跳过安装' - $($appname)" -ForegroundColor Red
			return
		}
	}

	$url = $url + $packer + "." + $types

	switch -regex ($todisk)
	{
		"auto" { break }
		"^[a-z]$" { break }
		default {
			$todisk = "auto"
		}
	}

	Switch ($todisk)
	{
		auto {
			$drives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[a-z]$'
			$newdrives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[d-z]$'
			foreach ($drive in $drives) {
				$newpath = "$($drive):\$($structure)\$($filename).$($types)"
				$tempoutputfoldoer = "$($drive):\$($structure)"
				Get-ChildItem $tempoutputfoldoer -Recurse -Include "*$($filename)*" -ErrorAction SilentlyContinue | Foreach-Object {
					$output = $_.fullname
					$outputfoldoer = "$($drive):\$($structure)"
					break
				}

				foreach ($drive in $newdrives) {
					if(Test-Disk -Path $drive) {
						$output = "$($drive):\$($structure)\$($packer).$($types)"
						$outputfoldoer = "$($drive):\$($structure)"
						break
					} else {
						$output = "$($env:SystemDrive)\$($structure)\$($packer).$($types)"
						$outputfoldoer = "$($env:SystemDrive)\$($structure)"
					}
				}
			}
		}
		default {
			$output = "$($todisk):\$($structure)\$($packer).$($types)"
			$outputfoldoer = "$($todisk):\$($structure)"
		}
	}

	if(!(Test-Path $outputfoldoer -PathType Container)) {
		New-Item -Path $outputfoldoer -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
		if(!(Test-Path $outputfoldoer -PathType Container)) {
			Write-Host "    - 创建目录失败：$($outputfoldoer)`n" -ForegroundColor Red
			return
		}
	}
	
	Switch ($types)
	{
		exe {
			if ((Test-Path $output -PathType Leaf)) {
				Get-RunApp -filename $output -param $param -pp $pp -sel 1
			} else {
				Write-Host "`    * 开始下载
    - 连接地址：$url"
				try {
					Write-Host "`    - 保存文件到：$output"
					(New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
					Get-RunApp -filename $output -param $param -pp $pp -sel 1
				} catch {
					Write-Host "     - 状态：不可用`n" -ForegroundColor Red
				}
			}
		}
		zip {
			$tmpnewpathexe = "$($todisk)\$($structure)\$($packer).exe"
			$tmpnewpathzip = "$($todisk)\$($structure)\$($packer).zip"

			if ((Test-Path $tmpnewpathexe -PathType Leaf)) {
				Get-RunApp -filename $tmpnewpathexe -param $param -pp $pp -sel 1
			} else {
				if ((Test-Path $tmpnewpathzip -PathType Leaf)) {
					Write-Host "    - 本地存在：$tmpnewpathzip"
					Switch ($act)
					{
						Unzip {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - 仅解压"
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								return
							}
						}
						Install {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - 下载后解压"
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								Get-RunApp -filename $tmpnewpathexe -param $param -pp $pp -sel 1
								return
							}
						}
					}
				} else {
					Write-Host "    * 开始下载
    - 连接地址：$url"
					try {
						Write-Host "`    - 保存文件到：$output"
						(New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
					} catch {
						Write-Host "     - 状态：不可用`n" -ForegroundColor Red
						break
					}
					Switch ($act)
					{
						Unzip {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - 仅解压..."
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								return
							}
						}
						Install {
							if ((Test-Path $output -PathType Leaf)) {
								Write-Host "    - 解压后运行..."
								Expand-Archive -LiteralPath $output -DestinationPath $outputfoldoer -force
								if ((Test-Path $output)) { remove-item -path $output -force }
								Get-RunApp -filename $tmpnewpathexe -param $param -pp $pp -sel 1
								return
							}
						}
					}
				}
			}
		}
		bat {
			if ((Test-Path $output -PathType Leaf)) {
				Get-RunApp -filename $output -param $param -pp $pp -sel 2
			} else {
				Write-Host "`n    * 开始下载
    - 连接地址：$url"
				try {
					Write-Host "`    - 保存文件到：$output"
					(New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
					Get-RunApp -filename $output -param $param -pp $pp -sel 2
				} catch {
					Write-Host "     - 状态：不可用`n" -ForegroundColor Red
					break
				}
			}
		}
		ps1 {
			if ((Test-Path $output -PathType Leaf)) {
				Get-RunApp -filename $output -param $param -pp $pp -sel 3
			} else {
				Write-Host "`n    * 开始下载
    - 连接地址：$url"
				try {
					Write-Host "`    - 保存文件到：$output"
					(New-Object System.Net.WebClient).DownloadFile($url, $output) | Out-Null
					Get-RunApp -filename $output -param $param -pp $pp -sel 3
				} catch {
					Write-Host "     - 状态：不可用`n" -ForegroundColor Red
				}
			}
		}
	}
}

function Get-RunApp {
	param(
		$filename,
		$param,
		$pp,
		$sel
	)

	if ((Test-Path $filename -PathType Leaf)) {
		Switch ($pp)
		{
			Fast {
				Write-Host "    - 快速运行：$filename
    - 参数：$param"
				if ($param -eq "") {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename }
						2 { Start-Process $filename }
						3 { Start-Process powershell -argument "$filename" }
					}
				} else {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename -ArgumentList $param }
						2 { Start-Process $filename }
						3 { Start-Process powershell -argument "$filename $param" }
					}
				}
			}
			Wait {
				Write-Host "    - 等待运行：$filename
    - 参数：$param"
				if ($param -eq "") {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename -Wait }
						2 { Start-Process $filename -Wait }
						3 { Start-Process powershell -argument "$filename" -Wait }
					}
				} else {
					switch ($sel)
					{
						1 { Start-Process -FilePath $filename -ArgumentList $param -Wait }
						2 { Start-Process $filename -Wait }
						3 { Start-Process powershell -argument "$filename $param" -Wait }
					}
				}
			}
		}
		Write-Host ""
	} else {
		Write-Host "    - 未发现安装文件，请检查完整性：$filename`n" -ForegroundColor Red
	}
}

cls
Write-Host "`n   Author: Yi ( http://fengyi.tel )

   From: Yi's Solution
   buildstring: 5.1.2.1.bk_release.210120-1208

   安装软件列表 ( 共 $($app.Count) 款 )
   ---------------------------------------------------"
for ($i=0; $i -lt $app.Count; $i++) {
	Switch ($app[$i][1])
	{
		Enable {
			Write-Host "   '等待安装' - $($app[$i][0])" -ForegroundColor Green
		}
		Disable {
			Write-Host "   '跳过安装' - $($app[$i][0])" -ForegroundColor Red
		}
	}
}
Write-Host "   ---------------------------------------------------"

function Wait-Exit {
	param(
		[int]$wait
	)
	Write-Host "`n   提示：$wait 秒后自动退出安装脚本..." -ForegroundColor Red
	Start-Sleep -s $wait
	exit
}

function Install-start {
	Write-Host "`n   正在安装软件..."
	Write-Host "   ---------------------------------------------------"
	for ($i=0; $i -lt $app.Count; $i++) {
		Get-Version -appname $app[$i][0] -status $app[$i][1] -act $app[$i][2] -pp $app[$i][3] -types $app[$i][4] -todisk $app[$i][5] -structure $app[$i][6] -filename $app[$i][7] -packer $app[$i][8] -url $app[$i][9] -param $app[$i][10]
	}
}

function Process-other {
	Write-Host "`n    处理其它：" -ForegroundColor Green

	Write-Host "    - 删除开机自启动项"
	Remove-ItemProperty -ErrorAction SilentlyContinue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "Wechat" | Out-Null

	Write-Host "    - 删除多余快捷方式"
	Set-Location "$env:public\Desktop"
	Remove-Item -Force -ErrorAction SilentlyContinue ".\Kleopatra.lnk" | Out-Null

	Write-Host "    - 更名"
	#Rename-Item -Path ".\Google Chrome.lnk" -NewName "谷歌浏览器.lnk" -ErrorAction SilentlyContinue | Out-Null
}

If ($Force) {
	Install-start
	Process-other
} else {
	Write-Host "   是否安装以上软件？" -ForegroundColor Green

	$caption="安装软件前请确认。"
	$message="继续安装（Y）`n取消安装（N）"
	$choices = @("&Yes","&No")
	$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription] 
	$choices | foreach  { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))} 
	$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 1)
	Switch ($prompt)
	{
		0 {
			Install-start
			Process-other
			Wait-Exit -wait 6
		}
		1 {
			Write-Host "`n   取消安装。"
			Wait-Exit -wait 2
		}
	}
}