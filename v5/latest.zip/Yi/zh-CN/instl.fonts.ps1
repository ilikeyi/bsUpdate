﻿$Host.UI.RawUI.WindowTitle = "安装字体"

# 请设置要搜索的目录
$DirectoryStructure = @(
	"Yi\Fonts"
	"Fonts"
)

# 请设置搜索文件类型
$type = @(
	"*.otf"
	"*.ttf"
)

#region functions
function Install-Fonts {
	param (
		[string]$fontFile,
		[string]$shortname
	)
	
	if ((Test-Path "$env:SystemDrive\Windows\fonts\$shortname") -or 
		(Test-Path "$env:LOCALAPPDATA\Microsoft\Windows\Fonts\$shortname")) {
		Write-Host "   '已安装' - $($fontFile)" -ForegroundColor Red
	} else {
		Write-Host "   '安装中' - $($fontFile)" -ForegroundColor Green

		(New-Object -ComObject Shell.Application).Namespace(0x14).CopyHere($_.FullName) | Out-Null
		Write-Host "    - 完成.`n" -ForegroundColor Green
	}
}
#endregion

Write-host "`n   正在安装字体
   ---------------------------------------------------"

# install fonts
$drives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[a-z]$'
foreach ($drive in $drives){
	foreach ($nsf in $DirectoryStructure) {
		Get-ChildItem "${drive}:\${nsf}" -Recurse -Include ($type) -ErrorAction SilentlyContinue | Foreach-Object {
			Install-Fonts -fontFile $_.FullName -shortname $_.Name
		}
	}
}