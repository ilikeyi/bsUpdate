﻿#
#  请认真阅读以下来自微软的声明。
#
#  应用和网站将以其支持的列表中的第一种语言显示。
#

# 设置主要语言：zh-CN
$langlist = New-WinUserLanguageList zh-CN

# 从显示的语言中清除其他输入法
$langlist[0].InputMethodTips.Clear()

# Chinese (Simplified Chinese): Pinyin
$langlist[0].InputMethodTips.add('0804:{81D4E9C9-1D3B-41BC-9E6C-4B40BF79E35E}{FA550B04-5AD7-411f-A5AC-CA038EC515D7}')

# Chinese (Simplified Chinese): Wubi
$langlist[0].InputMethodTips.add('0804:{6a498709-e00b-4c45-a018-8f9e4081ae40}{82590C13-F4DD-44f4-BA1D-8667246FDF8E}')

# English (United States)
$langlist[0].InputMethodTips.add('0409:00000409')

# 应用在系统上所做的更改（并强制避免出现提示信息）
Set-WinUserLanguageList $langlist -Force

# 键盘默认语言：en-US
Set-WinDefaultInputMethodOverride -InputTip "0409:00000409"

# 将区域和语言的语言环境设置为例如：zh-CN:
Set-WinSystemLocale zh-CN

# 设置系统时区
Set-TimeZone -Id "China Standard Time" -PassThru | Out-Null