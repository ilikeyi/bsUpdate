﻿#Requires -version 5.0

[CmdletBinding()]
param(
	[parameter(Mandatory = $false, HelpMessage = "Forced, no need to ask")]
	[switch]$Force,
	[switch]$IsProcess
)

$Host.UI.RawUI.WindowTitle = "Yi's 解决方案，自动更新"

# 请设置服务器列表
# 配置：域名 + 结构
$ServerList = @(
	('https://fengyi.tel',
	 '/download/bs/v5/latest.xml' ),
	('https://github.com',
	 '/ilikeyi/bsUpdate/raw/main/v5/latest.xml' ),
	('https://gitee.com',
	 '/ilikeyi/BsUpdate/raw/master/v5/latest.xml' )
)

function Test-URI {
	Param(
		[Parameter(Position=0,Mandatory,HelpMessage="HTTP or HTTPS")]
		[ValidatePattern( "^(http|https)://" )]
		[Alias("url")]
		[string]$URI,
		[Parameter(ParameterSetName="Detail")]
		[Switch]$Detail,
		[ValidateScript({$_ -ge 0})]
		[int]$Timeout = 30
	)
	Process {
		Try {
			$paramHash = @{
				UseBasicParsing = $True
				DisableKeepAlive = $True
				Uri = $uri
				Method = 'Head'
				ErrorAction = 'stop'
				TimeoutSec = $Timeout
			}
			$test = Invoke-WebRequest @paramHash
			if ($Detail) {
				$test.BaseResponse | Select ResponseURI,ContentLength,ContentType,LastModified, @{Name="Status";Expression={$Test.StatusCode}}
			} else {
				if ($test.statuscode -ne 200) { $False } else { $True }
			}
		} Catch {
			write-verbose -message $_.exception
			if ($Detail) {
				$objProp = [ordered]@{
					ResponseURI = $uri
					ContentLength = $null
					ContentType = $null
					LastModified = $null
					Status = 404
				}
				New-Object -TypeName psobject -Property $objProp
			} else { $False }
		}
	}
}

function Wait-Exit {
	param(
		[int]$wait
	)
	Write-Host "`n   自动更新脚本将会在 $wait 秒后自动退出。" -ForegroundColor Red
	Start-Sleep -s $wait
	exit
}

function Archive-Unzip {
	param(
		$filename,
        $to
	)

    if (Get-Zip) {
        $arguments = "x ""-r"" ""-tzip"" ""$filename"" ""-o$to"" ""-y""";
        Start-Process $script:Zip "$arguments" -Wait -WindowStyle Minimized
    } else {
        Expand-Archive -LiteralPath $filename -DestinationPath $to -force
    }
}

function Get-Zip {
	if (Test-Path "$env:ProgramFiles\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:ProgramFiles(x86)\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles(x86)\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:SystemDrive\Yi\Yi\AIO\7z.exe") {
		$script:Zip = "$env:SystemDrive\Yi\Yi\AIO\7z.exe"
		return $true
	}
	return $false
}

Write-host "`n   Author: Yi ( https://fengyi.tel )

   From: Yi's Solutions
   buildstring: 5.3.1.3.bs_release.210120-1208`n"

$locver = "$PSScriptRoot\..\version.xml"
$ServerTest = $false
if ((Test-Path $locver)) {
	[xml]$curver = Get-content $locver
	write-host "   ver: $($curver.versioninfo.version.version)`n"
} else {
	Write-host "   未找到本地版的 version.xml 文件，检查更新已中止。`n"

	If ($Force) {
		return
	} else {
		Wait-Exit -wait 6
	}
}

Write-host "   检查服务器状态 ( 共 $($ServerList.Count) 个可选 )
   ---------------------------------------------------"

foreach ($list in $ServerList | Sort-Object { Get-Random } ) {
	$fullurl = $list[0] + $list[1]

	Write-Host "   * 服务器地址：$($list[0])"

	if(test-uri $fullurl){
		$versionxmlloc = $fullurl
		$ServerTest = $true
		Write-Host "     - 状态：可用" -ForegroundColor Green
		break
	} else {
		Write-Host "     - 状态：不可用`n" -ForegroundColor Red
	}
}

if ($ServerTest) {
	Write-Host "   ---------------------------------------------------"
	Write-Host "     - 已设置为优先级" -ForegroundColor Green
} else {
	Write-Host "     - 未通过服务器状态测试" -ForegroundColor Red
	Write-Host "   ---------------------------------------------------"

	If ($Force) {
		exit
	} else {
		Wait-Exit -wait 6
	}
}

Write-host "`n   正在查询更新中..."

# Check if remote version xml is available to the client
$error.Clear()
$time = Measure-Command { $request = Invoke-WebRequest -Uri $versionxmlloc } 2>$null

if ($error.Count -eq 0) {
	Write-host "`n   正检查是否有最新版本可用，连接耗时 $($time.TotalMilliseconds) 毫秒。"
} else {
	Write-host "`n   无法连接到远程服务器，检查更新已中止。`n"

	If ($Force) {
		return
	} else {
		Wait-Exit -wait 6
	}
}

$getSerVer = (Invoke-WebRequest -Uri $versionxmlloc -Body $body -Method:Get -Headers $head -ContentType "application/xml" -TimeoutSec 15 -ErrorAction:stop)
$IsCorrectAuVer = $false
$chkLocalver = $($curver.versioninfo.version.minau)
$chkRemovever = ([xml]$getSerVer.Content).versioninfo.version.minau
$PPocess = "$PSScriptRoot\..\Post.Processing.bat"
$PsPocess = "$PSScriptRoot\..\Post.Processing.ps1"

If([String]::IsNullOrEmpty($chkRemovever)){
	$IsCorrectAuVer = $false
} else {
	if ($chkRemovever -ge $chkLocalver) {
		$IsCorrectAuVer = $true
	} else {
		$IsCorrectAuVer = $false
	}
}

# 当满足最低自动更新程序版本要求时，将继续执行。
if ($IsCorrectAuVer) {
	Write-host "`n   满足最低更新程序版本要求，最低要求版本：$($curver.versioninfo.version.minau)"
	$IsUpdateAvailable = $false
	$url = ([xml]$getSerVer.Content).versioninfo.download.url
	$output = "$PSScriptRoot\..\latest.zip"

	if (([xml]$getSerVer.Content).versioninfo.version.version -gt $($curver.versioninfo.version.version)) {
		$IsUpdateAvailable = $true
	} else {
		$IsUpdateAvailable = $false
	}

	if ($IsUpdateAvailable) {
		Write-host "`n   验证地址是否可用
   ---------------------------------------------------"

		Write-Host "   * 下载地址：$($url)"
		if(test-uri $url){
			Write-Host "     - 可用" -ForegroundColor Green
			Write-Host "   ---------------------------------------------------"
		} else {
			Write-Host "     - 不可用" -ForegroundColor Red
			Write-Host "   ---------------------------------------------------"
			If ($Force) {
				exit
			} else {
				Wait-Exit -wait 6
			}
		}

		Write-host "`n   当前使用版本: $($curver.versioninfo.version.version) - $($curver.versioninfo.version.buildstring)
   可用最新版本: $(([xml]$getSerVer.Content).versioninfo.version.version) - $(([xml]$getSerVer.Content).versioninfo.version.buildstring)
   
   $(([xml]$getSerVer.Content).versioninfo.changelog.title)
   $('-' * (([xml]$getSerVer.Content).versioninfo.changelog.title).Length)
$(([xml]$getSerVer.Content).versioninfo.changelog.'#text')"

		Write-host "   发现新的可用版本！`n" -ForegroundColor Green
		If ($Force) {
			$title = "   正在强制进行更新。"
			$start_time = Get-Date
			if ((Test-Path $output)) { remove-item -path $output -force -ErrorAction SilentlyContinue }
			Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
			Write-Output "`n   所用的时间：$((Get-Date).Subtract($start_time).Seconds) 秒(s)"
		} else {
			$title = "您要安装此更新吗？"
			$message = "是，将安装上述更新`n否，则不会安装该更新"
			$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Yes"
			$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "No"
			$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
			$prompt=$host.ui.PromptForChoice($title, $message, $options, 0)
			Switch ($prompt)
			{
				0 {
					$start_time = Get-Date
					remove-item -path $output -force -ErrorAction SilentlyContinue
					Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
					Write-Output "`n   所用的时间：$((Get-Date).Subtract($start_time).Seconds) 秒(s)"
				}
				1 {
					Write-Host "`n   用户已取消更新。"
					Wait-Exit -wait 2
				}
			}
		}
		if ((Test-Path $output -PathType Leaf)) {
			Archive-Unzip -filename $output -to "$PSScriptRoot\..\..\"
			Write-Host "`n   * 后期处理"
			if ($IsProcess) {
				Write-Host "     - 不执行" -ForegroundColor red
			} else {
				if ((Test-Path $PPocess -PathType Leaf)) {
					Start-Process -FilePath $PPocess -wait -WindowStyle Minimized
					remove-item -path $PPocess -force
					Write-Host "     - 完成" -ForegroundColor Green
				} else {
					Write-Host "     - 未找到后期处理任务" -ForegroundColor red
				}
				if ((Test-Path $PsPocess -PathType Leaf)) {
					Start-Process powershell -ArgumentList "-file $($PsPocess)" -Wait -WindowStyle Minimized
					remove-item -path $PsPocess -force
					Write-Host "     - 完成" -ForegroundColor Green
				} else {
					Write-Host "     - 未找到后期处理任务" -ForegroundColor red
				}
			}
			Write-host "`n   Yi's Solutions 已成功更新！`n"
		} else {
			Write-host "`n   下载更新时发生错误，更新过程中止。"
		}
		remove-item -path $output -force -ErrorAction SilentlyContinue
	} else {
		Write-host "`n   没有可用的更新。`n`n   您正在运行 Yi's Solutions 的最新可用版本。`n"
	}
} else {
	Write-host "`n   不满足最低更新程序版本要求，

   最低要求版本：$($curver.versioninfo.version.minau)

   请重新下载 Yi's Solutions 的副本，以更新此工具。

   检查更新已中止。`n"
}

If ($Force) {
	return
} else {
	Wait-Exit -wait 6
}