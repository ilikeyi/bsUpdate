﻿<#
	.Log function
#>
Function Logging
{
	$SaveTo = "Log-$(Get-Date -Format "yyyyMMddHHmmss")"
	Start-Transcript -Path "$PSScriptRoot\..\$SaveTo.txt" -Force
}

<#
	.Language Module
#>
Function Language
{
	param (
		[string]$Force,
		[switch]$Reset,
		[switch]$Auto
	)
	$Host.UI.RawUI.WindowTitle = "Yi's Solutions | Choose your country or region."

	if ($Reset) {
		$global:IsLang = $null
	}
	
	if ($Auto) {
		LanguageChange -lang (Get-Culture).Name
		RefreshLanguage
		return
	}

	if (-not ([string]::IsNullOrEmpty($Force))){
		LanguageChange -lang $Force
		RefreshLanguage
		return
	}
	
	if (([string]::IsNullOrEmpty($global:IsLang))){
		Clear-Host
		$eng = New-Object System.Management.Automation.Host.ChoiceDescription "&1 en-US", "eng"
		$chs = New-Object System.Management.Automation.Host.ChoiceDescription "&2 zh-CN", "chs"
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($eng, $chs)
		$title = '    Choose your country or region.'
		$message = "`n    North America`n[1] English ( United States )`n`n    Asia Pacific`n[2] 中文 ( 简体, 中国 )`n`n"
		$result = $host.ui.PromptForChoice($title, $message, $options, 0)
		switch ($result) {
			0 {
				LanguageChange -lang "en-US"
				RefreshLanguage
			}
			1 {
				LanguageChange -lang "zh-CN"
				RefreshLanguage
			}
		}
	} else {
		LanguageChange -lang $global:IsLang
	}
}

Function LanguageChange {
	param (
		[string]$lang
	)

	if (Test-Path "$PSScriptRoot\$($lang)\Yi.psd1" -PathType Leaf) {
		$global:IsLang = $lang
		Import-LocalizedData -BindingVariable Global:Lang -FileName "Yi.psd1" -UICulture $lang
	} else {
		if (Test-Path "$PSScriptRoot\en-US\Yi.psd1" -PathType Leaf) {
			$global:IsLang = "en-US"
			Import-LocalizedData -BindingVariable Global:Lang -FileName "Yi.psd1" -UICulture "en-US"
		} else {
			Clear-Host
			Write-Host "`n  There is no language pack locally, it will automatically exit after 6 seconds." -ForegroundColor Red
			Start-Sleep -s 6
			exit
		}
	}
}

Function RefreshLanguage {
	Remove-Module -Name Yi -Force -ErrorAction Ignore
	Import-Module -Name $PSScriptRoot\Yi.psd1 -PassThru -Force | Out-Null
	Language
}
# Language Module End

<#
	.Main interface
#>
Function Logo {
	param (
		$Title
	)
	Clear-Host
	$Host.UI.RawUI.WindowTitle = "Yi's Solutions | $($Title)"
	Write-Host "`n   Author: Yi ( http://fengyi.tel )

   From: Yi's Solutions
   buildstring: 6.0.0.1.bs_release.210226-1208`n"
}

Function Mainpage {
	Logo -Title $($lang.Mainpage)
	Write-Host "   $($lang.Mainpage)
   ---------------------------------------------------
    1. $($lang.Update)
    2. $($lang.Reset) $($lang.Mainname)
    3. $($lang.Delete) $($lang.Mainname)
    4. $($lang.RefreshLang)

  * A. $($lang.Oneclick) BCDEFGHI
    B. $($lang.ActivationKit)
    C. $($lang.DeskIcon)
    D. $($lang.Optimize) $($lang.System)
    E. $($lang.Optimize) $($lang.Service)
    F. $($lang.Instl) $($lang.Necessary)
    G. $($lang.Instl) $($lang.MostUsedSoftware)
    H. $($lang.Delete) $($lang.ComesWith)
    I. $($lang.Delete) $($lang.UninstallUWP)

    L. $($lang.SwitchLanguage)
    Q. $($lang.Exit)`n"

	$select = Read-Host "   $($lang.Choose)"
	switch ($select) {
		'1' { Update }
		'2' { Yi }
		'3' {
			Uninstall
			ToMainpage -wait 2
		}
		'4' {
			Refresh
			LanguageSetting
			ScheduledTaskSettings
			UninstallApps
			Permissions
		}
		'a' {
			ActivatePact -Force
			AddDesktopICON -Force
			Optimization -Force
			OptimizationService -Force
			Prerequisite -Force
			MostUsedSoftware -Force
			SystemSoftware -Force
			UninstallApps
			ToMainpage -wait 6
		}
		'b' { ActivatePact }
		'c' { AddDesktopICON }
		'd' { Optimization }
		'e' { OptimizationService }
		'f' { Prerequisite }
		'g' {
			MostUsedSoftware
			ToMainpage -wait 2
		}
		'h' { SystemSoftware }
		'i' {
			UninstallApps
			ToMainpage -wait 2
		}
		'l' {
			Language -Reset
			Mainpage
		}
		'q' { exit }
		default { Mainpage }
	}
}

Function ToMainpage {
	param(
		[int]$wait
	)

	if ($global:QUIT) {
		$global:QUIT = $False
		Write-Host $($lang.ToQuit -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		exit
	} else {
		Write-Host $($lang.ToMsg -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Mainpage
	}
}
# Main interface End

<#
	.Add Yi's Solutions
#>
Function Yi {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title $($lang.Reset)
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------
   - $($lang.ForceUpdate)
   - $($lang.VolumeLabel)
   - $($lang.Disable) $($lang.NetworkLocationWizard)
   - $($lang.AddTo) $($lang.Exclude)
   - $($lang.FixMainFolder)
   - $($lang.Authority)
   - $($lang.RefreshLang)
   - $($lang.AddTo) $($lang.DeskMenu)
   - $($lang.InstallFonts)
   - $($lang.SettingLangAndKeyboard)
   - $($lang.AddTo) $($lang.PlanTask) ( \Yi\isDark )"

	if ($Force) {
		#RestorePoint
		Update -Force -IsProcess
		YiStart -Force
		exit
	} else {
		$caption = "$($lang.Reset) '$($lang.Mainname)' ?"
		$message = "$($lang.Continue) (Y)`n$($lang.Cancel) (N)"
		$choices = @("&Yes","&No")
		$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription]
		$choices | ForEach-Object { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))}
		$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 0)
		Switch ($prompt)
		{
			0 {
				Update -Force -IsProcess
				YiStart
				ToMainpage -wait 6
			}
			1 {
				ToMainpage -wait 2
			}
		}
	}
}

Function YiStart {
	param (
		[switch]$Force
	)

	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue
	Unregister-ScheduledTask -TaskPath '\Yi\' -TaskName 'isDark' -Confirm:$false -ErrorAction SilentlyContinue

	Write-Host "`n   $($lang.VolumeLabel)"
	(New-Object -ComObject "Shell.Application").NameSpace($env:SystemDrive).Self.Name = "OS"

	Write-Host "`n   $($lang.Disable) $($lang.NetworkLocationWizard)"
	New-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" -Force -ErrorAction SilentlyContinue | Out-Null

	Write-Host "`n   $($lang.Exclude)"
	Add-MpPreference -ExclusionPath "$env:SystemDrive\Yi" -ErrorAction SilentlyContinue | Out-Null

	Write-Host "`n   $($lang.FixMainFolder)"
	if (Test-Path "$PSScriptRoot\..\AIO\DeskEdit.exe" -PathType Leaf) {
		Start-Process -FilePath "$PSScriptRoot\..\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi"" /S=.ShellClassInfo /L=IconResource=""$env:SystemDrive\Yi\Yi\icons\Yi.ico,0"""
	}
	LanguageSetting
	RefreshIconCache
	Permissions
	RefreshStart
	InstallFontsStart
	ScheduledTaskSettings

	if ($Force) { YiWelcome }
}

Function YiWelcome {
	$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
	$regValue = "powershell -Command ""Start-Process 'Powershell' -Argument '-File ""$($env:SystemDrive)\Yi\Yi\Yi.ps1""' -Verb RunAs"""
	if ((Test-Path $regPath)) {
		New-ItemProperty -Path $regPath -Name "Yi" -Value $regValue -PropertyType STRING -Force | Out-Null
	} else {
		New-Item -Path $regPath -Force | Out-Null
		New-ItemProperty -Path $regPath -Name "Yi" -Value $regValue -PropertyType STRING -Force | Out-Null
	}
}
# Yi End

<#
   .Uninstall
#>
Function Uninstall {
	Logo -Title "$($lang.Delete) $($lang.MainHisName)"
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormUn.Close()
	}
	$OK_Click = {
		$FormUn.Hide()
		$global:QUIT = $true
		if ($AllIcon.Checked) {
			Write-Host "   $($lang.Delete) $($lang.Redundant)" -ForegroundColor Green
			Write-Host "   - $($lang.Delete) $env:USERPROFILE\Desktop\$($lang.MainHisName).lnk"
			Remove-Item -Path "$env:USERPROFILE\Desktop\Bundled Solutions.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:USERPROFILE\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
			Write-Host "   - $($lang.Delete) $env:SystemDrive\Users\Public\Desktop\$($lang.MainHisName).lnk"
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\Bundled Solutions.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue

			$StartMenu = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\Yi's Solutions"
			Write-Host "   - $($lang.Delete) $($StartMenu)`n"
			RemoveTree -Path $StartMenu
			Start-Process -FilePath "$PSScriptRoot\..\AIO\syspin.exe" -WindowStyle Hidden -ArgumentList """$StartMenu\- $($lang.Mainpage) -.lnk"" ""51394""" -Wait
		}
		if ($ScheduledTasks.Checked) {
			Write-Host "   $($lang.Delete) $($lang.PlanTask) ( \Yi\Dark )`n" -ForegroundColor Green
			Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue
			Unregister-ScheduledTask -TaskPath '\Yi\' -TaskName 'isDark' -Confirm:$false -ErrorAction SilentlyContinue
		}
		if ($DeskMenu.Checked) {
			YiDeskMenu -Del
		}
		if ($Exclude.Checked) {
			Write-Host "   $($lang.Delete) $($lang.Exclude) ( $($env:SystemDrive)\Yi )`n" -ForegroundColor Green
			Remove-MpPreference -ExclusionPath "$env:SystemDrive\Yi"
		}
		if ($Restricted.Checked) {
			Write-Host "   $($lang.Restricted)`n" -ForegroundColor Green
			Set-ExecutionPolicy -ExecutionPolicy Restricted -Force -ErrorAction SilentlyContinue
		}
		if ($NextDelete.Checked) {
			Write-Host "   $($lang.NextDelete)`n" -ForegroundColor Green
			$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
			$regKey = "Clear Yi Folder"
			$regValue = "cmd.exe /c rd /s /q ""$($env:SystemDrive)\Yi"""
			if ((Test-Path $regPath)) {
				New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
			} else {
				New-Item -Path $regPath -Force | Out-Null
				New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
			}
		}
		if ($CleanAll.Checked) {
			Write-Host "   $($lang.Delete) $($lang.MainHisName) ( $($env:SystemDrive)\Yi )`n" -ForegroundColor Green
			RemoveTree -Path "$env:SystemDrive\Yi"
		}
		$FormUn.Close()
	}
	$FormUn            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = "$($lang.Delete) $($lang.MainHisName)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$AllIcon           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) $($lang.Redundant)"
		Checked        = $true
	}
	$ScheduledTasks    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) $($lang.PlanTask) ( \Yi\Dark )"
		Checked        = $true
	}
	$DeskMenu          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) $($lang.DeskMenu) ( Yi's Solutions )"
		Checked        = $true
	}
	$Exclude           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) $($lang.Exclude) ( $($env:SystemDrive)\Yi )"
		Checked        = $true
	}
	$Restricted        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.Restricted
		Checked        = $true
	}
	$NextDelete        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.NextDelete
		Checked        = $true
	}
	$CleanAll          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) $($lang.MainHisName)"
		Checked        = $true
	}
	$FormUn.controls.AddRange($Pane1)
	$FormUn.controls.AddRange($AllSel)
	$FormUn.controls.AddRange($AllClear)
	$FormUn.controls.AddRange($Start)
	$FormUn.controls.AddRange($Canel)
	$Pane1.controls.AddRange($AllIcon)
	$Pane1.controls.AddRange($ScheduledTasks)
	$Pane1.controls.AddRange($DeskMenu)
	$Pane1.controls.AddRange($Exclude)
	$Pane1.controls.AddRange($Restricted)
	$Pane1.controls.AddRange($NextDelete)
	$Pane1.controls.AddRange($CleanAll)
	$FormUn.FormBorderStyle = 'Fixed3D'
	$FormUn.ShowDialog() | Out-Null
}

<#
   .Hide Permissions module
#>
$GroupFolder = @(
	"Yi"
	"Fonts"
	"00\AIO\rarreg.key"
	"00\AIO\auth.dll"
	"10\TFTPBoot"
	"10\tftpd32.ini"
	"10\GhostSrv_ZH.dll"
	"10\GhostExp_ZH.dll"
	"30\AdvancedIPScanner"
	"30\VLC"
	"30\360DrvMgr"
	"30\DriverGenius"
	"30\DriverTalent"
	"30\Beyond Compare"
	"30\DiskGenius"
	"30\DnsJumper"
	"30\EasyBCD"
	"30\FastCopy"
	"30\RegeditX"
	"30\RegShot"
	"30\rufus"
	"30\ventoy"
	"30\WinNTSetup"
	"30\WipeFile"
	"30\Everything"
	"30\SDCardFormatter"
	"30\TopMost"
	"40\AIDA64"
	"40\ASSSDBenchmark"
	"40\CPU-Z"
	"40\FurMark"
	"40\GPU-Z"
	"40\GPUShark"
	"40\Hard Disk Sentinel"
	"40\HDDScan"
	"40\HDSpeed"
	"40\HDTune"
	"40\MaxxMEM2"
	"40\MemTest"
	"40\TxBENCH"
	"40\Victoria"
	"50\AutoRuns"
	"50\DbgView"
	"50\DriverView"
	"50\FullEventLogView"
	"50\ProcessExplorer"
	"50\ProcessMonitor"
	"50\PUTTY"
	"50\Stud_PE"
	"50\TCPView"
	"60\DefenderControl"
	"60\fab"
	"60\Wub"
	"70\Radmin"
	"70\TeamViewer"
	"70\TTVnc"
	"70\VNCView"
	"70\WinBox"
	"70\AnyDesk"
)

$GroupFile = @(
	"Yi\Modules\en-US\instl.ps1"
	"Yi\Modules\zh-CN\instl.ps1"
)

Function Permissions {
	Write-Host "`n   $($lang.Authority)`n"
	Set-Location "$PSScriptRoot\..\"
	foreach ($nsf in $GroupFolder) {
		Set-ItemProperty -Path "$env:SystemDrive\Yi\$nsf" -Name Attributes -Value Hidden -ErrorAction SilentlyContinue
	}

	foreach ($nsf in $GroupFile) {
		Set-ItemProperty -Path "$env:SystemDrive\Yi\$nsf" -Name Attributes -Value "ReadOnly" -ErrorAction SilentlyContinue
	}
}
# Hide Permissions module End

<#
	.Refresh module
#>
Function Refresh {
	param(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title $($lang.RefreshLang)

	If ($Force) {
		RefreshStart
	} else {
		Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------
   1. $($lang.DelOldShortcut)
   2. $($lang.VerifyShortcut)`n"

		Write-Host "   $($lang.Refresh)" -ForegroundColor Green
		$caption = $lang.RefreshConfirm
		$message = "$($lang.Continue) (Y)`n$($lang.Cancel) (N)"
		$choices = @("&Yes","&No")
		$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription]
		$choices | ForEach-Object { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))}
		$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 0)
		Switch ($prompt)
		{
			0 {
				RefreshStart
				ToMainpage -wait 6
			}
			1 {
				ToMainpage -wait 2
			}
		}
	}
}
# Refresh module End

Function RefreshStart {
	YiDeskMenu -Reset

	Write-Host "   $($lang.AddTo) $($lang.DeskIcon)"
	Set-Location "$env:SystemDrive\Yi"
	$StartMenu = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\Yi's Solutions"
	Start-Process -FilePath "Yi\AIO\syspin.exe" -WindowStyle Hidden -ArgumentList """$StartMenu\- $($lang.Mainpage) -.lnk"" ""51394""" -Wait
	Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\Bundled Solutions.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "00\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "30\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "40\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "50\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "60\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "70\*.lnk" -ErrorAction SilentlyContinue
	RemoveTree -Path $StartMenu
	CheckCatalog -chkpath $StartMenu

	if (Test-Path "Yi" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi"" /S=.ShellClassInfo /L=LocalizedResourceName=""Yi's Solutions"""			
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Users\Public\Desktop\$($lang.MainHisName).lnk"" /a:c /t:""$env:SystemDrive\Yi"" /i:""$env:SystemDrive\Yi\Yi\icons\Yi.Gift.ico""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\- $($lang.Location) -.lnk"" /a:c /t:""$env:SystemDrive\Yi"" /i:""$env:SystemDrive\Yi\Yi\icons\Yi.Gift.ico""" -WindowStyle Hidden

		if (Test-Path -Path "Yi\Yi.ps1") {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\- $($lang.Mainpage) -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$env:SystemDrive\Yi\Yi\Yi.ps1\""' -Verb RunAs"" /i:""$env:SystemDrive\Yi\Yi\icons\MainPanel.ico""" -WindowStyle Hidden -Wait
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\- $($lang.InstlOffice) -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$env:SystemDrive\Yi\Yi\Yi.ps1\"" -Functions \\\""WPS -Quit\\\""' -Verb RunAs"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\- $($lang.Mainpage) -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$env:SystemDrive\Yi\Yi\Yi.ps1\""' -Verb RunAs"" /i:""$env:SystemDrive\Yi\Yi\icons\MainPanel.ico""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\syspin.exe" -ArgumentList """$StartMenu\- $($lang.Mainpage) -.lnk"" ""51201""" -Wait -WindowStyle Hidden
		}
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\Instl.ps1") {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\- $($lang.EditAndInstl) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\instl.ps1""" -WindowStyle Hidden
		} else {
			if (Test-Path -Path "Yi\Modules\en-US\Instl.ps1") {
				Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\- $($lang.EditAndInstl) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\en-US\instl.ps1""" -WindowStyle Hidden
			}
		}
	}

	if (Test-Path "00" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\00"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.InstlPacker)"""
	}

	if (Test-Path "10" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.BakRestore)"
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\10"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.BakRestore)"""
		if (Test-Path -Path "10\Ghost64.exe" ) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Symantec Ghost.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\Ghost64.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\Ghost64.exe""" -WindowStyle Hidden }
		if (Test-Path -Path "10\GhostExp.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Symantec Ghost Explorer.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\GhostExp.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\GhostExp.exe""" -WindowStyle Hidden }
		if (Test-Path -Path "10\GhostSrv.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Symantec GhostCast Server.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\GhostSrv.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\GhostSrv.exe""" -WindowStyle Hidden }
		if (Test-Path -Path "10\tftpd64.exe" ) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Tftpd.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\tftpd64.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\tftpd64.exe""" -WindowStyle Hidden }
	}

	if (Test-Path "20" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\20"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.ActivationKit)"""
	}

	if (Test-Path "30" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.MostUsedSoftware)"
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\30"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.MostUsedSoftware)"""
		if (Test-Path "30\AdvancedIPScanner" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Advanced IP Scanner.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\AdvancedIPScanner\advanced_ip_scanner.exe"" /w:""$env:SystemDrive\Yi\30\AdvancedIPScanner"" /i:""$env:SystemDrive\Yi\30\AdvancedIPScanner\advanced_ip_scanner.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Advanced IP Scanner.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\AdvancedIPScanner\advanced_ip_scanner.exe"" /w:""$env:SystemDrive\Yi\30\AdvancedIPScanner"" /i:""$env:SystemDrive\Yi\30\AdvancedIPScanner\advanced_ip_scanner.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\VLC" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\VLC media player.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\VLC\vlc.exe"" /w:""$env:SystemDrive\Yi\30\VLC"" /i:""$env:SystemDrive\Yi\30\VLC\vlc.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\VLC media player.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\VLC\vlc.exe"" /w:""$env:SystemDrive\Yi\30\VLC"" /i:""$env:SystemDrive\Yi\30\VLC\vlc.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\360DrvMgr" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\$($lang.DrvMgr).lnk"" /a:c /t:""$env:SystemDrive\Yi\30\360DrvMgr\360DrvMgr.exe"" /w:""$env:SystemDrive\Yi\30\360DrvMgr"" /i:""$env:SystemDrive\Yi\30\360DrvMgr\360DrvMgr.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\$($lang.DrvMgr).lnk"" /a:c /t:""$env:SystemDrive\Yi\30\360DrvMgr\360DrvMgr.exe"" /w:""$env:SystemDrive\Yi\30\360DrvMgr"" /i:""$env:SystemDrive\Yi\30\360DrvMgr\360DrvMgr.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\DriverTalent" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Driver Updater.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DriverTalent\Driver Talent.exe"" /w:""$env:SystemDrive\Yi\30\DriverTalent"" /i:""$env:SystemDrive\Yi\30\DriverTalent\Driver Talent.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Driver Updater.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DriverTalent\Driver Talent.exe"" /w:""$env:SystemDrive\Yi\30\DriverTalent"" /i:""$env:SystemDrive\Yi\30\DriverTalent\Driver Talent.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\DriverGenius" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\$($lang.DriverGenius).lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DriverGenius\DriverGenius.exe"" /w:""$env:SystemDrive\Yi\30\DriverGenius"" /i:""$env:SystemDrive\Yi\30\DriverGenius\DriverGenius.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\$($lang.DriverGenius).lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DriverGenius\DriverGenius.exe"" /w:""$env:SystemDrive\Yi\30\DriverGenius"" /i:""$env:SystemDrive\Yi\30\DriverGenius\DriverGenius.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\DiskGenius" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\DiskGenius.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DiskGenius\Diskgenius.bat"" /w:""$env:SystemDrive\Yi\30\DiskGenius"" /i:""$env:SystemDrive\Yi\30\DiskGenius\Diskgenius.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\DiskGenius.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DiskGenius\Diskgenius.bat"" /w:""$env:SystemDrive\Yi\30\DiskGenius"" /i:""$env:SystemDrive\Yi\30\DiskGenius\Diskgenius.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "30\WinNTSetup" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\WinNTSetup.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\WinNTSetup\WinNTSetup.exe"" /w:""$env:SystemDrive\Yi\30\WinNTSetup"" /i:""$env:SystemDrive\Yi\30\WinNTSetup\WinNTSetup.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\WinNTSetup.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\WinNTSetup\WinNTSetup.exe"" /w:""$env:SystemDrive\Yi\30\WinNTSetup"" /i:""$env:SystemDrive\Yi\30\WinNTSetup\WinNTSetup.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\rufus" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Rufus.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\rufus\rufus.bat"" /w:""$env:SystemDrive\Yi\30\rufus"" /i:""$env:SystemDrive\Yi\30\rufus\rufus.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Rufus.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\rufus\rufus.bat"" /w:""$env:SystemDrive\Yi\30\rufus"" /i:""$env:SystemDrive\Yi\30\rufus\rufus.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "30\FastCopy" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\FastCopy.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\FastCopy\FastCopy.bat"" /w:""$env:SystemDrive\Yi\30\FastCopy"" /i:""$env:SystemDrive\Yi\30\FastCopy\FastCopy.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\FastCopy.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\FastCopy\FastCopy.bat"" /w:""$env:SystemDrive\Yi\30\FastCopy"" /i:""$env:SystemDrive\Yi\30\FastCopy\FastCopy.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "30\DnsJumper" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\DNS Jumper.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DnsJumper\DnsJumper.bat"" /w:""$env:SystemDrive\Yi\30\DnsJumper"" /i:""$env:SystemDrive\Yi\30\DnsJumper\DnsJumper.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\DNS Jumper.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DnsJumper\DnsJumper.bat"" /w:""$env:SystemDrive\Yi\30\DnsJumper"" /i:""$env:SystemDrive\Yi\30\DnsJumper\DnsJumper.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "30\EasyBCD" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\EasyBCD.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\EasyBCD\EasyBCD.exe"" /w:""$env:SystemDrive\Yi\30\EasyBCD"" /i:""$env:SystemDrive\Yi\30\EasyBCD\EasyBCD.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\EasyBCD.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\EasyBCD\EasyBCD.exe"" /w:""$env:SystemDrive\Yi\30\EasyBCD"" /i:""$env:SystemDrive\Yi\30\EasyBCD\EasyBCD.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\RegeditX" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\RegEditX.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\RegeditX\RegEditX.exe"" /w:""$env:SystemDrive\Yi\30\RegeditX"" /i:""$env:SystemDrive\Yi\30\RegeditX\RegEditX.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\RegEditX.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\RegeditX\RegEditX.exe"" /w:""$env:SystemDrive\Yi\30\RegeditX"" /i:""$env:SystemDrive\Yi\30\RegeditX\RegEditX.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\RegShot" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\RegShot.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\RegShot\Regshot.bat"" /w:""$env:SystemDrive\Yi\30\RegShot"" /i:""$env:SystemDrive\Yi\30\RegShot\Regshot.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\RegShot.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\RegShot\Regshot.bat"" /w:""$env:SystemDrive\Yi\30\RegShot"" /i:""$env:SystemDrive\Yi\30\RegShot\Regshot.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "30\Beyond Compare" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Beyond Compare.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\Beyond Compare\BCompare.bat"" /w:""$env:SystemDrive\Yi\30\Beyond Compare"" /i:""$env:SystemDrive\Yi\30\Beyond Compare\BComparePortable.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Beyond Compare.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\Beyond Compare\BCompare.bat"" /w:""$env:SystemDrive\Yi\30\Beyond Compare"" /i:""$env:SystemDrive\Yi\30\Beyond Compare\BComparePortable.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "30\WipeFile" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\WipeFile.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\WipeFile\WipeFile.exe"" /w:""$env:SystemDrive\Yi\30\WipeFile"" /i:""$env:SystemDrive\Yi\30\WipeFile\WipeFile.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\WipeFile.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\WipeFile\WipeFile.exe"" /w:""$env:SystemDrive\Yi\30\WipeFile"" /i:""$env:SystemDrive\Yi\30\WipeFile\WipeFile.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\Everything" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Everything.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\Everything\Everything.exe"" /w:""$env:SystemDrive\Yi\30\Everything"" /i:""$env:SystemDrive\Yi\30\Everything\Everything.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Everything.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\Everything\Everything.exe"" /w:""$env:SystemDrive\Yi\30\Everything"" /i:""$env:SystemDrive\Yi\30\Everything\Everything.exe""" -WindowStyle Hidden
		}
		if (Test-Path "30\SDCardFormatter" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\SD Card Formatter.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\SDCardFormatter\SDCardFormatter.bat"" /w:""$env:SystemDrive\Yi\30\SDCardFormatter"" /i:""$env:SystemDrive\Yi\30\SDCardFormatter\SDCardFormatter.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\SD Card Formatter.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\SDCardFormatter\SDCardFormatter.bat"" /w:""$env:SystemDrive\Yi\30\SDCardFormatter"" /i:""$env:SystemDrive\Yi\30\SDCardFormatter\SDCardFormatter.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "30\TopMost" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\TopMost.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\TopMost\TopMost.exe"" /w:""$env:SystemDrive\Yi\30\TopMost"" /i:""$env:SystemDrive\Yi\30\TopMost\TopMost.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\TopMost.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\TopMost\TopMost.exe"" /w:""$env:SystemDrive\Yi\30\TopMost"" /i:""$env:SystemDrive\Yi\30\TopMost\TopMost.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path "40" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.HardwareDetection)"
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\40"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.HardwareDetection)"""

		if (Test-Path "40\AIDA64" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\AIDA64.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\AIDA64\aida64.exe"" /w:""$env:SystemDrive\Yi\40\AIDA64"" /i:""$env:SystemDrive\Yi\40\AIDA64\aida64.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\AIDA64.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\AIDA64\aida64.exe"" /w:""$env:SystemDrive\Yi\40\AIDA64"" /i:""$env:SystemDrive\Yi\40\AIDA64\aida64.exe""" -WindowStyle Hidden
		}
		if (Test-Path "40\ASSSDBenchmark" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\AS SSD Benchmark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\ASSSDBenchmark\ASSSDBenchmark.bat"" /w:""$env:SystemDrive\Yi\40\ASSSDBenchmark"" /i:""$env:SystemDrive\Yi\40\ASSSDBenchmark\ASSSDBenchmark.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\AS SSD Benchmark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\ASSSDBenchmark\ASSSDBenchmark.bat"" /w:""$env:SystemDrive\Yi\40\ASSSDBenchmark"" /i:""$env:SystemDrive\Yi\40\ASSSDBenchmark\ASSSDBenchmark.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "40\CPU-Z" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\CPU-Z.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\CPU-Z\cpu-z.bat"" /w:""$env:SystemDrive\Yi\40\CPU-Z"" /i:""$env:SystemDrive\Yi\40\CPU-Z\cpu-z.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\CPU-Z.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\CPU-Z\cpu-z.bat"" /w:""$env:SystemDrive\Yi\40\CPU-Z"" /i:""$env:SystemDrive\Yi\40\CPU-Z\cpu-z.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "40\FurMark" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\FurMark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\FurMark\FurMark.exe"" /w:""$env:SystemDrive\Yi\40\FurMark"" /i:""$env:SystemDrive\Yi\40\FurMark\FurMark.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\FurMark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\FurMark\FurMark.exe"" /w:""$env:SystemDrive\Yi\40\FurMark"" /i:""$env:SystemDrive\Yi\40\FurMark\FurMark.exe""" -WindowStyle Hidden
		}
		if (Test-Path "40\GPUShark" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\GPUShark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\GPUShark\GPUShark.exe"" /w:""$env:SystemDrive\Yi\40\GPUShark"" /i:""$env:SystemDrive\Yi\40\GPUShark\GPUShark.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\GPUShark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\GPUShark\GPUShark.exe"" /w:""$env:SystemDrive\Yi\40\GPUShark"" /i:""$env:SystemDrive\Yi\40\GPUShark\GPUShark.exe""" -WindowStyle Hidden
		}
		if (Test-Path "40\GPU-Z" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\GPU-Z.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\GPU-Z\GPU-Z.bat"" /w:""$env:SystemDrive\Yi\40\GPU-Z"" /i:""$env:SystemDrive\Yi\40\GPU-Z\GPU-Z.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\GPU-Z.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\GPU-Z\GPU-Z.bat"" /w:""$env:SystemDrive\Yi\40\GPU-Z"" /i:""$env:SystemDrive\Yi\40\GPU-Z\GPU-Z.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "40\HDDScan" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\HDDScan.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDDScan\HDDScan.exe"" /w:""$env:SystemDrive\Yi\40\HDDScan"" /i:""$env:SystemDrive\Yi\40\HDDScan\HDDScan.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\HDDScan.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDDScan\HDDScan.exe"" /w:""$env:SystemDrive\Yi\40\HDDScan"" /i:""$env:SystemDrive\Yi\40\HDDScan\HDDScan.exe""" -WindowStyle Hidden
		}
		if (Test-Path "40\Hard Disk Sentinel" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\Hard Disk Sentinel.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\Hard Disk Sentinel\HDSentinel.exe"" /w:""$env:SystemDrive\Yi\40\Hard Disk Sentinel"" /i:""$env:SystemDrive\Yi\40\Hard Disk Sentinel\HDSentinel.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\Hard Disk Sentinel.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\Hard Disk Sentinel\HDSentinel.exe"" /w:""$env:SystemDrive\Yi\40\Hard Disk Sentinel"" /i:""$env:SystemDrive\Yi\40\Hard Disk Sentinel\HDSentinel.exe""" -WindowStyle Hidden
		}
		if (Test-Path "40\HDSpeed" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\HDSpeed.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDSpeed\HDSpeed.bat"" /w:""$env:SystemDrive\Yi\40\HDSpeed"" /i:""$env:SystemDrive\Yi\40\HDSpeed\HDSpeed.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\HDSpeed.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDSpeed\HDSpeed.bat"" /w:""$env:SystemDrive\Yi\40\HDSpeed"" /i:""$env:SystemDrive\Yi\40\HDSpeed\HDSpeed.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "40\MaxxMEM2" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\MaxxMEM2.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MaxxMEM2\MaxxMEM2.exe"" /w:""$env:SystemDrive\Yi\40\MaxxMEM2"" /i:""$env:SystemDrive\Yi\40\MaxxMEM2\MaxxMEM2.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\MaxxMEM2.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MaxxMEM2\MaxxMEM2.exe"" /w:""$env:SystemDrive\Yi\40\MaxxMEM2"" /i:""$env:SystemDrive\Yi\40\MaxxMEM2\MaxxMEM2.exe""" -WindowStyle Hidden
		}
		if (Test-Path "40\TxBENCH" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\TxBENCH.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\TxBENCH\TxBENCH.exe"" /w:""$env:SystemDrive\Yi\40\TxBENCH"" /i:""$env:SystemDrive\Yi\40\TxBENCH\TxBENCH.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\TxBENCH.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\TxBENCH\TxBENCH.exe"" /w:""$env:SystemDrive\Yi\40\TxBENCH"" /i:""$env:SystemDrive\Yi\40\TxBENCH\TxBENCH.exe""" -WindowStyle Hidden
		}
		if (Test-Path "40\Victoria" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\Victoria.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\Victoria\Victoria.bat"" /w:""$env:SystemDrive\Yi\40\Victoria"" /i:""$env:SystemDrive\Yi\40\Victoria\Victoria.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\Victoria.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\Victoria\Victoria.bat"" /w:""$env:SystemDrive\Yi\40\Victoria"" /i:""$env:SystemDrive\Yi\40\Victoria\Victoria.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path -path "40\MemTest\MemTest64.exe") {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\MemTest64.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\MemTest64.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\MemTest64.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\MemTest64.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\MemTest64.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\MemTest64.exe""" -WindowStyle Hidden
		}
		if (Test-Path -path "40\MemTest\MTPclassic.exe") {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\memTestPro Classic.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\MTPclassic.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\MTPclassic.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\memTestPro Classic.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\MTPclassic.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\MTPclassic.exe""" -WindowStyle Hidden
		}
		if (Test-Path -path "40\MemTest\memTestPro.exe") {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\memTestPro.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\memTestPro.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\memTestPro.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\memTestPro.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\memTestPro.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\memTestPro.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path "50" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.Debugging)"
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\50"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.Debugging)"""

		if (Test-Path "50\AutoRuns" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\AutoRuns.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\AutoRuns\AutoRuns.exe"" /w:""$env:SystemDrive\Yi\50\AutoRuns"" /i:""$env:SystemDrive\Yi\50\AutoRuns\AutoRuns.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\AutoRuns.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\AutoRuns\AutoRuns.exe"" /w:""$env:SystemDrive\Yi\50\AutoRuns"" /i:""$env:SystemDrive\Yi\50\AutoRuns\AutoRuns.exe""" -WindowStyle Hidden
		}
		if (Test-Path "50\DbgView" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\DbgView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\DbgView\Dbgview.exe"" /w:""$env:SystemDrive\Yi\50\DbgView"" /i:""$env:SystemDrive\Yi\50\DbgView\Dbgview.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\DbgView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\DbgView\Dbgview.exe"" /w:""$env:SystemDrive\Yi\50\DbgView"" /i:""$env:SystemDrive\Yi\50\DbgView\Dbgview.exe""" -WindowStyle Hidden
		}
		if (Test-Path "50\DriverView" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\DriverView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\DriverView\DriverView.exe"" /w:""$env:SystemDrive\Yi\50\DriverView"" /i:""$env:SystemDrive\Yi\50\DriverView\DriverView.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\DriverView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\DriverView\DriverView.exe"" /w:""$env:SystemDrive\Yi\50\DriverView"" /i:""$env:SystemDrive\Yi\50\DriverView\DriverView.exe""" -WindowStyle Hidden
		}
		if (Test-Path "50\FullEventLogView" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\FullEventLogView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\FullEventLogView\FullEventLogView.exe"" /w:""$env:SystemDrive\Yi\50\FullEventLogView"" /i:""$env:SystemDrive\Yi\50\FullEventLogView\FullEventLogView.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\FullEventLogView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\FullEventLogView\FullEventLogView.exe"" /w:""$env:SystemDrive\Yi\50\FullEventLogView"" /i:""$env:SystemDrive\Yi\50\FullEventLogView\FullEventLogView.exe""" -WindowStyle Hidden
		}
		if (Test-Path "50\ProcessExplorer" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\Process Explorer.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\ProcessExplorer\ProcessExplorer.exe"" /w:""$env:SystemDrive\Yi\50\ProcessExplorer"" /i:""$env:SystemDrive\Yi\50\ProcessExplorer\ProcessExplorer.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\Process Explorer.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\ProcessExplorer\ProcessExplorer.exe"" /w:""$env:SystemDrive\Yi\50\ProcessExplorer"" /i:""$env:SystemDrive\Yi\50\ProcessExplorer\ProcessExplorer.exe""" -WindowStyle Hidden
		}
		if (Test-Path "50\ProcessMonitor" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\Process Monitor.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\ProcessMonitor\Procmon.exe"" /w:""$env:SystemDrive\Yi\50\ProcessMonitor"" /i:""$env:SystemDrive\Yi\50\ProcessMonitor\Procmon.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\Process Monitor.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\ProcessMonitor\Procmon.exe"" /w:""$env:SystemDrive\Yi\50\ProcessMonitor"" /i:""$env:SystemDrive\Yi\50\ProcessMonitor\Procmon.exe""" -WindowStyle Hidden
		}
		if (Test-Path "50\PUTTY" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\PUTTY.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\PUTTY\putty.exe"" /w:""$env:SystemDrive\Yi\50\PUTTY"" /i:""$env:SystemDrive\Yi\50\PUTTY\putty.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\PUTTY.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\PUTTY\putty.exe"" /w:""$env:SystemDrive\Yi\50\PUTTY"" /i:""$env:SystemDrive\Yi\50\PUTTY\putty.exe""" -WindowStyle Hidden
		}
		if (Test-Path "50\TCPView" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\TCPView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\TCPView\Tcpview.exe"" /w:""$env:SystemDrive\Yi\50\TCPView"" /i:""$env:SystemDrive\Yi\50\TCPView\Tcpview.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\TCPView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\TCPView\Tcpview.exe"" /w:""$env:SystemDrive\Yi\50\TCPView"" /i:""$env:SystemDrive\Yi\50\TCPView\Tcpview.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path "60" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.SetupTool)"
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\60"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.SetupTool)"""

		CheckCatalog -chkpath "$StartMenu\$($lang.SetupTool)"
		if (Test-Path "60\DefenderControl" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\- $($lang.DefenderControl) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.bat"" /w:""$env:SystemDrive\Yi\60\DefenderControl"" /i:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.SetupTool)\$($lang.DefenderControl).lnk"" /a:c /t:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.bat"" /w:""$env:SystemDrive\Yi\60\DefenderControl"" /i:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "60\Wub" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\- $($lang.Wub) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\60\Wub\Wub.bat"" /w:""$env:SystemDrive\Yi\60\Wub"" /i:""$env:SystemDrive\Yi\60\Wub\Wub.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.SetupTool)\$($lang.Wub).lnk"" /a:c /t:""$env:SystemDrive\Yi\60\Wub\Wub.bat"" /w:""$env:SystemDrive\Yi\60\Wub"" /i:""$env:SystemDrive\Yi\60\Wub\Wub.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "60\fab" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\- $($lang.Fab) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\60\fab\Fab.bat"" /w:""$env:SystemDrive\Yi\60\fab"" /i:""$env:SystemDrive\Yi\60\fab\Fab.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.SetupTool)\$($lang.Fab).lnk"" /a:c /t:""$env:SystemDrive\Yi\60\fab\Fab.bat"" /w:""$env:SystemDrive\Yi\60\fab"" /i:""$env:SystemDrive\Yi\60\fab\Fab.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\60\G.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\$($lang.StRemote).lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\60\G.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\60\H.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\$($lang.StPwd).lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\60\H.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\60\I.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\$($lang.StSMB).lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\60\I.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\60\J.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\$($lang.StSafe).lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\60\J.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\60\N.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\$($lang.StDelHide).lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\60\N.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\60\P.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\$($lang.StSelAdv).lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\60\P.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
		if (Test-Path -Path "Yi\Modules\$((Get-Culture).Name)\60\Q.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\$($lang.StPS).lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\Modules\$((Get-Culture).Name)\60\Q.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	}

	if (Test-Path "70" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.RemoteTool)"
		Start-Process -FilePath "Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi\70"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.RemoteTool)"""

		if (Test-Path "70\AnyDesk" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\AnyDesk.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\AnyDesk\AnyDesk.exe"" /w:""$env:SystemDrive\Yi\70\AnyDesk"" /i:""$env:SystemDrive\Yi\70\AnyDesk\AnyDesk.exe" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\AnyDesk.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\AnyDesk\AnyDesk.exe"" /w:""$env:SystemDrive\Yi\70\AnyDesk"" /i:""$env:SystemDrive\Yi\70\AnyDesk\AnyDesk.exe" -WindowStyle Hidden
		}
		if (Test-Path "70\Radmin" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\Radmin.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\Radmin\Radmin.exe"" /w:""$env:SystemDrive\Yi\70\Radmin"" /i:""$env:SystemDrive\Yi\70\Radmin\Radmin.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\Radmin.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\Radmin\Radmin.exe"" /w:""$env:SystemDrive\Yi\70\Radmin"" /i:""$env:SystemDrive\Yi\70\Radmin\Radmin.exe""" -WindowStyle Hidden
		}
		if (Test-Path "70\TeamViewer" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\TeamViewer.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TeamViewer\TeamViewer.exe"" /w:""$env:SystemDrive\Yi\70\TeamViewer"" /i:""$env:SystemDrive\Yi\70\TeamViewer\TeamViewer.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\TeamViewer.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TeamViewer\TeamViewer.exe"" /w:""$env:SystemDrive\Yi\70\TeamViewer"" /i:""$env:SystemDrive\Yi\70\TeamViewer\TeamViewer.exe""" -WindowStyle Hidden
		}
		if (Test-Path "70\TTVnc" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\TTC.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TTVnc\TTClient.exe"" /w:""$env:SystemDrive\Yi\70\TTVnc"" /i:""$env:SystemDrive\Yi\70\TTVnc\TTClient.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\TTC.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TTVnc\TTClient.exe"" /w:""$env:SystemDrive\Yi\70\TTVnc"" /i:""$env:SystemDrive\Yi\70\TTVnc\TTClient.exe""" -WindowStyle Hidden
		}
		if (Test-Path "70\TTVnc" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\TTS.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TTVnc\TTServer.exe"" /w:""$env:SystemDrive\Yi\70\TTVnc"" /i:""$env:SystemDrive\Yi\70\TTVnc\TTServer.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\TTS.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TTVnc\TTServer.exe"" /w:""$env:SystemDrive\Yi\70\TTVnc"" /i:""$env:SystemDrive\Yi\70\TTVnc\TTServer.exe""" -WindowStyle Hidden
		}
		if (Test-Path "70\VNCView" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\VNC Viewer.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\VNCView\VNCView.exe"" /w:""$env:SystemDrive\Yi\70\VNCView"" /i:""$env:SystemDrive\Yi\70\VNCView\VNCView.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\VNC Viewer.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\VNCView\VNCView.exe"" /w:""$env:SystemDrive\Yi\70\VNCView"" /i:""$env:SystemDrive\Yi\70\VNCView\VNCView.exe""" -WindowStyle Hidden
		}
		if (Test-Path "70\WinBox" -PathType Container) {
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\WinBox.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\WinBox\winbox.exe"" /w:""$env:SystemDrive\Yi\70\WinBox"" /i:""$env:SystemDrive\Yi\70\WinBox\winbox.exe""" -WindowStyle Hidden
			Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\WinBox.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\WinBox\winbox.exe"" /w:""$env:SystemDrive\Yi\70\WinBox"" /i:""$env:SystemDrive\Yi\70\WinBox\winbox.exe""" -WindowStyle Hidden
		}
	}
}

Function YiDeskMenu {
	param
	(
		[switch]$Add,
		[switch]$Del,
		[switch]$Reset
	)

	Write-Host "   $($lang.DeskMenu)" -ForegroundColor Green

	if ($Reset) {
		DisableDeskMenu
		EnableDeskMenu
	}

	if ($Del) { DisableDeskMenu }
	if ($Add) { EnableDeskMenu }

	Write-host ""
}

Function DisableDeskMenu {
	Write-Host "   - $($lang.Delete) $($lang.DeskMenu)"
	Remove-Item -Path "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.MainPanel" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue | Out-Null
}

Function EnableDeskMenu {
	param
	(
		[switch]$Hide
	)

	Write-Host "   - $($lang.AddTo) $($lang.DeskMenu)"
	New-Item "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'MUIVerb' -Value "&Yi's Solutions" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\Yi.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'SeparatorAfter' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Position' -Value 'Top' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	if ($Hide)
	{
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Extended' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.MainPanel" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.MainPanel\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.MainPanel' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\MainPanel.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.MainPanel' -Name 'MUIVerb' -Value $($lang.Mainpage) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.MainPanel\command' -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$($env:SystemDrive)\Yi\Yi\Yi.ps1""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\Yi.Gift.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir' -Name 'MUIVerb' -Value $($lang.Location) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir\command' -Name '(default)' -Value "explorer $($env:SystemDrive)\Yi" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language\command" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\refresh.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language' -Name 'MUIVerb' -Value $($lang.RefreshLang) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language\command' -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$($env:SystemDrive)\Yi\Yi\Yi.ps1"" -Functions \""Refresh -Quit\""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\reset.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg' -Name 'MUIVerb' -Value $($lang.Reset) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg\command' -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$($env:SystemDrive)\Yi\Yi\Yi.ps1"" -Functions \""Yi -Quit\""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\update.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update' -Name 'MUIVerb' -Value $($lang.Update) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update\command' -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$($env:SystemDrive)\Yi\Yi\Yi.ps1"" -Functions \""Update -Quit\""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\about.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About' -Name 'MUIVerb' -Value $($lang.About) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About\command' -Name '(default)' -Value "explorer ""https://fengyi.tel/go/os""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'MUIVerb' -Value "&Yi's Solutions" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\Yi.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'SeparatorAfter' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Position' -Value 'Top' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'SubCommands' -Value 'Yi.MainPanel;Yi.Dir;|;Yi.Update;Yi.Language;Yi.Reg;|;Yi.About;' -PropertyType String -Force -ea SilentlyContinue | Out-Null
}
# Right-click menu module End

<#
	.Install font module
#>
# Please set the directory to search
$DirectoryStructure = @(
	"Yi\Fonts"
	"Fonts"
)

# Please set the search file type
$type = @(
	"*.otf"
	"*.ttf"
)

Function InstallFonts {
	param (
		[string]$fontFile,
		[string]$shortname
	)
	$Host.UI.RawUI.WindowTitle = "Yi's Solutions | $($lang.InstallFonts)"

	if ((Test-Path "$env:SystemDrive\Windows\fonts\$shortname") -or 
		(Test-Path "$env:LOCALAPPDATA\Microsoft\Windows\Fonts\$shortname")) {
		Write-Host "   '$($lang.ItInstalled)' - $($fontFile)" -ForegroundColor Red
	} else {
		Write-Host "   '$($lang.installing)' - $($fontFile)" -ForegroundColor Green

		(New-Object -ComObject Shell.Application).Namespace(0x14).CopyHere($_.FullName) | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

Function InstallFontsStart {
	Write-host "`n   $($lang.InstallFonts)`n   ---------------------------------------------------"

	$drives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[a-z]$'
	foreach ($drive in $drives){
		foreach ($nsf in $DirectoryStructure) {
			Get-ChildItem "${drive}:\${nsf}" -Recurse -Include ($type) -ErrorAction SilentlyContinue | Foreach-Object {
				InstallFonts -fontFile $_.FullName -shortname $_.Name
			}
		}
	}
	RemoveTree -Path "$($env:SystemDrive)\Yi\Fonts"
}
# Install font module End

<#
	.Language keyboard setting module
#>
Function LanguageSetting {
	switch ((Get-Culture).Name) {
		'zh-CN' {
			Write-Host "`n   $($lang.SetLang)$((Get-Culture).Name)"
			Write-Host "   $($lang.KeyboardSequence)$($lang.Pinyi), $($lang.Wubi), $($lang.English) ( $($lang.Default) )"
			$langlist = New-WinUserLanguageList zh-CN
			$langlist[0].InputMethodTips.Clear()
			$langlist[0].InputMethodTips.add('0804:{81D4E9C9-1D3B-41BC-9E6C-4B40BF79E35E}{FA550B04-5AD7-411f-A5AC-CA038EC515D7}')
			$langlist[0].InputMethodTips.add('0804:{6a498709-e00b-4c45-a018-8f9e4081ae40}{82590C13-F4DD-44f4-BA1D-8667246FDF8E}')
			$langlist[0].InputMethodTips.add('0409:00000409')
			Set-WinUserLanguageList $langlist -Force
			Set-WinDefaultInputMethodOverride -InputTip "0409:00000409"
			Set-WinSystemLocale zh-CN
			Set-TimeZone -Id "China Standard Time" -PassThru | Out-Null
		}
		Default {
			Write-Host "`n   $($lang.SetLang)$((Get-Culture).Name)"
			Write-Host "   $($lang.KeyboardSequence)$($lang.English) ( $($lang.Default) ), $($lang.Pinyi), $($lang.Wubi)"
			$langlist = New-WinUserLanguageList en-US
			$langlist[0].InputMethodTips.Clear()
			$langlist[0].InputMethodTips.add('0409:00000409')
			$langlist[0].InputMethodTips.add('0804:{81D4E9C9-1D3B-41BC-9E6C-4B40BF79E35E}{FA550B04-5AD7-411f-A5AC-CA038EC515D7}')
			$langlist[0].InputMethodTips.add('0804:{6a498709-e00b-4c45-a018-8f9e4081ae40}{82590C13-F4DD-44f4-BA1D-8667246FDF8E}')
			Set-WinUserLanguageList $langlist -Force
			Set-WinDefaultInputMethodOverride -InputTip "0409:00000409"
			Set-WinSystemLocale zh-CN
			Set-TimeZone -Id "China Standard Time" -PassThru | Out-Null
		}
	}
}
# Language keyboard setting module End

# Synchronization task
Function ScheduledTaskSettings {
	Write-Host "`n   $($lang.AddTo) $($lang.PlanTask) ( \Yi\isDark )"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue
	Unregister-ScheduledTask -TaskPath '\Yi\' -TaskName 'isDark' -Confirm:$false -ErrorAction SilentlyContinue

	$action = New-ScheduledTaskAction -Execute "$($env:systemdrive)\Yi\Yi\AIO\hstart.exe" -Argument "/NOCONSOLE /SILENT ""powershell.exe -file $($env:systemdrive)\Yi\Yi\theme.ps1"""
	$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1)
	$STPrin = New-ScheduledTaskPrincipal -GroupId "BUILTIN\Administrators"
	Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "\Yi\isDark" -Description "Yi" -RunLevel Highest -Force -ErrorAction SilentlyContinue | Out-Null
	Start-ScheduledTask -TaskPath '\Yi\' -TaskName "isDark" -ErrorAction SilentlyContinue
}

<#
	.Update module
#>
$ServerList = @(
	('https://fengyi.tel',
	 '/download/bs/v6/latest.xml'),
	('https://github.com',
	 '/ilikeyi/bsUpdate/raw/main/v6/latest.xml'),
	('https://gitee.com',
	 '/ilikeyi/BsUpdate/raw/master/v6/latest.xml')
)

Function CheckCatalog
{
	Param (
		[string]$chkpath
	)

	if (-not (Test-Path $chkpath -PathType Container))
	{
		New-Item -Path $chkpath -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
		if (-not (Test-Path $chkpath -PathType Container))
		{
			Write-Host "   - $($lang.FailedCreateFolder)$($chkpath)`n" -ForegroundColor Red
			return
		}
	}
}

Function RemoveTree {
	Param (
		[string]$Path
	)

	Remove-Item $Path -force -Recurse -ErrorAction silentlycontinue | Out-Null
	
	if (Test-Path "$Path\" -ErrorAction silentlycontinue) {
		$folders = Get-ChildItem -Path $Path -Directory -Force -ErrorAction SilentlyContinue
		ForEach ($folder in $folders) {
			RemoveTree $folder.FullName
		}

		$files = Get-ChildItem -Path $Path -File -Force -ErrorAction SilentlyContinue

		ForEach ($file in $files) {
			Remove-Item $file.FullName -force -ErrorAction SilentlyContinue
		}

		if (Test-Path "$Path\" -ErrorAction silentlycontinue) {
			Remove-Item $Path -force -ErrorAction SilentlyContinue
		}
	}
}

Function TestURI {
	Param(
		[Parameter(Position=0,Mandatory,HelpMessage="HTTP or HTTPS")]
		[ValidatePattern( "^(http|https)://" )]
		[Alias("url")]
		[string]$URI,
		[Parameter(ParameterSetName="Detail")]
		[Switch]$Detail,
		[ValidateScript({$_ -ge 0})]
		[int]$Timeout = 30
	)
	Process {
		Try {
			$paramHash = @{
				UseBasicParsing = $True
				DisableKeepAlive = $True
				Uri = $uri
				Method = 'Head'
				ErrorAction = 'stop'
				TimeoutSec = $Timeout
			}
			$test = Invoke-WebRequest @paramHash
			if ($Detail) {
				$test.BaseResponse | Select-Object ResponseURI,ContentLength,ContentType,LastModified, @{Name="Status";Expression= {$Test.StatusCode}}
			} else {
				if ($test.statuscode -ne 200) { $False } else { $True }
			}
		} Catch {
			write-verbose -message $_.exception
			if ($Detail) {
				$objProp = [ordered]@{
					ResponseURI = $uri
					ContentLength = $null
					ContentType = $null
					LastModified = $null
					Status = 404
				}
				New-Object -TypeName psobject -Property $objProp
			} else { $False }
		}
	}
}

Function Archive {
	param(
		$filename,
		$to
	)

	if (Compressing) {
		Write-host "   - $($lang.UseZip -f $($global:Zip))"
		$arguments = "x ""-r"" ""-tzip"" ""$filename"" ""-o$to"" ""-y""";
		Start-Process $global:Zip "$arguments" -Wait -WindowStyle Minimized
	} else {
		Start-Process $script:Zip "$arguments" -Wait -WindowStyle Minimized
		Expand-Archive -LiteralPath $filename -DestinationPath $to -force
	}
}

Function Compressing {
	if (Test-Path "$env:ProgramFiles\7-Zip\7z.exe") {
		$global:Zip = "$env:ProgramFiles\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:ProgramFiles(x86)\7-Zip\7z.exe") {
		$global:Zip = "$env:ProgramFiles(x86)\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:SystemDrive\Yi\Yi\AIO\7z.exe") {
		$global:Zip = "$env:SystemDrive\Yi\Yi\AIO\7z.exe"
		return $true
	}
	return $false
}

Function Update {
	param(
		[switch]$Force,
		[switch]$Quit,
		[switch]$IsProcess
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title $($lang.Update)
	$ServerTest     = $false
	$IsCorrectAuVer = $false
	$YiVer          = "6.0.0.1"
	$chkLocalver    = "6.0.0.0"
	Write-Host "   $($lang.UpdateCheckServerStatus -f $($ServerList.Count))
   ---------------------------------------------------"

	foreach ($list in $ServerList | Sort-Object { Get-Random } ) {
		$fullurl = $list[0] + $list[1]
		Write-Host "   * $($lang.UpdateServerAddress -f $($list[0]))"
		if(TestURI $fullurl){
			$versionxmlloc = $fullurl
			$ServerTest = $true
			Write-Host "   - $($lang.UpdateServeravailable)" -ForegroundColor Green
			break
		} else {
			Write-Host "   - $($lang.UpdateServerUnavailable)`n" -ForegroundColor Red
		}
	}

	if ($ServerTest) {
		Write-Host "   ---------------------------------------------------"
		Write-Host "   - $($lang.UpdatePriority)" -ForegroundColor Green
	} else {
		Write-Host "   - $($lang.UpdateServerTestFailed)" -ForegroundColor Red
		Write-Host "   ---------------------------------------------------"

		RefreshLanguage
		If ($Force) {
			return
		} else {
			ToMainpage -wait 2
		}
	}

	Write-host "`n   $($lang.UpdateQueryingUpdate)"

	$error.Clear()
	$time = Measure-Command { Invoke-WebRequest -Uri $versionxmlloc -ErrorAction SilentlyContinue }

	if ($error.Count -eq 0) {
		Write-Host "`n   $($lang.UpdateQueryingTime -f $($time.TotalMilliseconds))"
	} else {
		Write-host "`n   $($lang.UpdateConnectFailed)"

		RefreshLanguage
		If ($Force) {
			return
		} else {
			ToMainpage -wait 2
		}
	}

	$getSerVer = (Invoke-WebRequest -Uri $versionxmlloc -UseBasicParsing -Body $body -Method:Get -Headers $head -ContentType "application/xml" -TimeoutSec 15 -ErrorAction:stop)
	$chkRemovever = ([xml]$getSerVer.Content).versioninfo.version.minau
	$PPocess = "$PSScriptRoot\Post.Processing.bat"
	$PsPocess = "$PSScriptRoot\Post.Processing.ps1"

	If([String]::IsNullOrEmpty($chkRemovever)){
		$IsCorrectAuVer = $false
	} else {
		if ($chkRemovever -ge $chkLocalver) {
			$IsCorrectAuVer = $true
		} else {
			$IsCorrectAuVer = $false
		}
	}

	if ($IsCorrectAuVer) {
		Write-Host "`n   $($lang.UpdateMinimumVersion -f $($chkLocalver))"
		$IsUpdateAvailable = $false
		$url = ([xml]$getSerVer.Content).versioninfo.download.url
		$output = "$PSScriptRoot\..\latest.zip"

		if (([xml]$getSerVer.Content).versioninfo.version.version -gt $YiVer) {
			$IsUpdateAvailable = $true
		} else {
			$IsUpdateAvailable = $false
		}

		if ($IsUpdateAvailable) {
			Write-host "`n   $($lang.UpdateVerifyAvailable)
   ---------------------------------------------------"

			Write-Host "   * $($lang.UpdateDownloadAddress)$($url)"
			if(TestURI $url){
				Write-Host "   - $($lang.UpdateAvailable)" -ForegroundColor Green
				Write-Host "   ---------------------------------------------------"
			} else {
				Write-Host "   - $($lang.UpdateUnavailable)" -ForegroundColor Red
				Write-Host "   ---------------------------------------------------"
				RefreshLanguage
				If ($Force) {
					return
				} else {
					ToMainpage -wait 2
				}
			}

			Write-host "`n   $($lang.UpdateCurrent)$YiVer
   $($lang.UpdateLatest)$(([xml]$getSerVer.Content).versioninfo.version.version)

   $(([xml]$getSerVer.Content).versioninfo.changelog.title)
   $('-' * (([xml]$getSerVer.Content).versioninfo.changelog.title).Length)
$(([xml]$getSerVer.Content).versioninfo.changelog.'#text')"

			Write-host "   $($lang.UpdateNewLatest)`n" -ForegroundColor Green
			If ($Force) {
				$title = "   $($lang.UpdateForce)"
				$start_time = Get-Date
				remove-item -path $output -force -ErrorAction SilentlyContinue
				Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
				Write-Host "`n   $($lang.UpdateTimeUsed)$((Get-Date).Subtract($start_time).Seconds) (s)"
			} else {
				$title = "$($lang.UpdateInstall)"
				$message = "$($lang.UpdateInstallSel)"
				$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Yes"
				$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "No"
				$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
				$prompt=$host.ui.PromptForChoice($title, $message, $options, 0)
				Switch ($prompt)
				{
					0 {
						$start_time = Get-Date
						remove-item -path $output -force -ErrorAction SilentlyContinue
						Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
						Write-Host "`n   $($lang.UpdateTimeUsed)$((Get-Date).Subtract($start_time).Seconds) (s)"
					}
					1 {
						Write-Host "`n   $($lang.UserCancel)"
						RefreshLanguage
						ToMainpage -wait 2
					}
				}
			}

			if ((Test-Path $output -PathType Leaf)) {
				Write-Host "`n   $($lang.UpdateUnpacking)$output"
				Archive -filename $output -to "$PSScriptRoot\..\..\"
				Write-Host "`n   * $($lang.UpdatePostProc)"
				if ($IsProcess) {
					Write-Host "   - $($lang.UpdateNotExecuted)" -ForegroundColor red
				} else {
					if ((Test-Path $PPocess -PathType Leaf)) {
						Start-Process -FilePath $PPocess -wait -WindowStyle Minimized
						remove-item -path $PPocess -force
						Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
					} else {
						Write-Host "   - $($lang.UpdateNoPost)" -ForegroundColor red
					}
					if ((Test-Path $PsPocess -PathType Leaf)) {
						Start-Process powershell -ArgumentList "-file $($PsPocess)" -Wait -WindowStyle Minimized
						remove-item -path $PsPocess -force
						Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
					} else {
						Write-Host "   - $($lang.UpdateNoPost)`n" -ForegroundColor red
					}
					PostProcessing
					Write-host "`n   Yi's Solutions $($lang.UpdateDone)`n"
				}
			} else {
				Write-host "`n   $($lang.UpdateUpdateStop)"
			}
			remove-item -path $output -force -ErrorAction SilentlyContinue
		} else {
			Write-host "   $($lang.UpdateNoUpdateAvailable)"
		}
	} else {
		Write-host "   $($lang.UpdateNotSatisfied -f $($chkLocalver))"
	}

	RefreshLanguage
	If ($Force) {
		return
	} else {
		ToMainpage -wait 2
	}
}

Function PostProcessing {
	RefreshLanguage
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue
	RefreshStart
	Permissions
}
# Update End

<#
   .Install Module
#>
Function TestAvailableDisk {
	param (
		[string]$Path
	)
	
	$test_tmp_filename = "writetest-" + [guid]::NewGuid()
	$test_filename = Join-Path -Path "$($Path)" -ChildPath "$($test_tmp_filename)"
	
	try
	{
		[io.file]::OpenWrite($test_filename).close()
		
		if ((Test-Path -Path $test_filename))
		{
			Remove-Item $test_filename -ErrorAction SilentlyContinue
			return $true
		}
		$false
	}
	catch
	{
		return $false
	}
}

Function JoinUrl {
	param (
		[parameter(Mandatory = $True, HelpMessage = "Base Path")]
		[ValidateNotNullOrEmpty()]
		[string]$Path,
		[parameter(Mandatory = $True, HelpMessage = "Child Path or Item Name")]
		[ValidateNotNullOrEmpty()]
		[string]$ChildPath
	)
	if ($Path.EndsWith('/')) {
		return "$Path" + "$ChildPath"
	} else {
		return "$Path/$ChildPath"
	}
}

Function StartInstallSoftware
{
	param (
		$appname,
		$status,
		$act,
		$mode,
		$todisk,
		$structure,
		$url,
		$packer,
		$types,
		$filename,
		$param,
		$method
	)
	$url = JoinUrl -Path "$($url)" -ChildPath "$($packer).$($types)"

	Switch ($status) {
		Enable {
			Write-Host "   $($lang.Instling) - $($appname)" -ForegroundColor Green
		}
		Disable {
			Write-Host "   $($lang.InstlSkip) - $($appname)" -ForegroundColor Red
			return
		}
	}

	Switch ($todisk) {
		auto {
			$drives = Get-PSDrive -PSProvider FileSystem | Where-Object { -not ("$($env:SystemDrive)\" -eq $_.Root) } | Select-Object -ExpandProperty 'Root'
			foreach ($drive in $drives) {
				$tempoutputfoldoer = Join-Path -Path $($drive) -ChildPath "$($structure)"
				Get-ChildItem -Path $tempoutputfoldoer -File -Filter "*$($filename)*$((Get-Culture).Name)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($drive)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path $tempoutputfoldoer -File -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($drive)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path $tempoutputfoldoer -File -Filter "*$($packer)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($drive)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				foreach ($drive in $drives) {
					if (TestAvailableDisk -Path $drive) {
						$OutTo = Join-Path -Path "$($drive)" -ChildPath "$($structure)"
						$OutAny = Join-Path -Path "$($drive)" -ChildPath "$($structure)\$($packer).$($types)"
						break
					} else {
						$OutTo = Join-Path -Path $($env:SystemDrive) -ChildPath "$($structure)"
						$OutAny = Join-Path -Path $($env:SystemDrive) -ChildPath "$($structure)\$($packer).$($types)"
					}
				}
			}
		}
		default {
			$OutTo = Join-Path -Path $($todisk) -ChildPath "$($structure)"
			$OutAny = Join-Path -Path $($todisk) -ChildPath "$($structure)\$($packer).$($types)"
			Get-ChildItem -Path $OutTo -File -Filter "*$($filename)*$((Get-Culture).Name)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path $OutTo -File -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path $OutTo -File -Filter "*$($packer)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
		}
	}

	Switch ($types) {
		zip {
			Switch ($act)
			{
				Install {
					Get-ChildItem -Path $OutTo -File -Filter "*$($filename)*$((Get-Culture).Name)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)$($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -File -Filter "*$($filename)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)$($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -File -Filter "*$($packer)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)$($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.ExistingPacker)"
					} else {
						Write-Host "   * $($lang.StartDown)`n     > $($lang.ConnectTo)$url`n     + $($lang.SaveTo)$OutAny"
						CheckCatalog -chkpath $OutTo
						Invoke-WebRequest -Uri $url -OutFile "$($OutAny)" -ErrorAction SilentlyContinue | Out-Null
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.Unpacking)"
						Archive -filename $OutAny -to $OutTo
						Write-Host "   - $($lang.UnzipDone)"
						if ((Test-Path $OutAny)) { remove-item -path $OutAny -force }
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
					Get-ChildItem -Path $OutTo -File -Filter "*$($filename)*$((Get-Culture).Name)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)$($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -File -Filter "*$($filename)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)$($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -File -Filter "*$($packer)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)$($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
				}
				NoInst {
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.BeenInstl)`n"
					} else {
						Write-Host "   * $($lang.StartDown)`n     > $($lang.ConnectTo)$url`n     + $($lang.SaveTo)$OutAny"
						CheckCatalog -chkpath $OutTo
						Invoke-WebRequest -Uri $url -OutFile "$($OutAny)" -ErrorAction SilentlyContinue | Out-Null
					}
				}
				To {
					$newoutputfoldoer = "$($OutTo)\$($packer)"
					if (Test-Path $newoutputfoldoer -PathType Container) {
						Write-Host "   - $($lang.BeenInstl)`n"
						break
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.ExistingInstlPacker)"
					} else {
						Write-Host "   * $($lang.StartDown)`n     > $($lang.ConnectTo)$url`n     + $($lang.SaveTo)$OutAny"
						Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.UnzipOnly)"
						Archive -filename $OutAny -to $newoutputfoldoer
						Write-Host "   - $($lang.UnzipDone)`n"
						if ((Test-Path $OutAny)) { remove-item -path $OutAny -force }
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
				}
				Unzip {
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.ExistingPacker)"
					} else {
						Write-Host "   * $($lang.StartDown)`n     > $($lang.ConnectTo)$url`n     + $($lang.SaveTo)$OutAny"
						CheckCatalog -chkpath $OutTo
						Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.UnzipOnly)"
						Archive -filename $OutAny -to $OutTo
						Write-Host "   - $($lang.UnzipDone)`n"
						if ((Test-Path $OutAny)) { remove-item -path $OutAny -force }
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
				}
			}
		}
		default {
			if ((Test-Path $OutAny -PathType Leaf)) {
				OpenApp -filename $OutAny -param $param -mode $mode -method $method
			} else {
				Write-Host "   * $($lang.StartDown)`n     > $($lang.ConnectTo)$url"
				if (TestURI $url) {
					Write-Host "     + $($lang.SaveTo)$OutAny"
					CheckCatalog -chkpath $OutTo
					Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
					OpenApp -filename $OutAny -param $param -mode $mode -method $method
				} else {
					Write-Host "     - $($lang.NotAvailable)`n" -ForegroundColor Red
				}
			}
		}
	}
}

Function OpenApp
{
	param (
		$filename,
		$param,
		$mode,
		$method
	)
	$Select = $method -split ":"

	switch ($Select[0]) {
		1 {
			$TestCfg = "$(Split-Path $filename)\$($Select[1]).$($Select[2])"
			$TestDefault = "$(Split-Path $filename)\$($Select[1]).default.$($Select[2])"
			$TestLanguage = "$(Split-Path $filename)\$($Select[1]).$((Get-Culture).Name).$($Select[2])"
			if (Test-Path $TestCfg -PathType Leaf) {
				break
			} else {
				if (Test-Path $TestLanguage -PathType Leaf) {
					Copy-Item -Path $TestLanguage -Destination $TestCfg -ErrorAction SilentlyContinue
				} else {
					if (Test-Path $TestDefault -PathType Leaf) {
						Copy-Item -Path $TestDefault -Destination $TestCfg -ErrorAction SilentlyContinue
					}
				}
			}
		}
		6 {
			Add-MpPreference -ExclusionPath "$env:Programfiles\KMSpico"
			Add-MpPreference -ExclusionPath "$env:SystemRoot\SECOH-QAD.exe"
			Add-MpPreference -ExclusionPath "$env:SystemRoot\SECOH-QAD.dll"
		}
		default {
		}
	}

	if ((Test-Path $filename -PathType Leaf)) {
		Switch ($mode)
		{
			Fast {
				Write-Host "   - $($lang.QucikRun)$filename`n   - $($lang.Parameter)$param`n"
				if (([string]::IsNullOrEmpty($param))) { Start-Process -FilePath $filename } else { Start-Process -FilePath $filename -ArgumentList $param }
			}
			Wait {
				Write-Host "   - $($lang.WaitDone)$filename`n   - $($lang.Parameter)$param`n"
				if (([string]::IsNullOrEmpty($param))) { Start-Process -FilePath $filename -Wait } else { Start-Process -FilePath $filename -ArgumentList $param -Wait }
			}
		}
	} else {
		Write-Host "   - $($lang.InstlNo)$filename`n" -ForegroundColor Red
	}
	
	switch ($Select[0]) {
		2 {
			stop-service "GoogleChromeElevationService" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
			stop-service "gupdate" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
			stop-service "gupdatem" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
			set-service "GoogleChromeElevationService" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
			set-service "gupdate" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
			set-service "gupdatem" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
			Disable-ScheduledTask -TaskPath "\" -TaskName "GoogleUpdateTaskMachineCore" -ErrorAction SilentlyContinue | Out-Null
			Disable-ScheduledTask -TaskPath "\" -TaskName "GoogleUpdateTaskMachineUA" -ErrorAction SilentlyContinue | Out-Null
		}
	}
}
# Install Module end

<#
   .Activate the system
#>

Function ActivatePact {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	$DefaultBackground = (Get-Host).UI.RawUI.BackgroundColor
	$DefaultForeground = (Get-Host).UI.RawUI.ForegroundColor
	$Host.UI.RawUI.BackgroundColor = 'DarkRed'
	$Host.UI.RawUI.ForegroundColor = 'White'

	Logo -Title $($lang.Warning)
	Write-Host "   $($lang.Warning)
   ---------------------------------------------------
   $($lang.WarningMsg)`n"

	$caption = $lang.AcceptTerms
	$message = $lang.AcceptTermsYN
	$choices = @("&Yes","&No")
	$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription]
	$choices | ForEach-Object { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))}
	$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 1)
	$Host.UI.RawUI.BackgroundColor = $DefaultBackground
	$Host.UI.RawUI.ForegroundColor = $DefaultForeground
	Switch ($prompt) {
		0 {
			if ($Force) {
				Activate -Force
				break
			} else {
				Activate
				ToMainpage -wait 6
			}
		}
		1 {
			if ($Force) {
				break
			} else {
				ToMainpage -wait 2
			}
		}
	}
}

Function Activate {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title $($lang.ActivationKit)
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	if ($Force) {
		ActivateGUI
	} else {
		ActivateGUI
		ToMainpage -wait 2
	}
}

$ActivateApp = @(
	("KMSpico",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Fast,
	 $env:SystemDrive,
	 "Yi\20",
	 "https://",
	 "KMSpico-setup",
	 "exe",
	 "KMSpico*",
	 "/silent",
	 "6"),
	($lang.CloudMoe,
	 [Status]::Disable,
	 [Action]::Install,
	 [Mode]::Fast,
	 $env:SystemDrive,
	 "Yi\20",
	 "https://github.com/TGSAN/CMWTAT_Digital_Edition/raw/master",
	 "CMWTAT_Digital_Release_2_5_0_0",
	 "exe",
	 "CMWTAT*",
	 "-a -e -h",
	 "")
)

Function ActivateGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormAct.Close()
	}
	$OK_Click = {
		$FormAct.Hide()
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Checked) {
					StartInstallSoftware -appname $ActivateApp[$_.Tag][0] -status "Enable" -act $ActivateApp[$_.Tag][2] -mode $ActivateApp[$_.Tag][3] -todisk $ActivateApp[$_.Tag][4] -structure $ActivateApp[$_.Tag][5] -url $ActivateApp[$_.Tag][6] -packer $ActivateApp[$_.Tag][7] -types $ActivateApp[$_.Tag][8] -filename $ActivateApp[$_.Tag][9] -param $ActivateApp[$_.Tag][10] -method $ActivateApp[$_.Tag][11]
				}
			}
		}
		$FormAct.Close()
	}
	$FormAct           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $lang.ActivationKit
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 202
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(218,482)
		Height         = 36
		Width          = 202
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$FormAct.controls.AddRange($Pane1)
	$FormAct.controls.AddRange($Start)
	$FormAct.controls.AddRange($Canel)

	for ($i=0; $i -lt $ActivateApp.Count; $i++) {
		$CheckBox  = New-Object System.Windows.Forms.RadioButton -Property @{
			Height = 30
			Width  = 405
			Text   = $ActivateApp[$i][0]
			Tag    = $i
		}

		if ($ActivateApp[$i][1] -like "Enable") {
			$CheckBox.Checked = $true
		} else {
			$CheckBox.Checked = $false
		}
		$Pane1.controls.AddRange($CheckBox)		
	}

	$FormAct.FormBorderStyle = 'Fixed3D'
	$FormAct.ShowDialog() | Out-Null
}
# Activate the system end

<#
   .Install prerequisite software 
#>
Function Prerequisite {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title "$($lang.Instl) $($lang.Necessary)"
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"
	
	if ($Force) {
		PrerequisiteGUI
	} else {
		PrerequisiteGUI
		ToMainpage -wait 2
	}
}

$PrerequisiteApp = @(
	("Google Chrome",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Fast,
	 $env:SystemDrive,
	 "Yi\00\AIO",
	 "https://fengyi.tel",
	 "Yi",
	 "exe",
	 "GoogleChrome*",
	 "/silent /install",
	 "2"),
	("7Zip",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Fast,
	 $env:SystemDrive,
	 "Yi\00\AIO",
	 "https://www.7-zip.org/a",
	 "7z2100-x64",
	 "exe",
	 "7z*",
	 "/S",
	 ""),
	 ("WinRAR",
	  [Status]::Enable,
	  [Action]::Install,
	  [Mode]::Fast,
	  $env:SystemDrive,
	  "Yi\00\AIO",
	  "https://www.rarlab.com/rar",
	  $($lang.Winrar),
	  "exe",
	  "winrar*",
	  "/S",
	  ""),
	("VisualCppRedist AIO",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Fast,
	 $env:SystemDrive,
	 "Yi\00\AIO",
	 "https://github.com/abbodi1406/vcredist/releases/download/v0.45.0",
	 "VisualCppRedist_AIO_x86_x64_45",
	 "zip",
	 "VisualCppRedist*",
	 "/y",
	 "")
)

Function PrerequisiteGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormPre.Close()
	}
	$OK_Click = {
		$FormPre.Hide()
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					if ($_.Tag -ne "Yi") {
						StartInstallSoftware -appname $PrerequisiteApp[$_.Tag][0] -status "Enable" -act $PrerequisiteApp[$_.Tag][2] -mode $PrerequisiteApp[$_.Tag][3] -todisk $PrerequisiteApp[$_.Tag][4] -structure $PrerequisiteApp[$_.Tag][5] -url $PrerequisiteApp[$_.Tag][6] -packer $PrerequisiteApp[$_.Tag][7] -types $PrerequisiteApp[$_.Tag][8] -filename $PrerequisiteApp[$_.Tag][9] -param $PrerequisiteApp[$_.Tag][10] -method $PrerequisiteApp[$_.Tag][11]
					}
				}
			}
		}
		if ($WPS.Checked) { WPSGUI }
		$FormPre.Close()
	}
	$FormPre           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = "$($lang.Instl) $($lang.Necessary)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$WPS               = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.Office
		Tag            = "Yi"
		Checked        = $true
	}
	$FormPre.controls.AddRange($Pane1)
	$FormPre.controls.AddRange($AllSel)
	$FormPre.controls.AddRange($AllClear)
	$FormPre.controls.AddRange($Start)
	$FormPre.controls.AddRange($Canel)

	for ($i=0; $i -lt $PrerequisiteApp.Count; $i++) {
		$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
			Height = 30
			Width  = 405
			Text   = $PrerequisiteApp[$i][0]
			Tag    = $i
		}

		if ($PrerequisiteApp[$i][1] -like "Enable") {
			$CheckBox.Checked = $true
		} else {
			$CheckBox.Checked = $false
		}
		$Pane1.controls.AddRange($CheckBox)		
	}

	$Pane1.controls.AddRange($WPS)
	$FormPre.FormBorderStyle = 'Fixed3D'
	$FormPre.ShowDialog() | Out-Null
}
# Install prerequisite software end

<#
   .Install Most Used Software
#>
Function MostUsedSoftware {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	if (Test-Path "$PSScriptRoot\$($global:IsLang)\Instl.ps1" -PathType Leaf) {
		powershell -NoLogo -NonInteractive -File "$PSScriptRoot\$($global:IsLang)\Instl.ps1" -Silent
	} else {
		if (Test-Path "$PSScriptRoot\en-US\Instl.ps1" -PathType Leaf) {
			powershell -NoLogo -NonInteractive -File "$PSScriptRoot\en-US\Instl.ps1" -Silent
		} else {
			Clear-Host
			Write-Host "`n   $($lang.InstlNo)$PSScriptRoot\en-US\Instl.ps1" -ForegroundColor Red
		}
	}
}

<#
   .Desktop Icon
#>
Function AddDesktopICON {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title $($lang.DeskIcon)
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	if ($Force) {
		AddDesktopGUI
	} else {
		AddDesktopGUI
		ToMainpage -wait 2
	}
}

Function AddDesktopGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormDesktop.Close()
	}
	$OK_Click = {
		$FormDesktop.Hide()
		if ($ThisPC.Checked) { AddDeskThisPC }
		if ($Network.Checked) { AddDeskNetwork }
		if ($User.Checked) { AddDeskUser }
		if ($IE.Checked) { AddDeskIE }
		if ($TaskBar.Checked) { ResetTaskBar }
		if ($ResetDesk.Checked) { ResetDesktop }
		$FormDesktop.Close()
	}
	$FormDesktop       = New-Object system.Windows.Forms.Form -Property @{
		AutoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $($lang.DeskIcon)
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		WrapContents   = $true
		Padding        = 8
		Dock           = 1
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$ThisPC            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.ThisPC)"
		Checked        = $true
	}
	$Network           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Network)"
	}
	$User              = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.User)"
		Checked        = $true
	}
	$IE                = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.IE)"
	}
	$TaskBar           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$ResetDesk         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.ResetDesk
		Checked        = $true
	}
	$FormDesktop.controls.AddRange($Pane1)
	$FormDesktop.controls.AddRange($AllSel)
	$FormDesktop.controls.AddRange($AllClear)
	$FormDesktop.controls.AddRange($Start)
	$FormDesktop.controls.AddRange($Canel)
	$Pane1.controls.AddRange($ThisPC)
	$Pane1.controls.AddRange($Network)
	$Pane1.controls.AddRange($User)
	$Pane1.controls.AddRange($IE)
	$Pane1.controls.AddRange($TaskBar)
	$Pane1.controls.AddRange($ResetDesk)
	$FormDesktop.FormBorderStyle = 'Fixed3D'
	$FormDesktop.ShowDialog() | Out-Null
}

Function AddDeskThisPC {
    Write-Host "   $($lang.ThisPC)"
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" -Type DWord -Value 0
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" -Type DWord -Value 0
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" -Type DWord -Value 0
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n"
}

Function AddDeskNetwork {
    Write-Host "   $($lang.Network)"
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Name "{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}" -Type DWord -Value 0
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Name "{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}" -Type DWord -Value 0
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Name "{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}" -Type DWord -Value 0
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Name "{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n"
}

Function AddDeskUser {
    Write-Host "   $($lang.User)"
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}" -Type DWord -Value 0
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}" -Type DWord -Value 0
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}" -Type DWord -Value 0
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n"
}

Function AddDeskIE {
	Write-Host "   $($lang.IE)"
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force | Out-Null }
	If (-not (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel")) { New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force | Out-Null }
	Remove-Item -Recurse -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}" -Force -ErrorAction SilentlyContinue | Out-Null
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\DefaultIcon") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\DefaultIcon" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\InProcServer32") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\InProcServer32" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Private") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Private" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Private\Command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Private\Command" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\NoAddOns") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\NoAddOns" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\NoAddOns\Command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\NoAddOns\Command" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\OpenHomePage") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\OpenHomePage" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\OpenHomePage\Command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\OpenHomePage\Command" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Properties") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Properties" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Properties\command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Properties\command" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\Shellex\ContextMenuHandlers\ieframe") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\Shellex\ContextMenuHandlers\ieframe" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\Shellex\MayChangeDefaultMenu") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\Shellex\MayChangeDefaultMenu" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu") -ne $true) {  New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu" -Force -ErrorAction SilentlyContinue | Out-Null }
	if((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel") -ne $true) {  New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Force -ErrorAction SilentlyContinue | Out-Null }
	Remove-Item -Recurse -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{871C5380-42A0-1069-A2EA-08002B30301D}" -Force -ErrorAction SilentlyContinue | Out-Null
    if((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{871C5380-42A0-1069-A2EA-08002B30301D}") -ne $true) {  New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{871C5380-42A0-1069-A2EA-08002B30301D}" -Force -ErrorAction SilentlyContinue | Out-Null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}' -Name '(default)' -Value 'Internet Explorer' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}' -Name 'InfoTip' -Value "@$env:SystemDrive\Windows\System32\ieframe.dll,-881" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\DefaultIcon' -Name '(default)' -Value "$env:SystemDrive\Windows\System32\ieframe.dll,-190" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\InProcServer32' -Name '(default)' -Value "$env:SystemDrive\Windows\System32\ieframe.dll" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\InProcServer32' -Name 'ThreadingModel' -Value 'Apartment' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell' -Name '(default)' -Value 'OpenHomePage' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Private' -Name '(default)' -Value $($lang.IEPrivate) -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Private\Command' -Name '(default)' -Value """$env:SystemDrive\Program Files\Internet Explorer\iexplore.exe"" -private" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
    New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\NoAddOns' -Name '(default)' -Value $($lang.IENoAddOns) -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\NoAddOns\Command' -Name '(default)' -Value """$env:SystemDrive\Program Files\Internet Explorer\iexplore.exe"" -extoff" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\OpenHomePage' -Name '(default)' -Value $($lang.IEOpenHomePage) -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\OpenHomePage\Command' -Name '(default)' -Value """$env:SystemDrive\Program Files\Internet Explorer\iexplore.exe""" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Properties' -Name '(default)' -Value $($lang.IEProperties) -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
    New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Properties' -Name 'Position' -Value 'bottom' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\shell\Properties\command' -Name '(default)' -Value 'control.exe inetcpl.cpl' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\Shellex\ContextMenuHandlers\ieframe' -Name '(default)' -Value '{871C5380-42A0-1069-A2EA-08002B30309D}' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\Shellex\MayChangeDefaultMenu' -Name '(default)' -Value '' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder' -Name '(default)' -Value "$env:SystemDrive\Windows\System32\ieframe.dll,-190" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder' -Name 'HideAsDeletePerUser' -Value '' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder' -Name 'Attributes' -Value 36 -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder' -Name 'HideFolderVerbs' -Value '' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder' -Name 'WantsParseDisplayName' -Value '' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{871C5380-42A0-1069-A2EA-08002B30301D}\ShellFolder' -Name 'HideOnDesktopPerUser' -Value '' -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null;
	Remove-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{871C5380-42A0-1069-A2EA-08002B30301D}' -Force -ErrorAction SilentlyContinue | Out-Null;
	Remove-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{871C5380-42A0-1069-A2EA-08002B30301D}' -Force -ErrorAction SilentlyContinue | Out-Null;
	Write-Host "   - $($lang.Done)`n"
}
# Desktop Icon End

<#
   .Close system software software 
#>
Function SystemSoftware {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title $($lang.ComesWith)
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	if ($Force) {
		CloseSoftwareGUI
	} else {
		CloseSoftwareGUI
		ToMainpage -wait 2
	}
}

$CloseSoftwareApp = @(
	($lang.DefenderControl,
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Wait,
	 $env:SystemDrive,
	 "Yi\60",
	 "https://www.sordum.org/files/download/defender-control",
	 "DefenderControl",
	 "zip",
	 "DefenderControl*",
	 "/D",
	 "1:DefenderControl:ini"),
	($lang.Wub,
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Wait,
	 $env:SystemDrive,
	 "Yi\60",
	 "https://www.sordum.org/files/download/windows-update-blocker",
	 "Wub",
	 "zip",
	 "Wub*",
	 "/D /P",
	 "1:Wub:ini"),
	($lang.Fab,
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Wait,
	 $env:SystemDrive,
	 "Yi\60",
	 "https://www.sordum.org/files/download/firewall-app-blocker",
	 "fab",
	 "zip",
	 "fab*",
	 "/S 3",
	 "1:Fab:ini")
)

Function CloseSoftwareGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormWith.Close()
	}
	$OK_Click = {
		$FormWith.Hide()
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					if ($_.Tag -ne "Yi") {
						StartInstallSoftware -appname $CloseSoftwareApp[$_.Tag][0] -status "Enable" -act $CloseSoftwareApp[$_.Tag][2] -mode $CloseSoftwareApp[$_.Tag][3] -todisk $CloseSoftwareApp[$_.Tag][4] -structure $CloseSoftwareApp[$_.Tag][5] -url $CloseSoftwareApp[$_.Tag][6] -packer $CloseSoftwareApp[$_.Tag][7] -types $CloseSoftwareApp[$_.Tag][8] -filename $CloseSoftwareApp[$_.Tag][9] -param $CloseSoftwareApp[$_.Tag][10] -method $CloseSoftwareApp[$_.Tag][11]
					}
				}
			}
		}
		if ($OneDrive.Checked) { DelOneDrive }
		if ($Edge.Checked) { DelEdge }
		if ($TaskBar.Checked) { ResetTaskBar }
		if ($ResetDesk.Checked) { ResetDesktop }
		$FormWith.Close()
	}
	$FormWith          = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $lang.ComesWith
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$OneDrive          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) OneDrive"
		Tag            = "Yi"
		Checked        = $true
	}
	$Edge              = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) Edge"
		Tag            = "Yi"
		Checked        = $true
	}
	$TaskBar           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Reset) $($lang.TaskBar)"
		Tag            = "Yi"
	}
	$ResetDesk         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.ResetDesk
		Checked        = $true
		Tag            = "Yi"
	}
	$FormWith.controls.AddRange($Pane1)
	$FormWith.controls.AddRange($AllSel)
	$FormWith.controls.AddRange($AllClear)
	$FormWith.controls.AddRange($Start)
	$FormWith.controls.AddRange($Canel)

	for ($i=0; $i -lt $CloseSoftwareApp.Count; $i++) {
		$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
			Height  = 30
			Width   = 405
			Text    = $CloseSoftwareApp[$i][0]
			Tag     = $i
			Checked = $true
		}

		$Pane1.controls.AddRange($CheckBox)		
	}

	$Pane1.controls.AddRange($OneDrive)
	$Pane1.controls.AddRange($Edge)
	$Pane1.controls.AddRange($TaskBar)
	$Pane1.controls.AddRange($ResetDesk)
	$FormWith.FormBorderStyle = 'Fixed3D'
	$FormWith.ShowDialog() | Out-Null
}

Function DelOneDrive {
	Write-Host "   $($lang.Delete) OneDrive" -ForegroundColor Green
	$removeonedrive = "$PSScriptRoot\..\AIO\Opt\scripts\remove-onedrive.ps1"
	if (Test-Path $removeonedrive -PathType Leaf ) {
		Start-Process "powershell" -ArgumentList "-file $($removeonedrive)" -WindowStyle Minimized
	}
}

Function DelEdge {
	Write-Host "   $($lang.Delete) Edge" -ForegroundColor Green
	$softiwt = "$PSScriptRoot\..\AIO\install_wim_tweak.exe"
	if (Test-Path $softiwt -PathType Leaf ) {
		Start-Process $softiwt -ArgumentList "/o" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft-Windows-Internet-Browser-Package /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft.MicrosoftEdgeDevToolsClient /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft.MicrosoftEdgeDevToolsClient_1000.20226.1000.0_neutral_neutral_8wekyb3d8bbwe /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/h /o" -Wait -WindowStyle Minimized
	}
	$latestedge = "$PSScriptRoot\..\AIO\Opt\scripts\latest.uninstall.edge.ps1"
	if (Test-Path $latestedge -PathType Leaf ) {
		Start-Process "powershell" -ArgumentList "-file $latestedge" -Wait -WindowStyle Minimized
	}
}
# Install SystemSoftware software end

Function Optimization {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title "$($lang.Optimize) $($lang.System)"
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	if ($Force) {
		OptimizationGUI
	} else {
		OptimizationGUI
		ToMainpage -wait 2
	}
}

Function OptimizationGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
		$NotificationPart.Checked = $True
		$PagingSize.Checked = $True
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
		$NotificationNo.Checked = $True
		$PagingSizeNo.Checked = $True
	}
	$Canel_Click = { 
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormOpt.Close()
	}
	$Restore_Click = {
		$FormOpt.Hide()
		if ($AddOwnership.Checked) { DisableTakeOwnership }
		if ($Hibernation.Checked) { EnableHibernation }
		if ($PowerSupply.Checked) { RestorePowerSupply }
		if ($AppRestartScreen.Checked) { EnableAppRestartScreen }
		if ($ShortcutArrow.Checked) { RestoreArrow }
		if ($NumLock.Checked) { DisableNumlock }
		if ($UAC.Checked) { SetUACDefault }
		if ($SmartScreen.Checked) { EnableSmartScreen }
		if ($Maintain.Checked) { EnableMaintain }
		if ($Experience.Checked) { RestoreExperience }
		if ($Defragmentation.Checked) { EnableDefragmentation }
		if ($Compatibility.Checked) { EnableCompatibility }
		if ($AnimationEffects.Checked) { RestoreAnimationEffects }
		if ($SafetyWarnings.Checked) { DisableSafetyWarnings }
		if ($QOS.Checked) { EnableQOS }
		if ($NetworkTuning.Checked) { EnableNetworkTuning }
		if ($ECN.Checked) { EnableECN }
		if ($ErrorRecovery.Checked) { EnableErrorRecovery }
		if ($DEP.Checked) { RestoreDEPPAE }
		if ($PowerFailure.Checked) { EnablePowerFailure }
		if ($IEAutoSet.Checked) { EnableAutoDetect }
		if ($ScheduledTasks.Checked) { RestoreScheduledTasks }
		if ($MergeTaskbarNever.Checked) { DefaultMergeTaskbarNever }
		if ($NotificationAlways.Checked) { DefaultNotificationAlways }
		if ($NavShowAll.Checked) { RestoreNavShowAll }
		if ($Cortana.Checked) { RestoreCortana }
		if ($PwdUnlimited.Checked) { RestorePwdUnlimited }
		if ($RAM.Checked) { RestoreRAM }
		if ($PhotoPreview.Checked) { DisablePhotoPreview }
		if ($QuickAccess.Checked) { ShowRecentShortcuts }
		if ($Gamebar.Checked) { EnableGamebar }
		if ($GameMode.Checked) { EnableGameMode }
		if ($Protected.Checked) { RestoreProtected }
		if ($MultipleIncrease.Checked) { RestoreMultipleIncrease }
		if ($Autoplay.Checked) { EnableAutoplay }
		if ($Autorun.Checked) { EnableAutorun }
		if ($ErrorReporting.Checked) { EnableErrorReporting }
		if ($F8BootMenu.Checked) { EnableF8BootMenu }
		if ($OptSSD.Checked) { DefaultOptSSD }
		if ($MemoryCompression.Checked) { EnableMemoryCompression }
		if ($Prelaunch.Checked) { EnablePrelaunch }
		if ($OptUser.Checked) { RestoreOptUser }
		if ($OptUpdate.Checked) { RestoreOptUpdate }
		if ($FixPrivacy.Checked) { RestoreFixPrivacy }
		if ($NotificationFull.Checked) { RestoreActionCenter }
		if ($NotificationPart.Checked) { RestoreActionCenterPart }
		if ($PagingSize.Checked) { RestorePagingSize }
		if ($PagingSizeHigh.Checked) { RestorePagingSize }
		if ($TaskBar.Checked) { ResetTaskBar }
		if ($ResetDesk.Checked) { ResetDesktop }
		gpupdate /force | out-null
		$FormOpt.Close()
	}
	$OK_Click = {
		$FormOpt.Hide()
		if ($AddOwnership.Checked) {
			DisableTakeOwnership
			EnableTakeOwnership
		}
		if ($Hibernation.Checked) { DisableHibernation }
		if ($PowerSupply.Checked) { SetPowerSupply }
		if ($AppRestartScreen.Checked) { DisableAppRestartScreen }
		if ($ShortcutArrow.Checked) { DisableArrow }
		if ($NumLock.Checked) { EnableNumlock }
		if ($UAC.Checked) { SetUACNever }
		if ($SmartScreen.Checked) { DisableSmartScreen }
		if ($Maintain.Checked) { DisableMaintain }
		if ($Experience.Checked) { SetExperience }
		if ($Defragmentation.Checked) { DisableDefragmentation }
		if ($Compatibility.Checked) { DisableCompatibility }
		if ($AnimationEffects.Checked) { OptAnimationEffects }
		if ($SafetyWarnings.Checked) { EnableSafetyWarnings }
		if ($QOS.Checked) { DisableQOS }
		if ($NetworkTuning.Checked) { DisableNetworkTuning }
		if ($ECN.Checked) { DisableECN }
		if ($ErrorRecovery.Checked) { DisableErrorRecovery }
		if ($DEP.Checked) { DisableDEPPAE }
		if ($PowerFailure.Checked) { DisablePowerFailure }
		if ($IEAutoSet.Checked) { DisableAutoDetect }
		if ($IEProxy.Checked) { IEProxy }
		if ($ScheduledTasks.Checked) { DisableScheduledTasks }
		if ($MergeTaskbarNever.Checked) { SetMergeTaskbarNever }
		if ($NotificationAlways.Checked) { SetNotificationAlways }
		if ($NavShowAll.Checked) { SetNavShowAll }
		if ($Cortana.Checked) { SetCortana }
		if ($PwdUnlimited.Checked) { SetPwdUnlimited }
		if ($RAM.Checked) { SetRAM }
		if ($PhotoPreview.Checked) { EnablePhotoPreview }
		if ($QuickAccess.Checked) { HideRecentShortcuts }
		if ($Gamebar.Checked) { DisableGamebar }
		if ($GameMode.Checked) { DisableGameMode }
		if ($Protected.Checked) { DisableProtected }
		if ($MultipleIncrease.Checked) { DisableMultipleIncrease }
		if ($Autoplay.Checked) { DisableAutoplay }
		if ($Autorun.Checked) { DisableAutorun }
		if ($ErrorReporting.Checked) { DisableErrorReporting }
		if ($F8BootMenu.Checked) { DisableF8BootMenu }
		if ($OptSSD.Checked) { OptSSD }
		if ($MemoryCompression.Checked) { DisableMemoryCompression }
		if ($Prelaunch.Checked) { DisablePrelaunch }
		if ($OptUser.Checked) { DisableOptUser }
		if ($OptUpdate.Checked) { DisableOptUpdate }
		if ($FixPrivacy.Checked) { DisableFixPrivacy }
		if ($SendTo.Checked) { SendTo }
		if ($CleanSystemLog.Checked) { CleanSystemLog }
		if ($CleanSxS.Checked) { CleanSxS }
		if ($NotificationFull.Checked) { DisableActionCenter }
		if ($NotificationPart.Checked) { DisableActionCenterPart }
		if ($PagingSize.Checked) { PagingSize -size 8 }
		if ($PagingSizeHigh.Checked) { PagingSize -size 16 }
		if ($TaskBar.Checked) { ResetTaskBar }
		if ($ResetDesk.Checked) { ResetDesktop }
		gpupdate /force | out-null
		$FormOpt.Close()
	}

	$FormOpt           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = "$($lang.Optimize) $($lang.System)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Reset             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(188,482)
		Height         = 36
		Width          = 75
		add_Click      = $Restore_Click
		Text           = $lang.Restore
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$AddOwnership      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.AddTo) $($lang.AddOwnership)"
		Checked        = $true
	}
	$Hibernation       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Close) $($lang.Hibernation)"
		Checked        = $true
	}
	$PowerSupply       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PowerSupply)"
		Checked        = $true
	}
	$AppRestartScreen  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.AppRestartScreen)"
		Checked        = $true
	}
	$ShortcutArrow     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) $($lang.ShortcutArrow)"
		Checked        = $true
	}
	$NumLock           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Setting) $($lang.NumLock)"
		Checked        = $true
	}
	$UAC               = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Setting) $($lang.UAC)$($lang.UACNever)"
		Checked        = $true
	}
	$SmartScreen       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.SmartScreen)"
		Checked        = $true
	}
	$Maintain          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Close) $($lang.Maintain)"
		Checked        = $true
	}
	$Experience        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Close) $($lang.Experience)"
		Checked        = $true
	}
	$Defragmentation   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Defragmentation)"
		Checked        = $true
	}
	$Compatibility     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Close) $($lang.Compatibility)"
		Checked        = $true
	}
	$AnimationEffects  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.AnimationEffects)"
		Checked        = $true
	}
	$SafetyWarnings    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.SafetyWarnings)"
		Checked        = $true
	}
	$QOS               = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.QOS)"
		Checked        = $true
	}
	$NetworkTuning     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.NetworkTuning)"
		Checked        = $true
	}
	$ECN               = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.ECN)"
		Checked        = $true
	}
	$ErrorRecovery     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Close) $($lang.ErrorRecovery)"
		Checked        = $true
	}
	$DEP               = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.DEP) ( $($lang.Restart) )"
	}
	$PowerFailure      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Close) $($lang.PowerFailure)"
		Checked        = $true
	}
	$IEAutoSet         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.IEAutoSet)"
		Checked        = $true
	}
	$IEProxy           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Restore) $($lang.IEProxy)"
	}
	$ScheduledTasks    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.ScheduledTasks)"
		Checked        = $true
	}
	$MergeTaskbarNever = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Setting) $($lang.MergeTaskbarNever)"
		Checked        = $true
	}
	$NotificationAlways = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Setting) $($lang.NotificationAlways)"
		Checked        = $true
	}
	$NavShowAll        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Setting) $($lang.NavShowAll)"
		Checked        = $true
	}
	$Cortana           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.Cortana
		Checked        = $true
	}
	$PwdUnlimited      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PwdUnlimited)"
		Checked        = $true
	}
	$RAM               = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.RAM)"
		Checked        = $true
	}
	$PhotoPreview      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Enable) $($lang.PhotoPreview)"
		Checked        = $true
	}
	$QuickAccess       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.QuickAccess)"
		Checked        = $true
	}
	$Gamebar           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Gamebar)"
		Checked        = $true
	}
	$GameMode          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.GameMode)"
		Checked        = $true
	}
	$Protected         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Protected)"
		Checked        = $true
	}
	$MultipleIncrease  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Enable) $($lang.MultipleIncrease)"
		Checked        = $true
	}
	$Autoplay          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Autoplay)"
	}
	$Autorun           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Autorun)"
	}
	$ErrorReporting    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.ErrorReporting)"
		Checked        = $true
	}
	$F8BootMenu        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.F8BootMenu)"
	}
	$OptSSD            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.OptSSD)"
		Checked        = $true
	}
	$MemoryCompression = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.MemoryCompression)"
		Checked        = $true
	}
	$Prelaunch         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Prelaunch)"
		Checked        = $true
	}
	$OptUser           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.OptUser)"
		Checked        = $true
	}
	$OptUpdate         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.OptUpdate)"
		Checked        = $true
	}
	$FixPrivacy        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.FixPrivacy)"
		Checked        = $true
	}
	$SendTo            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Clean) $($lang.SendTo)"
		Checked        = $true
	}
	$CleanSystemLog    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Clean) $($lang.Logs)"
		Checked        = $true
	}
	$CleanSxS          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Clean) $($lang.SxS)"
	}
	$GroupNotification = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 118
		Width          = 405
		autoSizeMode   = 1
		Padding        = 14
	}
	$NotificationTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Notification)"
	}
	$NotificationNo  = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = $lang.NotSet
	}
	$NotificationFull  = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Close) $($lang.Notification) $($lang.Full)"
	}
	$NotificationPart  = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Close) $($lang.Notification) $($lang.Part)"
		Checked        = $true
	}
	$GroupPagingSize   = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 118
		Width          = 405
		autoSizeMode   = 1
		Padding        = 14
	}
	$PagingSizeTitle   = New-Object System.Windows.Forms.Label -Property @{
		autoSize       = $true
		Text           = "$($lang.PagingSize) ( $($lang.Restart) )"
	}
	$PagingSizeNo      = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = $lang.NotSet
	}
	$PagingSize        = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PagingSize) (8G)"
		Checked        = $true
	}
	$PagingSizeHigh    = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PagingSize) (16G)"
	}
	$TaskBar           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$ResetDesk         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.ResetDesk
	}

	$FormOpt.controls.AddRange($Pane1)
	$FormOpt.controls.AddRange($AllSel)
	$FormOpt.controls.AddRange($AllClear)
	$FormOpt.controls.AddRange($Reset)
	$FormOpt.controls.AddRange($Start)
	$FormOpt.controls.AddRange($Canel)
	$Pane1.controls.AddRange($AddOwnership)
	$Pane1.controls.AddRange($Hibernation)
	$Pane1.controls.AddRange($PowerSupply)
	$Pane1.controls.AddRange($AppRestartScreen)
	$Pane1.controls.AddRange($ShortcutArrow)
	$Pane1.controls.AddRange($NumLock)
	$Pane1.controls.AddRange($UAC)
	$Pane1.controls.AddRange($SmartScreen)
	$Pane1.controls.AddRange($Maintain)
	$Pane1.controls.AddRange($Experience)
	$Pane1.controls.AddRange($Defragmentation)
	$Pane1.controls.AddRange($Compatibility)
	$Pane1.controls.AddRange($AnimationEffects)
	$Pane1.controls.AddRange($SafetyWarnings)
	$Pane1.controls.AddRange($QOS)
	$Pane1.controls.AddRange($NetworkTuning)
	$Pane1.controls.AddRange($ECN)
	$Pane1.controls.AddRange($ErrorRecovery)
	$Pane1.controls.AddRange($DEP)
	$Pane1.controls.AddRange($PowerFailure)
	$Pane1.controls.AddRange($IEAutoSet)
	$Pane1.controls.AddRange($IEProxy)
	$Pane1.controls.AddRange($ScheduledTasks)
	$Pane1.controls.AddRange($MergeTaskbarNever)
	$Pane1.controls.AddRange($NotificationAlways)
	$Pane1.controls.AddRange($NavShowAll)
	$Pane1.controls.AddRange($Cortana)
	$Pane1.controls.AddRange($PwdUnlimited)
	$Pane1.controls.AddRange($RAM)
	$Pane1.controls.AddRange($PhotoPreview)
	$Pane1.controls.AddRange($QuickAccess)
	$Pane1.controls.AddRange($Gamebar)
	$Pane1.controls.AddRange($GameMode)
	$Pane1.controls.AddRange($Protected)
	$Pane1.controls.AddRange($MultipleIncrease)
	$Pane1.controls.AddRange($Autoplay)
	$Pane1.controls.AddRange($Autorun)
	$Pane1.controls.AddRange($ErrorReporting)
	$Pane1.controls.AddRange($F8BootMenu)
	$Pane1.controls.AddRange($OptSSD)
	$Pane1.controls.AddRange($MemoryCompression)
	$Pane1.controls.AddRange($Prelaunch)
	$Pane1.controls.AddRange($OptUser)
	$Pane1.controls.AddRange($OptUpdate)
	$Pane1.controls.AddRange($FixPrivacy)
	$Pane1.controls.AddRange($SendTo)
	$Pane1.controls.AddRange($CleanSystemLog)
	$Pane1.controls.AddRange($CleanSxS)
	$Pane1.controls.AddRange($GroupNotification)
	$GroupNotification.controls.AddRange($NotificationTitle)
	$GroupNotification.controls.AddRange($NotificationNo)
	$GroupNotification.controls.AddRange($NotificationFull)
	$GroupNotification.controls.AddRange($NotificationPart)
	$Pane1.controls.AddRange($GroupPagingSize)
	$GroupPagingSize.controls.AddRange($PagingSizeTitle)
	$GroupPagingSize.controls.AddRange($PagingSizeNo)
	$GroupPagingSize.controls.AddRange($PagingSize)
	$GroupPagingSize.controls.AddRange($PagingSizeHigh)
	$Pane1.controls.AddRange($TaskBar)
	$Pane1.controls.AddRange($ResetDesk)
	$FormOpt.FormBorderStyle = 'Fixed3D'
	$FormOpt.ShowDialog() | Out-Null
}

<#
   . Optimization Service
#>
Function OptimizationService {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title "$($lang.Optimize) $($lang.Service)"
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	if ($Force) {
		OptimizationServiceGUI
	} else {
		OptimizationServiceGUI
		ToMainpage -wait 2
	}
}

$Services = @(
	"Spooler"
	"DPS"
	"DiagTrack"
	"WdiSystemHost"
	"WdiServiceHost"
	"diagnosticshub.standardcollector.service"
	"dmwappushservice"
	"lfsvc"
	"MapsBroker"
	"NetTcpPortSharing"
	"RemoteAccess"
	"RemoteRegistry"
	"SharedAccess"
	"TrkWks"
	"WbioSrvc"
	"WlanSvc"
	"WMPNetworkSvc"
	"WSearch"
	"XblAuthManager"
	"XblGameSave"
	"XboxNetApiSvc"
)

$ServiceUncheck = @(
	"Spooler"
	"WlanSvc"
	"WSearch"
	"XblAuthManager"
	"XblGameSave"
	"XboxNetApiSvc"
)

Function OptimizationServiceGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormService.Close()
	}
	$Restore_Click = {
		$FormService.Hide()
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					Write-Host "   $($_.Text)"
					Write-Host "   - $($lang.SettingTo -f $($lang.Auto))" -ForegroundColor Green
					Get-Service -Name $_.Tag | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
					if ($Status.Checked) {
						Write-Host "   - $($lang.Enable)" -ForegroundColor Green
						Start-Service $_.Tag -ErrorAction SilentlyContinue | Out-Null
					}
					Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
				}
			}
		}
		$FormService.Close()
	}
	$OK_Click = {
		$FormService.Hide()
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					Write-Host "   $($_.Text)"
					Write-Host "   - $($lang.SettingTo -f $($lang.Disable))" -ForegroundColor Green
					Get-Service -Name $_.Tag | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
					if ($Status.Checked) {
						Write-Host "   - $($lang.Close)" -ForegroundColor Green
						Stop-Service $_.Tag -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
					}
					Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
				}
			}
		}
		$FormService.Close()
	}
	$FormService       = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = "$($lang.Optimize) $($lang.Service)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 440
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$Status            = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(11,445)
		Height         = 36
		Width          = 480
		Text           = $lang.Status
		Checked        = $true
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Reset             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(188,482)
		Height         = 36
		Width          = 75
		add_Click      = $Restore_Click
		Text           = $lang.Enable
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.Disable
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$FormService.controls.AddRange($Pane1)
	$FormService.controls.AddRange($Status)
	$FormService.controls.AddRange($AllSel)
	$FormService.controls.AddRange($AllClear)
	$FormService.controls.AddRange($Reset)
	$FormService.controls.AddRange($Start)
	$FormService.controls.AddRange($Canel)

	for ($i=0; $i -lt $Services.Count; $i++) {
		$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
			Height  = 30
			Width   = 405
			Text    = $($lang.$($Services[$i]))
			Tag     = $Services[$i]
			Checked = $true
		}

		if ($ServiceUncheck.Contains($Services[$i])) {
			$CheckBox.Checked = $false
		}
		$Pane1.controls.AddRange($CheckBox)
	}

	$FormService.FormBorderStyle = 'Fixed3D'
	$FormService.ShowDialog() | Out-Null
}

<#
   .Install WPS
#>
Function WPS {
	param (
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $global:QUIT = $true }

	Logo -Title $($lang.InstlOffice)
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	if ($Force) {
		WPSGUI
	} else {
		WPSGUI
		ToMainpage -wait 2
	}
}

Function WPSGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormOffice.Close()
	}
	$OK_Click = {
		$FormOffice.Hide()
		if ($Disconnected.Checked) {
			StartInstallSoftware -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "Yi\Yi\AIO" -url "https://www.sordum.org/files/small-tools" -packer "NetDisabler" -types "zip" -filename "NetDisabler*" -param "/D" -method ""
		}
		if ($Office.Checked) {
			StartInstallSoftware -appname "WPS Office" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "Yi\00\AIO" -url "https://pacakge.cache.wpscdn.cn/wps/download" -packer "W.P.S.10214.12012.2019" -types "exe" -filename "WPS*" -param "/s" -method ""
		}
		if ($Patch.Checked) {
			Write-Host "   - $($lang.Patch)`n"
			if (Test-Path -Path "$PSScriptRoot\..\..\00\AIO\WPS.en-US.exe") {
				if (Test-Path -Path "$PSScriptRoot\..\..\00\AIO\auth.dll") {
					StartInstallSoftware -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "Yi\Yi\AIO" -url "https://www.sordum.org/files/small-tools" -packer "NetDisabler" -types "zip" -filename "NetDisabler*" -param "/D" -method ""
					Stop-Process -ProcessName wpscenter -ErrorAction SilentlyContinue | Out-Null
					Stop-Process -ProcessName wpscloudsvr -ErrorAction SilentlyContinue | Out-Null
					if (Test-Path -Path "$env:USERPROFILE\AppData\Local\Kingsoft\WPS Office\11.2.0.9629\office6\auth.dll") {
						Copy-Item -Path "$PSScriptRoot\..\..\00\AIO\auth.dll" -Destination "$env:USERPROFILE\AppData\Local\Kingsoft\WPS Office\11.2.0.9629\office6\auth.dll" -ErrorAction SilentlyContinue
					}
				}
			}
		}
		StartInstallSoftware -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "Yi\Yi\AIO" -url "https://www.sordum.org/files/small-tools" -packer "NetDisabler" -types "zip" -filename "NetDisabler*" -param "/E" -method ""

		if ($Redundant.Checked) {
			Write-Host "   - $($lang.Delete) $($lang.Redundant)`n"
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\WPS PDF.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\WPS演示.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:USERPROFILE\Desktop\WPS PDF.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:USERPROFILE\Desktop\WPS演示.lnk" -ErrorAction SilentlyContinue
		}
		if ($Update.Checked) {
			Write-Host "   - $($lang.Disable) $($lang.PlanTask) ( WpsUpdateTask_Administrator )`n"
			Disable-ScheduledTask -TaskPath "\" -TaskName "WpsUpdateTask_Administrator" -ErrorAction SilentlyContinue | Out-Null
		}
		if ($TaskBar.Checked) { ResetTaskBar }
		if ($ResetDesk.Checked) { ResetDesktop }
		$FormOffice.Close()
	}
	$FormOffice        = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $lang.InstlOffice
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$Office            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Instl) $($lang.Office)"
		Checked        = $true
	}
	$Disconnected      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.Disconnected
		Checked        = $true
	}
	$Patch             = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.Patch
		Checked        = $true
	}
	$Redundant         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Delete) $($lang.Redundant)"
		Checked        = $true
	}
	$Update            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Disable) $($lang.PlanTask) ( WpsUpdateTask_Administrator )"
		Checked        = $true
	}
	$TaskBar           = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$ResetDesk         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 405
		Text           = $lang.ResetDesk
		Checked        = $true
	}
	$FormOffice.controls.AddRange($Pane1)
	$FormOffice.controls.AddRange($AllSel)
	$FormOffice.controls.AddRange($AllClear)
	$FormOffice.controls.AddRange($Start)
	$FormOffice.controls.AddRange($Canel)
	$Pane1.controls.AddRange($Office)
	$Pane1.controls.AddRange($Disconnected)
	$Pane1.controls.AddRange($Patch)
	$Pane1.controls.AddRange($Redundant)
	$Pane1.controls.AddRange($Update)
	$Pane1.controls.AddRange($TaskBar)
	$Pane1.controls.AddRange($ResetDesk)
	$FormOffice.FormBorderStyle = 'Fixed3D'
	$FormOffice.ShowDialog() | Out-Null
}

Function DisableTakeOwnership {
	Write-Host "   $($lang.Delete) $($lang.AddOwnership)" -ForegroundColor Green
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Drive\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function EnableTakeOwnership {
	Write-Host "   $($lang.AddTo) $($lang.AddOwnership)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command") -ne $true) {  New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command" -force -ea SilentlyContinue }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'HasLUAShield' -Value '' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value '' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'Position' -Value 'middle' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'AppliesTo' -Value "NOT (System.ItemPathDisplay:=\""$env:SystemDrive\Users\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\ProgramData\"" OR System.ItemPathDisplay:=\""$env:SystemRoot\"" OR System.ItemPathDisplay:=\""$env:SystemRoot\System32\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\Program Files\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\Program Files (x86)\"")" -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'HasLUAShield' -Value '' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value '' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'Position' -Value 'middle' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'HasLUAShield' -Value '' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value '' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'Position' -Value 'middle' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name 'HasLUAShield' -Value '' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name 'MUIVerb' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name '(default)' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue
	RefreshIconCache
	Write-Host "   - $($lang.Done)`n"
}

Function DisableHibernation {
	Write-Host "   $($lang.Close) $($lang.Hibernation)" -ForegroundColor Green
	Start-Process 'powercfg.exe' -Verb runAs -ArgumentList '/h off' -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function EnableHibernation {
	Write-Host "   $($lang.Enable) $($lang.Hibernation)" -ForegroundColor Green
	Start-Process 'powercfg.exe' -ArgumentList '/h on' -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function SetPowerSupply {
	Write-Host "   $($lang.Setting) $($lang.PowerSupply)" -ForegroundColor Green
	powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
	powercfg -change -monitor-timeout-ac 0
	powercfg -change -monitor-timeout-dc 0
	powercfg -change -disk-timeout-ac 0
	powercfg -change -disk-timeout-dc 5
	powercfg -change -standby-timeout-ac 0
	powercfg -change -standby-timeout-dc 60
	powercfg -change -hibernate-timeout-ac 0
	powercfg -change -hibernate-timeout-dc 300
	powercfg /SETACVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
	powercfg /SETDCVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
	Write-Host "   - $($lang.Done)`n"
}

Function RestorePowerSupply {
	Write-Host "   $($lang.Restore) $($lang.PowerSupply)" -ForegroundColor Green
	powercfg -restoredefaultschemes
	Write-Host "   - $($lang.Done)`n"
}

Function EnableAppRestartScreen {
	Write-Host "   $($lang.Enable) $($lang.AppRestartScreen)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
	Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name WaitToKillAppTimeout -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name HungAppTimeout -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name AutoEndTasks -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name AutoEndTasks -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableAppRestartScreen {
	Write-Host "   $($lang.Disable) $($lang.AppRestartScreen)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillAppTimeout' -Value '4000' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'HungAppTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableArrow {
	Write-Host "   $($lang.Delete) $($lang.ShortcutArrow)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons") -ne $true) {  New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Value "$env:SystemRoot\system32\imageres.dll,197" -PropertyType String -Force -ea SilentlyContinue | out-null
	Remove-Item -Path "$env:USERPROFILE\AppData\Local\iconcache.db" -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'link' -Value ([byte[]](0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreArrow {
	Write-Host "   $($lang.Restore) $($lang.ShortcutArrow)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\IE.AssocFile.URL' -Name 'IsShortcut' -Value '' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\InternetShortcut' -Name 'IsShortcut' -Value '' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\lnkfile' -Name 'IsShortcut' -Value '' -PropertyType String -Force -ea SilentlyContinue | out-null
	Remove-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Force -ea SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name link -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function EnableNumlock {
	Write-Host "   $($lang.Setting) $($lang.Numlock)" -ForegroundColor Green
	If (-not (Test-Path "HKU:")) {
		New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
	}
	Set-ItemProperty -Path "HKU:\.DEFAULT\Control Panel\Keyboard" -Name "InitialKeyboardIndicators" -Type DWord -Value 2147483650 -ErrorAction SilentlyContinue
	Add-Type -AssemblyName System.Windows.Forms
	If (-not ([System.Windows.Forms.Control]::IsKeyLocked('NumLock'))) {
		$wsh = New-Object -ComObject WScript.Shell
		$wsh.SendKeys('{NUMLOCK}')
	}
	Write-Host "   - $($lang.Done)`n"
}

Function DisableNumlock {
	Write-Host "   $($lang.Cancel) $($lang.Numlock)" -ForegroundColor Green
	If (-not(Test-Path "HKU:")) {
		New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
	}
	Set-ItemProperty -Path "HKU:\.DEFAULT\Control Panel\Keyboard" -Name "InitialKeyboardIndicators" -Type DWord -Value 2147483648 -ErrorAction SilentlyContinue
	Add-Type -AssemblyName System.Windows.Forms
	If ([System.Windows.Forms.Control]::IsKeyLocked('NumLock')) {
		$wsh = New-Object -ComObject WScript.Shell
		$wsh.SendKeys('{NUMLOCK}')
	}
	Write-Host "   - $($lang.Done)`n"
}

Function SetUACNever {
	Write-Host "   $($lang.Setting) $($lang.UAC)$($lang.UACNever)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function SetUACDefault {
	Write-Host "   $($lang.Restore) $($lang.UAC)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 5 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableSmartScreen {
	Write-Host "   $($lang.Disable) $($lang.SmartScreen)" -ForegroundColor Green
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "Off"
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -Type DWord -Value 0
	$edge = (Get-AppxPackage -AllUsers "Microsoft.MicrosoftEdge").PackageFamilyName
	If (-not (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$edge\MicrosoftEdge\PhishingFilter")) {
		New-Item -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$edge\MicrosoftEdge\PhishingFilter" -Force | Out-Null
	}
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$edge\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -Type DWord -Value 0
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$edge\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n"
}

Function EnableSmartScreen {
	Write-Host "   $($lang.Enable) $($lang.SmartScreen)" -ForegroundColor Green
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "RequireAdmin"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -ErrorAction SilentlyContinue
	$edge = (Get-AppxPackage -AllUsers "Microsoft.MicrosoftEdge").PackageFamilyName
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$edge\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$edge\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function EnableMaintain {
	Write-Host "   $($lang.Disable) $($lang.Maintain)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -Name "MaintenanceDisabled" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableMaintain {
	Write-Host "   $($lang.Enable) $($lang.Maintain)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance") -ne $true) {  New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance' -Name 'MaintenanceDisabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function SetExperience {
	Write-Host "   $($lang.Disable) $($lang.Experience)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows") -ne $true) {  New-Item "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreExperience {
	Write-Host "   $($lang.Restore) $($lang.Experience)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -Name "CEIPEnable" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableSafetyWarnings {
	Write-Host "   $($lang.Disable) $($lang.SafetyWarnings)" -ForegroundColor Green
	Remove-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableSafetyWarnings {
	Write-Host "   $($lang.Enable) $($lang.SafetyWarnings)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations") -ne $true) {  New-Item "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes' -Value '.exe;.reg;.msi;.bat;.cmd;.com;.vbs;.hta;.scr;.pif;.js;' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableQOS {
	Write-Host "   $($lang.Disable) $($lang.QOS)" -ForegroundColor Green
	Start-Process -FilePath "$PSScriptRoot\..\AIO\nvspbind.exe" -ArgumentList "/d ""*"" ms_pacer" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function EnableQOS {
	Write-Host "   $($lang.Enable) $($lang.QOS)" -ForegroundColor Green
	Start-Process -FilePath "$PSScriptRoot\..\AIO\nvspbind.exe" -ArgumentList "/e ""*"" ms_pacer" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function DisableNetworkTuning {
	Write-Host "   $($lang.Disable) $($lang.NetworkTuning)" -ForegroundColor Green
	netsh interface tcp set global autotuninglevel=disabled | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableNetworkTuning {
	Write-Host "   $($lang.Enable) $($lang.NetworkTuning)" -ForegroundColor Green
	netsh interface tcp set global autotuninglevel=normal | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableECN {
	Write-Host "   $($lang.Disable) $($lang.ECN)" -ForegroundColor Green
	netsh int tcp set global ecn=disable | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableECN {
	Write-Host "   $($lang.Enable) $($lang.ECN)" -ForegroundColor Green
	netsh int tcp set global ecn=enabled | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableErrorRecovery {
	Write-Host "   $($lang.Disable) $($lang.ErrorRecovery)" -ForegroundColor Green
	bcdedit /set `{current`} bootstatuspolicy ignoreallfailures | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableErrorRecovery {
	Write-Host "   $($lang.Enable) $($lang.ErrorRecovery)" -ForegroundColor Green
	bcdedit /set {default} bootstatuspolicy DisplayAllFailures | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableDEPPAE {
	Write-Host "   $($lang.Disable) $($lang.DEP)" -ForegroundColor Green
	bcdedit /set `{current`} nx AlwaysOff
	bcdedit /set `{current`} pae ForceDisable
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreDEPPAE {
	Write-Host "   $($lang.Enable) $($lang.DEP)" -ForegroundColor Green
	bcdedit /deletevalue `{current`} pae 
	bcdedit /set `{current`} nx OptIn
	Write-Host "   - $($lang.Done)`n"
}

Function DisablePowerFailure {
	Write-Host "   $($lang.Disable) $($lang.PowerFailure)" -ForegroundColor Green
	bcdedit /set `{current`} Recoveryenabled No | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function EnablePowerFailure {
	Write-Host "   $($lang.Enable) $($lang.PowerFailure)" -ForegroundColor Green
	bcdedit /set `{current`} Recoveryenabled Yes | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableScheduledTasks {
	Write-Host "   $($lang.Disable) $($lang.ScheduledTasks)" -ForegroundColor Green
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\AIO\Opt\utils\disable-scheduled-tasks.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreScheduledTasks {
	Write-Host "   $($lang.Restore) $($lang.ScheduledTasks)" -ForegroundColor Green
	Write-Host "   - $($lang.NotSupport)"
}

Function DisableOptUser {
	Write-Host "   $($lang.Disable) $($lang.OptUser)" -ForegroundColor Green
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\AIO\Opt\scripts\optimize-user-interface.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreOptUser {
	Write-Host "   $($lang.Restore) $($lang.OptUser)" -ForegroundColor Green
	Write-Host "   - $($lang.NotSupport)"
}

Function DisableOptUpdate {
	Write-Host "   $($lang.Optimize) $($lang.OptUpdate)" -ForegroundColor Green
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\AIO\Opt\scripts\optimize-windows-update.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreOptUpdate {
	Write-Host "   $($lang.Restore) $($lang.OptUpdate)" -ForegroundColor Green
	Write-Host "   - $($lang.NotSupport)"
}

Function DisableFixPrivacy {
	Write-Host "   $($lang.Optimize) $($lang.FixPrivacy)" -ForegroundColor Green
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\AIO\Opt\scripts\fix-privacy-settings.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreFixPrivacy {
	Write-Host "   $($lang.Restore) $($lang.FixPrivacy)" -ForegroundColor Green
	Write-Host "   - $($lang.NotSupport)"
}

Function DisableAutoDetect {
	Write-Host "   $($lang.Disable) $($lang.IEAutoSet)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableAutoDetect {
	Write-Host "   $($lang.Enable) $($lang.IEAutoSet)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function IEProxy {
	Write-Host "   $($lang.Restore) $($lang.IEProxy)" -ForegroundColor Green
	"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections [1 7 17]" | Out-File -FilePath "$env:TEMP\ie_proxy.ini" -Encoding ASCII
	Start-Process "regini" -ArgumentList "$env:TEMP\ie_proxy.ini" -WindowStyle Minimized
	Remove-Item -Path "$env:TEMP\ie_proxy.ini" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function SetMergeTaskbarNever {
	Write-Host "   $($lang.Setting) $($lang.MergeTaskbarNever)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarGlomLevel' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DefaultMergeTaskbarNever {
	Write-Host "   $($lang.Restore) $($lang.MergeTaskbarNever)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name TaskbarGlomLevel -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function SetNotificationAlways {
	Write-Host "   $($lang.Setting) $($lang.NotificationAlways)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'EnableAutoTray' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DefaultNotificationAlways {
	Write-Host "   $($lang.Restore) $($lang.NotificationAlways)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name EnableAutoTray -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function SetNavShowAll {
	Write-Host "   $($lang.Setting) $($lang.NavShowAll)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'NavPaneExpandToCurrentFolder' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreNavShowAll {
	Write-Host "   $($lang.Restore) $($lang.NavShowAll)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "NavPaneExpandToCurrentFolder" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function SetCortana {
	Write-Host "   $($lang.Setting) $($lang.Cortana)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreCortana {
	Write-Host "   $($lang.Restore) $($lang.Cortana)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowCortanaButton" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function HideRecentShortcuts {
	Write-Host "   $($lang.Disable) $($lang.QuickAccess)" -ForegroundColor Green
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -Type DWord -Value 0
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -Type DWord -Value 0
	Remove-Item -Path "$env:appdata\Microsoft\Windows\Recent\*.*"
	Write-Host "   - $($lang.Done)`n"
}

Function ShowRecentShortcuts {
	Write-Host "   $($lang.Enable) $($lang.QuickAccess)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableMemoryCompression {
	Write-Host "   $($lang.Disable) $($lang.MemoryCompression)" -ForegroundColor Green
	Disable-MMAgent -mc
	Write-Host "   - $($lang.Done)`n"
}

Function EnableMemoryCompression {
	Write-Host "   $($lang.Enable) $($lang.MemoryCompression)" -ForegroundColor Green
	Enable-MMAgent -mc
	Write-Host "   - $($lang.Done)`n"
}

Function DisablePrelaunch {
	Write-Host "   $($lang.Disable) $($lang.Prelaunch)" -ForegroundColor Green
	Disable-MMAgent -ApplicationPreLaunch
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue;
	Write-Host "   - $($lang.Done)`n"
}

Function EnablePrelaunch {
	Write-Host "   $($lang.Enable) $($lang.Prelaunch)" -ForegroundColor Green
	Enable-MMAgent -ApplicationPreLaunch
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue;
	Write-Host "   - $($lang.Done)`n"
}

Function OptSSD {
	Write-Host "   $($lang.Optimize) $($lang.OptSSD)" -ForegroundColor Green
	fsutil behavior set DisableLastAccess 1 | Out-Null
	fsutil behavior set EncryptPagingFile 0 | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DefaultOptSSD {
	Write-Host "   $($lang.Restore) $($lang.OptSSD)" -ForegroundColor Green
	fsutil behavior set DisableLastAccess 2 | Out-Null
	fsutil behavior set EncryptPagingFile 0 | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableCompatibility {
	Write-Host "   $($lang.Disable) $($lang.Compatibility)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat") -ne $true) {  New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'DisablePCA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableCompatibility {
	Write-Host "   $($lang.Restore) $($lang.Compatibility)" -ForegroundColor Green
	Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function OptAnimationEffects {
	Write-Host "   $($lang.Optimize) $($lang.AnimationEffects)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM") -ne $true) {  New-Item "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM' -Name 'DisallowAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'EnableAeroPeek' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'AlwaysHibernateThumbnails' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'TurnOffSPIAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name 'VisualFXSetting' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAnimations' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewAlphaSelect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewShadow' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'IconsOnly' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x9e,0x1e,0x07,0x80,0x12,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'DragFullWindows' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'FontSmoothing' -Value '2' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreAnimationEffects {
	Write-Host "   $($lang.Restore) $($lang.AnimationEffects)" -ForegroundColor Green
	Write-Host "   - $($lang.NotSupport)"
}

Function DisableDefragmentation {
	Write-Host "   $($lang.Disable) $($lang.Defragmentation)" -ForegroundColor Green
	Disable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableDefragmentation {
	Write-Host "   $($lang.Enable) $($lang.Defragmentation)" -ForegroundColor Green
	Enable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DisablePhotoPreview {
	Write-Host "   $($lang.Disable) $($lang.PhotoPreview)" -ForegroundColor Green
	Remove-Item -Path "HKCU:\Software\Classes\.jpg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.jpeg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.gif" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.png" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.bmp" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.tiff" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.ico" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function EnablePhotoPreview {
	Write-Host "   $($lang.Enable) $($lang.PhotoPreview)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpg") -ne $true) {  New-Item "HKCU:\Software\Classes\.jpg" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpeg") -ne $true) {  New-Item "HKCU:\Software\Classes\.jpeg" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKCU:\Software\Classes\.gif") -ne $true) {  New-Item "HKCU:\Software\Classes\.gif" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKCU:\Software\Classes\.png") -ne $true) {  New-Item "HKCU:\Software\Classes\.png" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKCU:\Software\Classes\.bmp") -ne $true) {  New-Item "HKCU:\Software\Classes\.bmp" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKCU:\Software\Classes\.tiff") -ne $true) {  New-Item "HKCU:\Software\Classes\.tiff" -force -ea SilentlyContinue }
	if((Test-Path -LiteralPath "HKCU:\Software\Classes\.ico") -ne $true) {  New-Item "HKCU:\Software\Classes\.ico" -force -ea SilentlyContinue }
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpeg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.gif' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.png' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.bmp' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.tiff' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.ico' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function SetRAM {
	Write-Host "   $($lang.Setting) $($lang.RAM)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 67108864 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreRAM {
	Write-Host "   $($lang.Restore) $($lang.RAM)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 3670016 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function SetPwdUnlimited {
	Write-Host "   $($lang.Setting) $($lang.PwdUnlimited)" -ForegroundColor Green
	net accounts /maxpwage:UNLIMITED | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestorePwdUnlimited {
	Write-Host "   $($lang.Restore) $($lang.PwdUnlimited)" -ForegroundColor Green
	net accounts /maxpwage:42 | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableGamebar {
	Write-Host "   $($lang.Disable) $($lang.Gamebar)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AudioCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'CursorCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'MicrophoneCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableGamebar {
	Write-Host "   $($lang.Enable) $($lang.Gamebar)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AppCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AudioCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableGameMode {
	Write-Host "   $($lang.Disable) $($lang.GameMode)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AutoGameModeEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue;
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AllowAutoGameMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue;
	Write-Host "   - $($lang.Done)`n"
}

Function EnableGameMode {
	Write-Host "   $($lang.Enable) $($lang.GameMode)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableProtected {
	Write-Host "   $($lang.Disable) $($lang.Protected)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments") -ne $true) {  New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -force -ea SilentlyContinue | Out-Null }
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreProtected {
	Write-Host "   $($lang.Enable) $($lang.Protected)" -ForegroundColor Green
	Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function DisableMultipleIncrease {
	Write-Host "   $($lang.Disable) $($lang.MultipleIncrease)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'MultipleInvokePromptMinimum' -Value 999 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreMultipleIncrease {
	Write-Host "   $($lang.Enable) $($lang.MultipleIncrease)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer" -Name MultipleInvokePromptMinimum -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableAutoplay {
	Write-Host "   $($lang.Disable) $($lang.Autoplay)" -ForegroundColor Green
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 1
	Write-Host "   - $($lang.Done)`n"
}

Function EnableAutoplay {
	Write-Host "   $($lang.Enable) $($lang.Autoplay)" -ForegroundColor Green
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n"
}

Function DisableAutorun {
	Write-Host "   $($lang.Disable) $($lang.Autorun)" -ForegroundColor Green
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer")) {
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" | Out-Null
	}
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -Type DWord -Value 255
	Write-Host "   - $($lang.Done)`n"
}

Function EnableAutorun {
	Write-Host "   $($lang.Enable) $($lang.Autorun)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableErrorReporting {
	Write-Host "   $($lang.Disable) $($lang.ErrorReporting)" -ForegroundColor Green
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -Type DWord -Value 1
	Write-Host "   - $($lang.Done)`n"
}

Function EnableErrorReporting {
	Write-Host "   $($lang.Enable) $($lang.ErrorReporting)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableF8BootMenu {
	Write-Host "   $($lang.Disable) $($lang.F8BootMenu)" -ForegroundColor Green
	bcdedit /set `{current`} bootmenupolicy Standard | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function EnableF8BootMenu {
	Write-Host "   $($lang.Enable) $($lang.F8BootMenu)" -ForegroundColor Green
	bcdedit /set `{current`} bootmenupolicy Legacy | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function SendTo {
	Write-Host "   $($lang.Clean) $($lang.SendTo)" -ForegroundColor Green
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Mail Recipient.MAPIMail" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\邮件收件人.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Fax Recipient.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\传真收件人.lnk" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function CleanSystemLog {
	Write-Host "   $($lang.Clean) $($lang.Logs)" -ForegroundColor Green
	Get-EventLog -LogName * | ForEach-Object { Clear-EventLog $_.Log }
	Write-Host "   - $($lang.Done)`n"
}

Function CleanSxS {
	Write-Host "   $($lang.Clean) $($lang.SxS)" -ForegroundColor Green
	Dism /Online /Cleanup-Image /AnalyzeComponentstore
	Dism /Online /Cleanup-Image /StartComponentCleanup /ResetBase
	Write-Host "   - $($lang.Done)`n"
}

$Notifications = @(
	"windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel" # Settings
	"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.calendar"    # Calendar
	"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.mail"        # Mail
	"Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge" # Edge
	"Microsoft.Windows.Cortana_cw5n1h2txyewy!CortanaUI"   # Cortana
	"Windows.SystemToast.AudioTroubleshooter"    # Audio
	"Windows.SystemToast.Suggested"              # Suggested
	"Microsoft.WindowsStore_8wekyb3d8bbwe!App"   # Store
	"Windows.SystemToast.SecurityAndMaintenance" # Security and Maintenance
	"Windows.SystemToast.WiFiNetworkManager"     # Wireless
	"Windows.SystemToast.HelloFace"              # Windows Hello
	"Windows.SystemToast.RasToastNotifier"       # VPN
	"Windows.System.Continuum"                   # Tablet
	"Microsoft.BingNews_8wekyb3d8bbwe!AppexNews" # News
	"Windows.SystemToast.BdeUnlock"              # Bitlocker
	"Windows.SystemToast.BackgroundAccess"       # Battery Saver
	"Windows.Defender.SecurityCenter"            # Security Center
	"Microsoft.Windows.Photos_8wekyb3d8bbwe!App" # Photos
	"Microsoft.SkyDrive.Desktop"                 # OneDrive
	#"Windows.SystemToast.AutoPlay"              # Autoplay
)

Function DisableActionCenter {
	Write-Host "   $($lang.Disable) $($lang.Notification) $($lang.Full)" -ForegroundColor Green
	If (-not (Test-Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer")) {
		New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" | Out-Null
	}
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreActionCenter {
	Write-Host "   $($lang.Enable) $($lang.Notification) $($lang.Full)" -ForegroundColor Green
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function DisableActionCenterPart {
	Write-Host "   $($lang.Disable) $($lang.Notification) $($lang.Part)" -ForegroundColor Green
	if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications") -ne $true) {  New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -force -ea SilentlyContinue }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications' -Name 'DisableEnhancedNotifications' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

	New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Force -ErrorAction SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableSoftLanding' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

	foreach ($Name in $Notifications) {
		if((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name") -ne $true) {
			New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -force -ea SilentlyContinue | Out-Null
		}

		New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	netsh firewall set notifications mode=disable profile=all | Out-Null
	netsh firewall set opmode exceptions=disable | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestoreActionCenterPart {
	Write-Host "   $($lang.Restore) $($lang.Notification) $($lang.Part)" -ForegroundColor Green
	Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	
	foreach ($Name in $Notifications) {
		New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	netsh firewall set notifications mode=enable profile=all | Out-Null
	netsh firewall set opmode exceptions=enable | Out-Null
	Write-Host "   - $($lang.Done)`n"
}


Function PagingSize {
	param (
		[string]$size
	)
	Write-Host "   $($lang.Setting) $($lang.PagingSize) $($size)G" -ForegroundColor Green
	switch ($size) {
		8 { New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$env:SystemDrive\pagefile.sys 8192 8192") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null }
		16 { New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$env:SystemDrive\pagefile.sys 16384 16384") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null }
	}
	Write-Host "   - $($lang.Done)`n"
}

Function RestorePagingSize {
	Write-Host "   $($lang.Restore) $($lang.PagingSize)" -ForegroundColor Green
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("?:\pagefile.sys") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n"
}

Function RestorePoint {
	Enable-ComputerRestore -drive $env:SystemDrive -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Checkpoint-Computer -description "Yi" -restorepointtype "Modify_Settings" -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 1440 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Disable-ComputerRestore -Drive $env:SystemDrive -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n"
}

Function RefreshIconCache {
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

$ResetDesktopReg = @(
	'HKCU:\Software\Microsoft\Windows\Shell\BagMRU'
	'HKCU:\Software\Microsoft\Windows\Shell\Bags'
	'HKCU:\Software\Microsoft\Windows\ShellNoRoam\Bags'
	'HKCU:\Software\Microsoft\Windows\ShellNoRoam\BagMRU'
	'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
	'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags'
	'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\Bags'
	'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
)

Function ResetTaskBar {
	Write-Host "   $($lang.Reset) $($lang.TaskBar)" -ForegroundColor Green
	Write-Host "   - $($lang.Delete) $($lang.TaskBar)"
	Remove-Item -Path "$env:AppData\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\*.*"
	Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Start-Process -FilePath "$PSScriptRoot\..\AIO\syspin.exe" -WindowStyle Hidden -ArgumentList """$env:SystemRoot\explorer.exe"" ""5386""" -Wait

	Write-Host "   - $($lang.ResetExplorer)`n"
	Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
}

Function ResetDesktop {
	Write-Host "   $($lang.ResetDesk)" -ForegroundColor Green
	Write-Host "   - $($lang.ResetFolder)"
	foreach ($nsf in $ResetDesktopReg) {
		Remove-Item -Path $nsf -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.ResetExplorer)`n"
	Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
	RefreshIconCache
}

<#
	.Uninstall Module
#>
$AppsUncheck = @(
	"AdvancedMicroDevicesInc"
	"AppUp.IntelGraphicsControlPanel"
	"AppUp.IntelGraphicsExperience"
	"Microsoft.MicrosoftStickyNotes"
	"Microsoft.ScreenSketch"
	"Microsoft.Windows.Photos"
	"Microsoft.Photos.MediaEngineDLC"
	"Microsoft.WindowsAlarms"
	"Microsoft.WindowsCalculator"
	"Microsoft.WindowsCamera"
	"Microsoft.MicrosoftSolitaireCollection"
	"NVIDIACorp.NVIDIAControlPanel"
	"RealtekSemiconductorCorp.RealtekAudioControl"
)

$AppsExcluded = @(
	"Microsoft.549981C3F5F10"
	"Microsoft.DesktopAppInstaller"
	"Microsoft.StorePurchaseApp"
	"Microsoft.WindowsStore"
	"Microsoft.WebMediaExtensions"
	"Microsoft.BioEnrollment"
	"Microsoft.XboxGameCallableUI"
	"Microsoft.XboxIdentityProvider"
	"Microsoft.XboxApp"
	"Microsoft.GamingApp"
	"Microsoft.GamingServices"
	"Microsoft.Xbox.TCUI"
	"Microsoft.XboxSpeechToTextOverlay"
	"Microsoft.XboxGamingOverlay"
	"Microsoft.XboxGameOverlay"
)

Function UninstallApps {
	Logo -Title "$($lang.Delete) $($lang.UninstallUWP)"
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	if ($Force) {
		UninstallAppsGUI
	} else {
		UninstallAppsGUI
		ToMainpage -wait 2
	}
}

Function UninstallAppsGUI {
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$AllSel_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$AllClear_Click = {
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$Canel_Click = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$FormUn.Close()
	}
	$OK_Click = {
		$FormUn.Hide()
		$Pane1.Controls | ForEach-Object {
			if($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					Write-Host "   $($lang.UninstallNow -f $_.Text)"
					if ($AllUser.Checked) {
						Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "$($_.Tag)" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue
						Get-AppxPackage -Name "$($_.Tag)" | Remove-AppxPackage
					} else {
						Get-AppxPackage -Name "$($_.Tag)" | Remove-AppxPackage
					}
				}
			}
		}

		$cdm = @(
			"ContentDeliveryAllowed"
			"FeatureManagementEnabled"
			"OemPreInstalledAppsEnabled"
			"PreInstalledAppsEnabled"
			"PreInstalledAppsEverEnabled"
			"SilentInstalledAppsEnabled"
			"SubscribedContent-314559Enabled"
			"SubscribedContent-338387Enabled"
			"SubscribedContent-338388Enabled"
			"SubscribedContent-338389Enabled"
			"SubscribedContent-338393Enabled"
			"SubscribedContentEnabled"
			"SystemPaneSuggestionsEnabled"
		)

		Write-Host "`n   $($lang.PreventsApps)`n"
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Force -ErrorAction SilentlyContinue | Out-Null
		foreach ($key in $cdm) {
			New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name $key -Value 0 -PropertyType DWord -Force -ea SilentlyContinue
		}

		Write-Host "   $($lang.CloseStoreAuto)`n"
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore" -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -Name 'AutoDownload' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue

		Write-Host "   $($lang.PreventsSuggestApps)`n"
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue

		$FormUn.Close()
	}
	$FormUn            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = "$($lang.Delete) $($lang.UninstallUWP)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
		Icon           = New-Object system.drawing.icon ("$PSScriptRoot\..\icons\MainPanel.ico")
	}
	$Pane1             = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 440
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$AllSel            = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(10,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllSel_Click
		Text           = $lang.AllSel
	}
	$AllClear          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(88,482)
		Height         = 36
		Width          = 75
		add_Click      = $AllClear_Click
		Text           = $lang.AllClear
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(266,482)
		Height         = 36
		Width          = 75
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(345,482)
		Height         = 36
		Width          = 75
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$AllUser           = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = New-Object System.Drawing.Point(11,445)
		Height         = 36
		Width          = 200
		Text           = $lang.DeleteAllUser
		Checked        = $true
	}
	$FormUn.controls.AddRange($Pane1)
	$FormUn.controls.AddRange($AllSel)
	$FormUn.controls.AddRange($AllClear)
	$FormUn.controls.AddRange($Start)
	$FormUn.controls.AddRange($Canel)
	$FormUn.controls.AddRange($AllUser)

	[Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | Select-Object -ExpandProperty Id -Property DisplayName | Where-Object -FilterScript {
		($_.Name -in (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name) -and ($_.Name -notin $AppsExcluded) -and ($null -ne $_.DisplayName)} | ForEach-Object {
			$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
				Height = 30
				Width  = 405
				Text   = $_.DisplayName
				Tag    = $_.Name
			}
			if ($AppsUncheck.Contains($_.Name)) {
				$CheckBox.Checked = $False
			} else {
				$CheckBox.Checked = $True
			}
			$Pane1.controls.AddRange($CheckBox)
	}

	$FormUn.FormBorderStyle = 'Fixed3D'
	$FormUn.ShowDialog() | Out-Null
}
# Uninstall module End

<#
   .Enum Module
#>
Enum Status
{
	Enable
	Disable
}

Enum Mode
{
	Wait
	Fast
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}