﻿<#
   .Summary
	Yi's Solutions

   .Feature
	- Automatic recognition system subject
	- Rebuild Desktop.ini
	- Modify the contents of the registry
#>

function RefreshIconCache {
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

function SetDeskedit {
	param (
		[string]$ico
	)
	$Deskedit = "$PSScriptRoot\AIO\DeskEdit.exe"

	if (Test-Path $Deskedit -PathType Leaf) {
		Start-Process -FilePath $Deskedit -ArgumentList "/F=""$($env:SystemDrive)\Yi"" /S=.ShellClassInfo /L=IconResource=""$($env:SystemDrive)\Yi\Yi\icons\$($ico),0"""
	}
}

function SetRightMenu {
	param (
		[string]$ico
	)
	$YiMenu   = "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi"

	if (Get-ItemProperty -Path $YiMenu -Name 'icon' -ErrorAction SilentlyContinue) {
		New-ItemProperty -Path $YiMenu -Name "icon" -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\$($ico)" -PropertyType STRING -Force | Out-Null
	}
}

function IsDark {
	$SysTheme = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
	$Yi       = "HKCU:\SOFTWARE\Yi"

	if (!(Get-ItemProperty -Path $SysTheme -Name 'AppsUseLightTheme' -ErrorAction SilentlyContinue)) {
		write-host "6x0"
		exit
	}

	if (!(Test-Path $Yi)) {
		New-Item -Path $Yi -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath $Yi -Name 'isDark' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}

	if (!(Get-ItemProperty -Path $Yi -Name 'isDark' -ErrorAction SilentlyContinue)) {
		New-ItemProperty -LiteralPath $Yi -Name 'isDark' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}

	$resultSysTheme = Get-ItemPropertyValue -Path $SysTheme -Name "AppsUseLightTheme"
	$resultYiTheme = Get-ItemPropertyValue -Path $Yi -Name "isDark"

	switch($resultSysTheme)
	{
		"0" {
			Write-Output "Dark mode process"
			switch($resultYiTheme)
			{
				"0" {
					Write-Output "1. Jump over..."
				}
				"1" {
					Write-Output "2. Change"
					SetDeskedit -ico "Yi.Dark.ico"
					SetRightMenu -ico "Yi.Dark.ico"
					New-ItemProperty -Path $Yi -Name "isDark" -Value "0" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
				default {
					Write-Output "3. Change"
					SetDeskedit -ico "Yi.Dark.ico"
					SetRightMenu -ico "Yi.Dark.ico"
					New-ItemProperty -Path $Yi -Name "isDark" -Value "0" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
			}
		}
		"1" {
			Write-Output "Light mode process"
			switch($resultYiTheme)
			{
				"0" {
					Write-Output "4. Change"
					SetDeskedit -ico "Yi.ico"
					SetRightMenu -ico "Yi.ico"
					New-ItemProperty -Path $Yi -Name "isDark" -Value "1" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
				"1" {
					Write-Output "5. Jump over..."
				}
				default {
					Write-Output "6. Change"
					SetDeskedit -ico "Yi.ico"
					SetRightMenu -ico "Yi.ico"
					New-ItemProperty -Path $Yi -Name "isDark" -Value "1" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
			}
		}
	}
}

IsDark