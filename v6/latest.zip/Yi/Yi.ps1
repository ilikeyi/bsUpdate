﻿<#
	.Summary
	 Yi's Solutions

	.PowerShell must be run with elevated privileges, run
	 powershell -Command "Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force"

	.Or run in a PowerShell session, PS C:\>
	 Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force

	.EXAMPLE
	 PS C:\> .\Yi.ps1

	.LINK
	 https://github.com/ilikeyi/Solutions
	 https://gitee.com/ilikeyi/Solutions
#>

#Requires -RunAsAdministrator
#Requires -version 5.1

[CmdletBinding()]
param(
	[switch]$Force,
	[string[]]$Functions
)

Remove-Module -Name Yi -Force -ErrorAction Ignore
Import-Module -Name "$PSScriptRoot\Modules\Yi.psd1" -PassThru -Force

<#
	.Enable logging and save it in the script folder.
#>
# Logging

<#
	.Set language pack, usage:
	 Language                | Language selected by the user
	 Language -Auto          | Automatic matching
	 Language -Force "zh-CN" | Mandatory use of specified language
#>
Language -Auto

<#
	.Summary
	 Run function, support multiple conditions

	.EXAMPLE
	 .\Yi.ps1 -Function "Function1 -Param", "Function2 -Param"
#>
if ($Functions) {
	foreach ($Function in $Functions) {
		Invoke-Expression -Command $Function
	}
	exit
}

if ($Force) {
	Yi -Force
} else {
	Mainpage
}