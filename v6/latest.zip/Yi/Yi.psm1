﻿<#
	.Log function
#>
function Logging
{
	$LoggingFile = "Log-$(Get-Date -Format "yyyyMMddHHmmss")"
	Start-Transcript -Path "$PSScriptRoot\$LoggingFile.txt" -Force
}

<#
	.Language Module
#>
function Language {
	param (
		[string]$Force,
		[switch]$Reset,
		[switch]$Auto
	)
	$Host.UI.RawUI.WindowTitle = "Yi's Solution | Choose your country or region."

	if ($Reset) {
		$global:Lang = $null
	}
	
	if ($Auto) {
        LanguageChange -lng (Get-Culture).Name
		return
	}

	if (!([string]::IsNullOrEmpty($Force))){
		LanguageChange -lng $Force
		return
	}
	
	if (([string]::IsNullOrEmpty($global:Lang))){
		Clear-Host
		$eng = New-Object System.Management.Automation.Host.ChoiceDescription "&1 en-US", "eng"
		$chs = New-Object System.Management.Automation.Host.ChoiceDescription "&2 zh-CN", "chs"
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($eng, $chs)
		$title = '    Choose your country or region.'
		$message = "`n    North America`n[1] English ( United States )`n`n    Asia Pacific`n[2] 中文 ( 简体, 中国 )`n`n"
		$result = $host.ui.PromptForChoice($title, $message, $options, 0)
		switch ($result) {
			0 { LanguageChange -lng "en-US" }
			1 { LanguageChange -lng "zh-CN" }
		}
	} else {
		LanguageChange -lng $global:Lang
	}
}

function LanguageChange {
	param (
		[string]$lng
	)

	if (Test-Path "$PSScriptRoot\$($lng)\Yi.psd1" -PathType Leaf) {
		$global:Lang = $($lng)
		Import-LocalizedData -BindingVariable Global:Lang -FileName "Yi.psd1" -UICulture $lng
	} else {
        if (Test-Path "$PSScriptRoot\en-US\Yi.psd1" -PathType Leaf) {
            $global:Lang = "en-US"
            Import-LocalizedData -BindingVariable Global:Lang -FileName "Yi.psd1" -UICulture "en-US"
        } else {
            Clear-Host
            Write-Host "`n  There is no language pack locally, it will automatically exit after 6 seconds." -ForegroundColor Red
            Start-Sleep -s 6
            exit
        }
	}
}

function RefreshLanguage {
	Remove-Module -Name Yi -Force -ErrorAction Ignore
	Import-Module -Name $PSScriptRoot\Yi.psd1 -PassThru -Force | Out-Null
	Language
}
# Language Module End

<#
	.Main interface
#>
function Mainpage {
	$Host.UI.RawUI.WindowTitle = "Yi's Solution | $($lang.Mainpage)"
	Clear-Host
	Write-Host "`n   Author: Yi ( http://fengyi.tel )

   From: Yi's Solution
   buildstring: 6.0.0.0.bs_release.210120-1208

   $($lang.Mainpage)
   ---------------------------------------------------
   1. $($lang.Update)
   2. $($lang.ResetSolution) $($lang.Mainname)
   3. $($lang.DelSolution) $($lang.Mainname)
   4. $($lang.RefreshLang)
   5. $($lang.Oneclick) ABCDE
   6. $($lang.Oneclick) ABCDEF

   A. $($lang.ActivationOS)
   B. $($lang.InstallPS)
   C. $($lang.OptOS)
   D. $($lang.AddDesk)
   E. $($lang.DelOwnSoftware)
   F. $($lang.CloseOSSoftware)
   
   L. $($lang.SwitchLanguage)
   Q. $($lang.YiExit)`n"

	$select = Read-Host "   $($lang.Choose)"
	switch ($select) {
		'1' {
			Update
			RefreshLanguage
			ToMainpage -wait 6
		}
		'2' { Yi }
		'3' { Uninstall }
		'4' {
			HideDirectory
			Refresh
			LanguageSetting
			ScheduledTaskSettings
		}
		'5' { $global:Lang = 'zh-CN'
			Mainpage}
		'6' {}
		'a' {}
		'b' {}
		'c' {}
		'd' {}
		'e' {}
		'f' {
            RefreshLanguage
			Mainpage
        }
		'l' {
			Language -Reset
			Mainpage
		}
		'q' { exit }
		default { Mainpage }
	}
}

function ToMainpage {
	param(
		[int]$wait,
		[switch]$q
	)
	Write-Host $($lang.ToMsg -f $wait) -ForegroundColor Red
	Start-Sleep -s $wait
	if ($q) { exit }
	Mainpage
}
# Main interface End

<#
	.Add Yi's Solution
#>
function Yi {
	param(
		[switch]$Force
	)
	$Host.UI.RawUI.WindowTitle = "Yi's Solution | $($lang.ResetSolution)"

	Clear-Host
	Write-Host "`n   Author: Yi ( http://fengyi.tel )

   From: Yi's Solution
   buildstring: 6.0.0.0.bs_release.210120-1208

   任务计划
   ---------------------------------------------------
	- 静默自动更新脚本
	- 设置系统盘卷标：OS
	- 禁用 'Windows 10 的登录动画'
	- 添加 'Defender 排除目录'
	- 修复 'Yi 目录图标'
	- 隐藏目录或文件
	- 刷新语言
	- 添加桌面右键菜单
	- 安装字体
	- 设置键盘
	- 创建任务 \Yi\isDark"
	
	if ($Force) {
		YiAdd
		exit
	} else {
		$caption="$($lang.ResetSolution) ?"
		$message="继续（Y）`n取消（N）"
		$choices = @("&Yes","&No")
		$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription] 
		$choices | foreach  { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))} 
		$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 0)
		Switch ($prompt)
		{
			0 {
				YiAdd
				ToMainpage -wait 6
			}
			1 {
				ToMainpage -wait 2
			}
		}
	}
}

function YiAdd {
	Write-Host "`n   正在执行任务计划：" -ForegroundColor Cyan

	Write-Host "`n   正在强行更新脚本"
	Update -Force -IsProcess
	RefreshLanguage

	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue
	Unregister-ScheduledTask -TaskName "\Yi\isDark" -Confirm:$False -ErrorAction SilentlyContinue

	Write-Host "`n   正在设置系统盘卷标：OS"
	$disk = $env:SystemDrive -replace ':', ''
	Set-Volume -DriveLetter $disk -NewFileSystemLabel "OS"

	Write-Host "`n   正在禁用 Windows 10 的登录动画"
	New-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" -Force -ErrorAction SilentlyContinue | Out-Null

	Write-Host "`n   正在添加 'Defender 排除目录'"
	Add-MpPreference -ExclusionPath "$env:SystemDrive\Yi" -ErrorAction SilentlyContinue | Out-Null

	Write-Host "`n   正在修复 'Yi 目录图标'"
	if(Test-Path "$($env:SystemDrive)\Yi\Yi\AIO\DeskEdit.exe" -PathType Leaf ) {
		Start-Process -FilePath "$env:SystemDrive\Yi\Yi\AIO\DeskEdit.exe" -ArgumentList "/F=""$env:SystemDrive\Yi"" /S=.ShellClassInfo /L=IconResource=""$env:SystemDrive\Yi\Yi\icons\Yi.ico,0"""
	}
	
	HideDirectory
	Refresh -Force
	InstallFontsStart
	LanguageSetting
	ScheduledTaskSettings
}

<#
   .Uninstall
#>
function Uninstall {
	$Host.UI.RawUI.WindowTitle = "Yi's Solution | $($lang.DelSolution)"

	Clear-Host
	Write-Host "`n   Author: Yi ( http://fengyi.tel )

   From: Yi's Solution
   buildstring: 6.0.0.0.bs_release.210120-1208

   任务计划
   ---------------------------------------------------
   1. 下次登录后，删除：
      $($env:SystemDrive)\Yi
   2. 删除 $($env:SystemDrive)\Users\Default\Desktop\附赠解决方案.lnk
   3. 删除 当前公共桌面 附赠解决方案.lnk
   4. 删除 $($env:systemdrive)\ProgramData\Microsoft\Windows\Start Menu\Programs\Yi's Solution
   5. 删除 任务计划：\Yi\isDark
   6. 删除 桌面右键菜单
   7. 删除 Defender 排除目录
   8. 恢复 Powershell 执行策略：受限
   9. 删除 $($env:systemdrive)\Yi 目录下的所有文件"

	$caption="删除 '附赠解决方案'"
	$message="继续（Y）`n取消（N）"
	$choices = @("&Yes","&No")
	$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription] 
	$choices | foreach  { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))} 
	$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 1)
	Switch ($prompt)
	{
		0 {
			UninstallStart
			ToMainpage -wait 6
		}
		1 {
			ToMainpage -wait 2
		}
	}
}

function UninstallStart {
	Write-Host "`n   正在执行任务计划：" -ForegroundColor Cyan

	Write-Host "`n   正在使用或防止无法删除，下次登录后删除该目录："
	write-host "    $env:systemdrive\Yi"
	$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
	$regKey = "Clear Yi Folder"
	$regValue = "cmd.exe /c rd /s /q ""$($env:SystemDrive)\Yi"""
	if ((Test-Path $regPath)) {
		New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
	} else {
		New-Item -Path $regPath -Force | Out-Null
		New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
	}

	Write-Host "`n   正在删除 当前用户桌面 附赠解决方案.lnk"
	Remove-Item -Path "$env:USERPROFILE\Desktop\Bundled solution.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:USERPROFILE\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
	
	Write-Host "`n   正在删除 $env:SystemDrive\Users\Default\Desktop\附赠解决方案.lnk"
	Remove-Item -Path "$env:SystemDrive\Users\Default\Desktop\Bundled solution.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:SystemDrive\Users\Default\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
	
	Write-Host "`n   正在删除 $env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\Yi's Solution"
	$StartMenu = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\Yi's Solution"
	RemoveTree -Path $StartMenu
	
	Write-Host "`n   正在删除 任务计划：\Yi\isDark"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue
	Unregister-ScheduledTask -TaskName "\Yi\isDark" -Confirm:$False -ErrorAction SilentlyContinue

	Write-Host "`n   正在删除 桌面右键菜单"
	Remove-Item -Path "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.ControlCenter" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue | Out-Null
	
	Write-Host "`n   正在删除 Defender 排除目录"
	Remove-MpPreference -ExclusionPath "$env:SystemDrive\Yi"

	Write-Host "`n   正在恢复 Powershell 执行策略：受限"
	Set-ExecutionPolicy -ExecutionPolicy Restricted -Force

	Write-Host "`n   正在删除 $env:SystemDrive\Yi 目录下的所有文件"
	RemoveTree -Path "$env:SystemDrive\Yi"

	ToMainpage -wait 6 -q
}

<#
   .Hide catalog module
#>
$HideFolder = @(
	"Yi"
	"Fonts"
	"00"
	"00\AIO\rarreg.key"
	"10"
	"10\TFTPBoot"
	"10\tftpd32.ini"
	"10\GhostSrv_ZH.dll"
	"10\GhostExp_ZH.dll"
	"20"
	"30"
	"30\360DrvMgr"
	"30\DriverGenius"
	"30\DriverTalent"
	"30\3389"
	"30\Beyond Compare"
	"30\DiskGenius"
	"30\DnsJumper"
	"30\EasyBCD"
	"30\FastCopy"
	"30\FastStoneCapture"
	"30\Hash"
	"30\HashTab"
	"30\RegeditX"
	"30\RegShot"
	"30\rufus"
	"30\ventoy"
	"30\WinNTSetup"
	"30\PingPlotter"
	"30\WipeFile"
	"30\Everything"
	"30\SDCardFormatter"
	"30\TopMost"
	"40"
	"40\AIDA64"
	"40\ASSSDBenchmark"
	"40\CPU-Z"
	"40\FurMark"
	"40\GPU-Z"
	"40\GPUShark"
	"40\Hard Disk Sentinel"
	"40\HDDScan"
	"40\HDSpeed"
	"40\HDTune"
	"40\MaxxMEM2"
	"40\MemTest"
	"40\TxBENCH"
	"40\Victoria"
	"50"
	"50\AutoRuns"
	"50\DbgView"
	"50\DriverView"
	"50\FullEventLogView"
	"50\ProcessExplorer"
	"50\ProcessMonitor"
	"50\PUTTY"
	"50\Stud_PE"
	"50\TCPView"
	"60"
	"60\DefenderControl"
	"60\fab"
	"60\WindowsUpdateBlocker"
	"70"
	"70\Radmin"
	"70\TeamViewer"
	"70\TTVnc"
	"70\VNCView"
	"70\WinBox"
	"70\AnyDesk"
)

function HideDirectory {
	foreach ($nsf in $HideFolder) {
		Set-ItemProperty -Path "$env:SystemDrive\Yi\$nsf" -Name Attributes -Value Hidden -ErrorAction SilentlyContinue
	}
}
# Hide catalog module End

<#
	.Refresh module
#>
function Refresh {
	param(
		[switch]$Force
	)
	$Host.UI.RawUI.WindowTitle = "Yi's Solution | $($lang.RefreshLang)"

	If ($Force) {
		RefreshStart
	} else {
		Clear-Host
		Write-Host "`n   Author: Yi ( http://fengyi.tel )

   From: Yi's Solution
   buildstring: 6.0.0.0.bs_release.210120-1208

   任务计划：
   ---------------------------------------------------
	1. 删除旧快捷方式
	2. 验证软件包并生成快捷方式`n"

		Write-Host "   是否刷新？" -ForegroundColor Green
		$caption="刷新前请确认。"
		$message="继续刷新（Y）`n取消刷新（N）"
		$choices = @("&Yes","&No")
		$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription] 
		$choices | foreach  { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))} 
		$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 0)
		Switch ($prompt)
		{
			0 {
				Write-Host "`n   正在执行任务计划：" -ForegroundColor Cyan
				RefreshStart
				ToMainpage -wait 6
			}
			1 {
				ToMainpage -wait 2
			}
		}
	}
}
# Refresh module End

function RefreshStart {
	RightClickMenu
	Set-Location "$env:SystemDrive\Yi"
	$StartMenu = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\Yi's Solution"
	Remove-Item -Path "$env:SystemDrive\Users\Default\Desktop\Bundled solution.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:SystemDrive\Users\Default\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:USERPROFILE\Desktop\Bundled solution.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:USERPROFILE\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "00\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "30\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "40\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "50\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "60\*.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "70\*.lnk" -ErrorAction SilentlyContinue
	RemoveTree -Path $StartMenu
	CheckCatalog -chkpath $StartMenu

	if (Test-Path "Yi" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:USERPROFILE\Desktop\$($lang.MainHisName).lnk"" /a:c /t:""$env:SystemDrive\Yi"" /i:""$env:SystemDrive\Yi\Yi\icons\Yi.Gift.ico""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:USERPROFILE\Users\Default\Desktop\$($lang.MainHisName).lnk"" /a:c /t:""$env:SystemDrive\Yi"" /i:""$env:SystemDrive\Yi\Yi\icons\Yi.Gift.ico""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\- $($lang.Mainname) $($lang.MainFolder) -.lnk"" /a:c /t:""$env:SystemDrive\Yi"" /i:""$env:SystemDrive\Yi\Yi\icons\Yi.Gift.ico""" -WindowStyle Hidden
	}

	if (Test-Path "00" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder00).lnk"" /a:c /t:""$env:SystemDrive\Yi\00""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder00).lnk"" /a:c /t:""$env:SystemDrive\Yi\00""" -WindowStyle Hidden
	}

	if (Test-Path "10" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.ICONFolder00)"
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder10).lnk"" /a:c /t:""$env:SystemDrive\Yi\10""" -WindowStyle Hidden
		
		if (Test-Path -Path "c:\Yi\10\CGI-plus.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder10)\CGi-plus.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\CGI-plus.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\CGI-plus.exe""" -WindowStyle Hidden }
		if (Test-Path -Path "10\Ghost64.exe" ) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder10)\Symantec Ghost.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\Ghost64.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\Ghost64.exe""" -WindowStyle Hidden }
		if (Test-Path -Path "10\GhostExp.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder10)\Symantec Ghost Explorer.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\GhostExp.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\GhostExp.exe""" -WindowStyle Hidden }
		if (Test-Path -Path "10\GhostSrv.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder10)\Symantec GhostCast Server.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\GhostSrv.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\GhostSrv.exe""" -WindowStyle Hidden }
		if (Test-Path -Path "10\tftpd64.exe" ) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder10)\Tftpd.lnk"" /a:c /t:""$env:SystemDrive\Yi\10\tftpd64.exe"" /w:""$env:SystemDrive\Yi\10"" /i:""$env:SystemDrive\Yi\10\tftpd64.exe""" -WindowStyle Hidden }
	}

	#chkfolder
	if (Test-Path "20" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder20).lnk"" /a:c /t:""$env:SystemDrive\Yi\20""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder20).lnk"" /a:c /t:""$env:SystemDrive\Yi\20""" -WindowStyle Hidden
	}
	if (Test-Path "30" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.ICONFolder30)"
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder30).lnk"" /a:c /t:""$env:SystemDrive\Yi\30""" -WindowStyle Hidden
	}
	if (Test-Path "40" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.ICONFolder40)"
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder40).lnk"" /a:c /t:""$env:SystemDrive\Yi\40""" -WindowStyle Hidden
	}
	if (Test-Path "50" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.ICONFolder50)"
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder50).lnk"" /a:c /t:""$env:SystemDrive\Yi\50""" -WindowStyle Hidden
	}
	if (Test-Path "60" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.ICONFolder60)"
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder60).lnk"" /a:c /t:""$env:SystemDrive\Yi\60""" -WindowStyle Hidden
	}
	if (Test-Path "70" -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.ICONFolder70)"
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\$($lang.ICONFolder70).lnk"" /a:c /t:""$env:SystemDrive\Yi\70""" -WindowStyle Hidden
	}

	#00
	switch ((Get-Culture).Name) {
		'zh-CN' {
			if (Test-Path -Path "Yi\zh-CN\Instl.ps1") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\- 编辑或右键运行安装软件 -.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\Instl.ps1""" -WindowStyle Hidden }
		}
		default {
			if (Test-Path -Path "Yi\en-US\Instl.ps1") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\- 编辑或右键运行安装软件 -.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\en-US\Instl.ps1""" -WindowStyle Hidden }
		}
	}

	if (Test-Path -Path "Yi\Yi.ps1") {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\- $($lang.Mainname) $($lang.Mainpage) -.lnk"" /a:c /t:""powershell"" /p:""-File $env:SystemDrive\Yi\Yi\Yi.ps1"" /i:""$env:SystemDrive\Yi\Yi\icons\Yi.Gift.ico""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\- $($lang.Mainname) $($lang.Mainpage) -.lnk"" /a:c /t:""powershell"" /p:""-File $env:SystemDrive\Yi\Yi\Yi.ps1"" /i:""$env:SystemDrive\Yi\Yi\icons\Yi.Gift.ico""" -WindowStyle Hidden
	}

	if (Test-Path -Path "Yi\zh-CN\OC.browser.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\安装 'Chrome 浏览器'.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\OC.browser.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\OC.Office.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\安装 '办公软件'.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\OC.Office.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "00\AIO\Xunlei.zh-CN.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\00\安装 '迅雷 11'.lnk"" /a:c /t:""$env:SystemDrive\Yi\00\AIO\Xunlei.zh-CN.exe"" /i:""$env:SystemDrive\Yi\00\AIO\Xunlei.zh-CN.exe""" -WindowStyle Hidden }

	#30
	if (Test-Path "30\360DrvMgr" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\$($lang.ICONFolder360DrvMgr).lnk"" /a:c /t:""$env:SystemDrive\Yi\30\360DrvMgr\360DrvMgr.exe"" /w:""$env:SystemDrive\Yi\30\360DrvMgr"" /i:""$env:SystemDrive\Yi\30\360DrvMgr\360DrvMgr.exe""" -WindowStyle Hidden }
	if (Test-Path "30\DriverTalent" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Driver Updater.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DriverTalent\Driver Talent.exe"" /w:""$env:SystemDrive\Yi\30\DriverTalent"" /i:""$env:SystemDrive\Yi\30\DriverTalent\Driver Talent.exe""" -WindowStyle Hidden }
	if (Test-Path "30\DriverGenius" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\$($lang.ICONFolderDriverGenius).lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DriverGenius\DriverGenius.exe"" /w:""$env:SystemDrive\Yi\30\DriverGenius"" /i:""$env:SystemDrive\Yi\30\DriverGenius\DriverGenius.exe""" -WindowStyle Hidden }
	if (Test-Path "30\DiskGenius" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\DiskGenius.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DiskGenius\Diskgenius.bat"" /w:""$env:SystemDrive\Yi\30\DiskGenius"" /i:""$env:SystemDrive\Yi\30\DiskGenius\Diskgenius.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\WinNTSetup" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\WinNTSetup.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\WinNTSetup\WinNTSetup.exe"" /w:""$env:SystemDrive\Yi\30\WinNTSetup"" /i:""$env:SystemDrive\Yi\30\WinNTSetup\WinNTSetup.exe""" -WindowStyle Hidden }
	if (Test-Path "30\rufus" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Rufus.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\rufus\rufus.bat"" /w:""$env:SystemDrive\Yi\30\rufus"" /i:""$env:SystemDrive\Yi\30\rufus\rufus.exe"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\FastCopy" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\FastCopy.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\FastCopy\FastCopy.bat"" /w:""$env:SystemDrive\Yi\30\FastCopy"" /i:""$env:SystemDrive\Yi\30\FastCopy\FastCopy.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\DnsJumper" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\DNS Jumper.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\DnsJumper\DnsJumper.bat"" /w:""$env:SystemDrive\Yi\30\DnsJumper"" /i:""$env:SystemDrive\Yi\30\DnsJumper\DnsJumper.exe"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\EasyBCD" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\EasyBCD.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\EasyBCD\EasyBCD.exe"" /w:""$env:SystemDrive\Yi\30\EasyBCD"" /i:""$env:SystemDrive\Yi\30\EasyBCD\EasyBCD.exe""" -WindowStyle Hidden }
	if (Test-Path "30\RegeditX" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\RegEditX.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\RegeditX\RegEditX.exe"" /w:""$env:SystemDrive\Yi\30\RegeditX"" /i:""$env:SystemDrive\Yi\30\RegeditX\RegEditX.exe""" -WindowStyle Hidden }
	if (Test-Path "30\RegShot" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\RegShot.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\RegShot\Regshot.bat"" /w:""$env:SystemDrive\Yi\30\RegShot"" /i:""$env:SystemDrive\Yi\30\RegShot\Regshot.exe"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\FastStoneCapture" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\FSCapture.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\FastStoneCapture\FSCapture.bat"" /w:""$env:SystemDrive\Yi\30\FastStoneCapture"" /i:""$env:SystemDrive\Yi\30\FastStoneCapture\FSCapture.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\HashTab" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\HashTab.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\HashTab\HashTab.bat"" /w:""$env:SystemDrive\Yi\30\HashTab"" /i:""$env:SystemDrive\Yi\30\HashTab\HashTab.ico""" -WindowStyle Hidden }
	if (Test-Path "30\3389" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\$($lang.ICONFolder3389).lnk"" /a:c /t:""$env:SystemDrive\Yi\30\3389\3389.exe"" /w:""$env:SystemDrive\Yi\30\3389"" /i:""$env:SystemDrive\Yi\30\3389\3389.exe""" -WindowStyle Hidden }
	if (Test-Path "30\Hash" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\MD5.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\Hash\Hash.bat"" /w:""$env:SystemDrive\Yi\30\Hash"" /i:""$env:SystemDrive\Yi\30\Hash\Hash.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\Beyond Compare" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Beyond Compare.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\Beyond Compare\BCompare.bat"" /w:""$env:SystemDrive\Yi\30\Beyond Compare"" /i:""$env:SystemDrive\Yi\30\Beyond Compare\BComparePortable.exe"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\PingPlotter" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\PingPlotter.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\PingPlotter\PingPlotter.exe"" /w:""$env:SystemDrive\Yi\30\PingPlotter"" /i:""$env:SystemDrive\Yi\30\PingPlotter\PingPlotter.exe""" -WindowStyle Hidden }
	if (Test-Path "30\WipeFile" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\WipeFile.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\WipeFile\WipeFile.exe"" /w:""$env:SystemDrive\Yi\30\WipeFile"" /i:""$env:SystemDrive\Yi\30\WipeFile\WipeFile.exe""" -WindowStyle Hidden }
	if (Test-Path "30\Everything" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\Everything.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\Everything\Everything.exe"" /w:""$env:SystemDrive\Yi\30\Everything"" /i:""$env:SystemDrive\Yi\30\Everything\Everything.exe""" -WindowStyle Hidden }
	if (Test-Path "30\SDCardFormatter" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\SD Card Formatter.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\SDCardFormatter\SDCardFormatter.bat"" /w:""$env:SystemDrive\Yi\30\SDCardFormatter"" /i:""$env:SystemDrive\Yi\30\SDCardFormatter\SDCardFormatter.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "30\TopMost" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\30\TopMost.lnk"" /a:c /t:""$env:SystemDrive\Yi\30\TopMost\TopMost.exe"" /w:""$env:SystemDrive\Yi\30\TopMost"" /i:""$env:SystemDrive\Yi\30\TopMost\TopMost.exe""" -WindowStyle Hidden }

	#40
	if (Test-Path "40\AIDA64" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\AIDA64.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\AIDA64\aida64.bat"" /w:""$env:SystemDrive\Yi\40\AIDA64"" /i:""$env:SystemDrive\Yi\40\AIDA64\aida64.exe"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "40\ASSSDBenchmark" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\AS SSD Benchmark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\ASSSDBenchmark\ASSSDBenchmark.bat"" /w:""$env:SystemDrive\Yi\40\ASSSDBenchmark"" /i:""$env:SystemDrive\Yi\40\ASSSDBenchmark\ASSSDBenchmark.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "40\CPU-Z" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\CPU-Z.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\CPU-Z\cpu-z.bat"" /w:""$env:SystemDrive\Yi\40\CPU-Z"" /i:""$env:SystemDrive\Yi\40\CPU-Z\cpu-z.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "40\FurMark" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\FurMark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\FurMark\FurMark.exe"" /w:""$env:SystemDrive\Yi\40\FurMark"" /i:""$env:SystemDrive\Yi\40\FurMark\FurMark.exe""" -WindowStyle Hidden }
	if (Test-Path "40\GPUShark" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\GPUShark.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\GPUShark\GPUShark.exe"" /w:""$env:SystemDrive\Yi\40\GPUShark"" /i:""$env:SystemDrive\Yi\40\GPUShark\GPUShark.exe""" -WindowStyle Hidden }
	if (Test-Path "40\GPU-Z" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\GPU-Z.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\GPU-Z\GPU-Z.bat"" /w:""$env:SystemDrive\Yi\40\GPU-Z"" /i:""$env:SystemDrive\Yi\40\GPU-Z\GPU-Z.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "40\HDDScan" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\HDDScan.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDDScan\HDDScan.exe"" /w:""$env:SystemDrive\Yi\40\HDDScan"" /i:""$env:SystemDrive\Yi\40\HDDScan\HDDScan.exe""" -WindowStyle Hidden }
	if (Test-Path "40\Hard Disk Sentinel" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\HDSentinel.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\Hard Disk Sentinel\HDSentinel.exe"" /w:""$env:SystemDrive\Yi\40\Hard Disk Sentinel"" /i:""$env:SystemDrive\Yi\40\Hard Disk Sentinel\HDSentinel.exe""" -WindowStyle Hidden }
	if (Test-Path "40\HDSpeed" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\HDSpeed.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDSpeed\HDSpeed.bat"" /w:""$env:SystemDrive\Yi\40\HDSpeed"" /i:""$env:SystemDrive\Yi\40\HDSpeed\HDSpeed.ico"" /R:7""" -WindowStyle Hidden }
	if (Test-Path "40\MaxxMEM2" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\MaxxMEM2.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MaxxMEM2\MaxxMEM2.exe"" /w:""$env:SystemDrive\Yi\40\MaxxMEM2"" /i:""$env:SystemDrive\Yi\40\MaxxMEM2\MaxxMEM2.exe""" -WindowStyle Hidden }
	if (Test-Path "40\TxBENCH" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\TxBENCH.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\TxBENCH\TxBENCH.exe"" /w:""$env:SystemDrive\Yi\40\TxBENCH"" /i:""$env:SystemDrive\Yi\40\TxBENCH\TxBENCH.exe""" -WindowStyle Hidden }
	if (Test-Path "40\Victoria" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\Victoria.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\Victoria\Victoria.bat"" /w:""$env:SystemDrive\Yi\40\Victoria"" /i:""$env:SystemDrive\Yi\40\Victoria\Victoria.exe"" /R:7""" -WindowStyle Hidden }
	if (Test-Path -path "40\MemTest\MemTest64.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\MemTest64.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\MemTest64.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\MemTest64.exe""" -WindowStyle Hidden }
	if (Test-Path -path "40\MemTest\MTPclassic.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\memTestPro Classic.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\MTPclassic.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\MTPclassic.exe""" -WindowStyle Hidden }
	if (Test-Path -path "40\MemTest\memTestPro.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\memTestPro.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\MemTest\memTestPro.exe"" /w:""$env:SystemDrive\Yi\40\MemTest"" /i:""$env:SystemDrive\Yi\40\MemTest\memTestPro.exe""" -WindowStyle Hidden }
	if (Test-Path -path "40\HDTune\HDTune.exe") {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\HDTune.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDTune\HDTune.exe"" /w:""$env:SystemDrive\Yi\40\HDTune"" /i:""$env:SystemDrive\Yi\40\HDTune\HDTune.exe""" -WindowStyle Hidden
	} else {
		if (Test-Path -path "40\HDTune\HDTuneProPortable.exe") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\40\HDTune.lnk"" /a:c /t:""$env:SystemDrive\Yi\40\HDTune\HDTuneProPortable.exe"" /w:""$env:SystemDrive\Yi\40\HDTune"" /i:""$env:SystemDrive\Yi\40\HDTune\HDTuneProPortable.exe""" -WindowStyle Hidden }
	}

	# 50
	if (Test-Path "50\AutoRuns" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\AutoRuns.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\AutoRuns\AutoRuns.exe"" /w:""$env:SystemDrive\Yi\50\AutoRuns"" /i:""$env:SystemDrive\Yi\50\AutoRuns\AutoRuns.exe""" -WindowStyle Hidden }
	if (Test-Path "50\DbgView" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\DbgView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\DbgView\Dbgview.exe"" /w:""$env:SystemDrive\Yi\50\DbgView"" /i:""$env:SystemDrive\Yi\50\DbgView\Dbgview.exe""" -WindowStyle Hidden }
	if (Test-Path "50\DriverView" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\DriverView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\DriverView\DriverView.exe"" /w:""$env:SystemDrive\Yi\50\DriverView"" /i:""$env:SystemDrive\Yi\50\DriverView\DriverView.exe""" -WindowStyle Hidden }
	if (Test-Path "50\FullEventLogView" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\FullEventLogView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\FullEventLogView\FullEventLogView.exe"" /w:""$env:SystemDrive\Yi\50\FullEventLogView"" /i:""$env:SystemDrive\Yi\50\FullEventLogView\FullEventLogView.exe""" -WindowStyle Hidden }
	if (Test-Path "50\ProcessExplorer" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\Process Explorer.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\ProcessExplorer\ProcessExplorer.exe"" /w:""$env:SystemDrive\Yi\50\ProcessExplorer"" /i:""$env:SystemDrive\Yi\50\ProcessExplorer\ProcessExplorer.exe""" -WindowStyle Hidden }
	if (Test-Path "50\ProcessMonitor" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\Process Monitor.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\ProcessMonitor\Procmon.exe"" /w:""$env:SystemDrive\Yi\50\ProcessMonitor"" /i:""$env:SystemDrive\Yi\50\ProcessMonitor\Procmon.exe""" -WindowStyle Hidden }
	if (Test-Path "50\PUTTY" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\PUTTY.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\PUTTY\putty.exe"" /w:""$env:SystemDrive\Yi\50\PUTTY"" /i:""$env:SystemDrive\Yi\50\PUTTY\putty.exe""" -WindowStyle Hidden }
	if (Test-Path "50\TCPView" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\50\TCPView.lnk"" /a:c /t:""$env:SystemDrive\Yi\50\TCPView\Tcpview.exe"" /w:""$env:SystemDrive\Yi\50\TCPView"" /i:""$env:SystemDrive\Yi\50\TCPView\Tcpview.exe""" -WindowStyle Hidden }

	# 60
	CheckCatalog -chkpath "$StartMenu\$($lang.ICONFolder60)"
	if (Test-Path "60\DefenderControl" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\- $($lang.ICONFolderDefenderControl) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.bat"" /w:""$env:SystemDrive\Yi\60\DefenderControl"" /i:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.exe"" /R:7""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder60)\$($lang.ICONFolderDefenderControl).lnk"" /a:c /t:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.bat"" /w:""$env:SystemDrive\Yi\60\DefenderControl"" /i:""$env:SystemDrive\Yi\60\DefenderControl\DefenderControl.exe"" /R:7""" -WindowStyle Hidden
	}
	if (Test-Path "60\WindowsUpdateBlocker" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\- $($lang.ICONFolderWub) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\60\WindowsUpdateBlocker\Wub.bat"" /w:""$env:SystemDrive\Yi\60\WindowsUpdateBlocker"" /i:""$env:SystemDrive\Yi\60\WindowsUpdateBlocker\Wub.exe"" /R:7""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder60)\$($lang.ICONFolderWub).lnk"" /a:c /t:""$env:SystemDrive\Yi\60\WindowsUpdateBlocker\Wub.bat"" /w:""$env:SystemDrive\Yi\60\WindowsUpdateBlocker"" /i:""$env:SystemDrive\Yi\60\WindowsUpdateBlocker\Wub.exe"" /R:7""" -WindowStyle Hidden
	}
	if (Test-Path "60\fab" -PathType Container) {
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\- $($lang.ICONFolderfab) -.lnk"" /a:c /t:""$env:SystemDrive\Yi\60\fab\Fab.bat"" /w:""$env:SystemDrive\Yi\60\fab"" /i:""$env:SystemDrive\Yi\60\fab\Fab.exe"" /R:7""" -WindowStyle Hidden
		Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$StartMenu\$($lang.ICONFolder60)\$($lang.ICONFolderfab).lnk"" /a:c /t:""$env:SystemDrive\Yi\60\fab\Fab.bat"" /w:""$env:SystemDrive\Yi\60\fab"" /i:""$env:SystemDrive\Yi\60\fab\Fab.exe"" /R:7""" -WindowStyle Hidden
	}

	if (Test-Path -Path "Yi\zh-CN\60\D.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\启用或禁用 F8 功能.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\D.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\E.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\系统还原与 OEM 分区管理.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\E.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\F.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\启用或禁用打印机服务.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\F.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\G.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\启用 3389 远程桌面功能.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\G.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\H.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\设置密码和自动登录.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\H.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\I.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\打开 SMB 文件共享.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\I.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\J.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\禁止安全模式和最后一次正确配置.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\J.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\K.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\清理发送到.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\K.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\L.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\清理系统日志.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\L.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\M.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\清理显卡多余右键.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\M.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\N.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\删除隐藏设备.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\N.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\O.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\WinSxS 瘦身.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\O.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\P.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\选择高级启动菜单.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\P.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\Q.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\PowerShell 执行策略为不受限制.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\Q.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\R.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\IE代理无法设置恢复补丁.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\R.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\S.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\设置默认搜索为百度.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\S.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }
	if (Test-Path -Path "Yi\zh-CN\60\T.bat") { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\60\卸载 Edge 浏览器.lnk"" /a:c /t:""$env:SystemDrive\Yi\Yi\zh-CN\60\T.bat"" /i:""$env:SystemDrive\Yi\Yi\icons\run.ico""" -WindowStyle Hidden }

	# 70
	if (Test-Path "70\AnyDesk" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\AnyDesk.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\AnyDesk\AnyDesk.exe"" /w:""$env:SystemDrive\Yi\70\AnyDesk"" /i:""$env:SystemDrive\Yi\70\AnyDesk\AnyDesk.exe" -WindowStyle Hidden }
	if (Test-Path "70\Radmin" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\Radmin.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\Radmin\Radmin.exe"" /w:""$env:SystemDrive\Yi\70\Radmin"" /i:""$env:SystemDrive\Yi\70\Radmin\Radmin.exe""" -WindowStyle Hidden }
	if (Test-Path "70\TeamViewer" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\TeamViewer.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TeamViewer\TeamViewer.exe"" /w:""$env:SystemDrive\Yi\70\TeamViewer"" /i:""$env:SystemDrive\Yi\70\TeamViewer\TeamViewer.exe""" -WindowStyle Hidden }
	if (Test-Path "70\TTVnc" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\TTC.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TTVnc\TTClient.exe"" /w:""$env:SystemDrive\Yi\70\TTVnc"" /i:""$env:SystemDrive\Yi\70\TTVnc\TTClient.exe""" -WindowStyle Hidden }
	if (Test-Path "70\TTVnc" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\TTS.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\TTVnc\TTServer.exe"" /w:""$env:SystemDrive\Yi\70\TTVnc"" /i:""$env:SystemDrive\Yi\70\TTVnc\TTServer.exe""" -WindowStyle Hidden }
	if (Test-Path "70\VNCView" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\VNC Viewer.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\VNCView\VNCView.exe"" /w:""$env:SystemDrive\Yi\70\VNCView"" /i:""$env:SystemDrive\Yi\70\VNCView\VNCView.exe""" -WindowStyle Hidden }
	if (Test-Path "70\WinBox" -PathType Container) { Start-Process -FilePath "Yi\AIO\Shortcut.exe" -ArgumentList "/f:""$env:SystemDrive\Yi\70\WinBox.lnk"" /a:c /t:""$env:SystemDrive\Yi\70\WinBox\winbox.exe"" /w:""$env:SystemDrive\Yi\70\WinBox"" /i:""$env:SystemDrive\Yi\70\WinBox\winbox.exe""" -WindowStyle Hidden }

	do {
		Start-Sleep -Seconds 1
	} while (Get-Process -Name 'Shortcut' -ErrorAction SilentlyContinue)
	Copy-Item -Path "30\*.lnk" -Destination "$StartMenu\$($lang.ICONFolder30)"
	Copy-Item -Path "40\*.lnk" -Destination "$StartMenu\$($lang.ICONFolder40)"
	Copy-Item -Path "50\*.lnk" -Destination "$StartMenu\$($lang.ICONFolder50)"
	Copy-Item -Path "70\*.lnk" -Destination "$StartMenu\$($lang.ICONFolder70)"
}

# Right-click menu module
function RightClickMenu {
	Write-Host "`n   正在删除 '桌面右键菜单'"
	Remove-Item -Path "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.ControlCenter" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue | Out-Null

	Write-Host "`n   正在添加 '桌面右键菜单'"
	New-Item "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'MUIVerb' -Value "&Yi's Solution" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\Yi.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'SeparatorAfter' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Position' -Value 'Top' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.ControlCenter" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.ControlCenter\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.ControlCenter' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\ControlCenter.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.ControlCenter' -Name 'MUIVerb' -Value $($lang.Mainpage) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.ControlCenter\command' -Name '(default)' -Value "powershell.exe -file ""$($env:SystemDrive)\Yi\Yi\Yi.ps1""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\Yi.Gift.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir' -Name 'MUIVerb' -Value $($lang.MainFolder) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Dir\command' -Name '(default)' -Value "explorer $($env:SystemDrive)\Yi" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language\command" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\refresh.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language' -Name 'MUIVerb' -Value $($lang.RefreshLang) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Language\command' -Name '(default)' -Value "powershell.exe -file ""$($env:SystemDrive)\Yi\Yi\Yi.ps1"" -Page ""Refresh""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\reset.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg' -Name 'MUIVerb' -Value $($lang.ResetSolution) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Reg\command' -Name '(default)' -Value "powershell.exe -file ""$($env:SystemDrive)\Yi\Yi\Yi.ps1"" -Page ""Yi""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\update.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update' -Name 'MUIVerb' -Value $($lang.Update) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.Update\command' -Name '(default)' -Value "powershell.exe -file ""$($env:SystemDrive)\Yi\Yi\Yi.ps1"" -page ""Update""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\about.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About' -Name 'MUIVerb' -Value $($lang.About) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Yi.About\command' -Name '(default)' -Value "explorer ""https://fengyi.tel/go/os""" -PropertyType String -Force -ea SilentlyContinue | Out-Null

	New-Item "HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'MUIVerb' -Value "&Yi's Solution" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Icon' -Value "$($env:SystemDrive)\\Yi\\Yi\\icons\\Yi.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'SeparatorAfter' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'Position' -Value 'Top' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\Background\shell\Yi' -Name 'SubCommands' -Value 'Yi.ControlCenter;Yi.Dir;|;Yi.Update;Yi.Language;Yi.Reg;|;Yi.About;' -PropertyType String -Force -ea SilentlyContinue | Out-Null
}
# Right-click menu module End

<#
	.Install font module
#>
# Please set the directory to search
$DirectoryStructure = @(
	"Yi\Fonts"
	"Fonts"
)

# Please set the search file type
$type = @(
	"*.otf"
	"*.ttf"
)

function InstallFonts {
	param (
		[string]$fontFile,
		[string]$shortname
	)
	$Host.UI.RawUI.WindowTitle = "Yi's Solution | 安装字体"

	if ((Test-Path "$env:SystemDrive\Windows\fonts\$shortname") -or 
		(Test-Path "$env:LOCALAPPDATA\Microsoft\Windows\Fonts\$shortname")) {
		Write-Host "   '已安装' - $($fontFile)" -ForegroundColor Red
	} else {
		Write-Host "   '安装中' - $($fontFile)" -ForegroundColor Green

		(New-Object -ComObject Shell.Application).Namespace(0x14).CopyHere($_.FullName) | Out-Null
		Write-Host "    - 完成.`n" -ForegroundColor Green
	}
}

function InstallFontsStart {
	Write-host "`n   正在安装字体`n   ---------------------------------------------------"

	$drives = Get-PSDrive | Select-Object -ExpandProperty 'Name' | Select-String -Pattern '^[a-z]$'
	foreach ($drive in $drives){
		foreach ($nsf in $DirectoryStructure) {
			Get-ChildItem "${drive}:\${nsf}" -Recurse -Include ($type) -ErrorAction SilentlyContinue | Foreach-Object {
				InstallFonts -fontFile $_.FullName -shortname $_.Name
			}
		}
	}
}
# Install font module End

<#
	.Language keyboard setting module
#>
function LanguageSetting {
	switch ((Get-Culture).Name) {
		'en-US' {
			Write-Host "`n   正在设置语言：en-US`n   键盘顺序：英语（默认），拼音，五笔"
			$langlist = New-WinUserLanguageList en-US
			$langlist[0].InputMethodTips.Clear()
			$langlist[0].InputMethodTips.add('0409:00000409')
			$langlist[0].InputMethodTips.add('0804:{81D4E9C9-1D3B-41BC-9E6C-4B40BF79E35E}{FA550B04-5AD7-411f-A5AC-CA038EC515D7}')
			$langlist[0].InputMethodTips.add('0804:{6a498709-e00b-4c45-a018-8f9e4081ae40}{82590C13-F4DD-44f4-BA1D-8667246FDF8E}')
			Set-WinUserLanguageList $langlist -Force
			Set-WinDefaultInputMethodOverride -InputTip "0409:00000409"
			Set-WinSystemLocale zh-CN
			Set-TimeZone -Id "China Standard Time" -PassThru | Out-Null
		}
		'zh-CN' {
			Write-Host "`n   正在设置语言：zh-CN`n   键盘顺序：拼音，五笔，英语（默认）"
			$langlist = New-WinUserLanguageList zh-CN
			$langlist[0].InputMethodTips.Clear()
			$langlist[0].InputMethodTips.add('0804:{81D4E9C9-1D3B-41BC-9E6C-4B40BF79E35E}{FA550B04-5AD7-411f-A5AC-CA038EC515D7}')
			$langlist[0].InputMethodTips.add('0804:{6a498709-e00b-4c45-a018-8f9e4081ae40}{82590C13-F4DD-44f4-BA1D-8667246FDF8E}')
			$langlist[0].InputMethodTips.add('0409:00000409')
			Set-WinUserLanguageList $langlist -Force
			Set-WinDefaultInputMethodOverride -InputTip "0409:00000409"
			Set-WinSystemLocale zh-CN
			Set-TimeZone -Id "China Standard Time" -PassThru | Out-Null
		}
	}
}
# Language keyboard setting module End

# Synchronization task
function ScheduledTaskSettings {
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue
	Unregister-ScheduledTask -TaskName "\Yi\isDark" -Confirm:$False -ErrorAction SilentlyContinue
	
	$action = New-ScheduledTaskAction -Execute "$($env:systemdrive)\Yi\Yi\AIO\hstart.exe" -Argument "/NOCONSOLE /SILENT ""powershell.exe -file $($env:systemdrive)\Yi\Yi\theme.ps1"""
	$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1)
	Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "\Yi\isDark" -Description "Yi" -Force -ErrorAction SilentlyContinue | Out-Null
	Start-ScheduledTask -TaskName "\Yi\isDark" | Out-Null
}

<#
	.Update module
#>
$ServerList = @(
	('https://fengyi.tel',
	 '/download/bs/v6/latest.xml'),
	('https://github.com',
	 '/ilikeyi/bsUpdate/raw/main/v6/latest.xml'),
	('https://gitee.com',
	 '/ilikeyi/BsUpdate/raw/master/v6/latest.xml')
)

function CheckCatalog
{
	Param (
		[string]$chkpath
	)
	
	if (!(Test-Path $chkpath -PathType Container))
	{
		New-Item -Path $chkpath -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
		if (!(Test-Path $chkpath -PathType Container))
		{
			Write-Host "   - 创建目录失败：$($chkpath)`n" -ForegroundColor Red
			return
		}
	}
}

function RemoveTree {
	Param (
		[string]$Path
	)

	Remove-Item $Path -force -Recurse -ErrorAction silentlycontinue | Out-Null
	
	if (Test-Path "$Path\" -ErrorAction silentlycontinue) {
		$folders = Get-ChildItem -Path $Path -Directory -Force -ErrorAction SilentlyContinue
		ForEach ($folder in $folders) {
			RemoveTree $folder.FullName
		}
		
		$files = Get-ChildItem -Path $Path -File -Force -ErrorAction SilentlyContinue
		
		ForEach ($file in $files) {
			Remove-Item $file.FullName -force -ErrorAction SilentlyContinue
		}
		
		if (Test-Path "$Path\" -ErrorAction silentlycontinue) {
			Remove-Item $Path -force -ErrorAction SilentlyContinue
		}
	}
}

function TestURI {
	Param(
		[Parameter(Position=0,Mandatory,HelpMessage="HTTP or HTTPS")]
		[ValidatePattern( "^(http|https)://" )]
		[Alias("url")]
		[string]$URI,
		[Parameter(ParameterSetName="Detail")]
		[Switch]$Detail,
		[ValidateScript({$_ -ge 0})]
		[int]$Timeout = 30
	)
	Process {
		Try {
			$paramHash = @{
				UseBasicParsing = $True
				DisableKeepAlive = $True
				Uri = $uri
				Method = 'Head'
				ErrorAction = 'stop'
				TimeoutSec = $Timeout
			}
			$test = Invoke-WebRequest @paramHash
			if ($Detail) {
				$test.BaseResponse | Select ResponseURI,ContentLength,ContentType,LastModified, @{Name="Status";Expression={$Test.StatusCode}}
			} else {
				if ($test.statuscode -ne 200) { $False } else { $True }
			}
		} Catch {
			write-verbose -message $_.exception
			if ($Detail) {
				$objProp = [ordered]@{
					ResponseURI = $uri
					ContentLength = $null
					ContentType = $null
					LastModified = $null
					Status = 404
				}
				New-Object -TypeName psobject -Property $objProp
			} else { $False }
		}
	}
}

function Archive {
	param(
		$filename,
		$to
	)

	if (Compressing) {
		$arguments = "x ""-r"" ""-tzip"" ""$filename"" ""-o$to"" ""-y""";
		Start-Process $global:Zip "$arguments" -Wait -WindowStyle Minimized
	} else {
		Expand-Archive -LiteralPath $filename -DestinationPath $to -force
	}
}

function Compressing {
	if (Test-Path "$env:ProgramFiles\7-Zip\7z.exe") {
		$global:Zip = "$env:ProgramFiles\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:ProgramFiles(x86)\7-Zip\7z.exe") {
		$global:Zip = "$env:ProgramFiles(x86)\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path "$env:SystemDrive\Yi\Yi\AIO\7z.exe") {
		$global:Zip = "$env:SystemDrive\Yi\Yi\AIO\7z.exe"
		return $true
	}
	return $false
}

function Update {
	param(
		[switch]$Force,
		[switch]$IsProcess
	)
	$Host.UI.RawUI.WindowTitle = "Yi's Solution | $($lang.Update)"

	if (!$Force) {
		Clear-Host
		Write-host "`n   Author: Yi ( https://fengyi.tel )`n`n   From: Yi's Solution`n   buildstring: 6.0.0.0.bs_release.210120-1208"
	}

	$locver = "$PSScriptRoot\version.xml"
	$ServerTest = $false
	if ((Test-Path $locver)) {
		[xml]$curver = Get-content $locver
		write-host "`n   ver: $($curver.versioninfo.version.version)`n"
	} else {
		Write-Host "`n   $($lang.UpdateNoLocalVersion)`n"

		If ($Force) {
			return
		} else {
			ToMainpage -wait 6
		}
	}
	
	Write-Host "   $($lang.UpdateCheckServerStatus -f $($ServerList.Count))
   ---------------------------------------------------"

foreach ($list in $ServerList | Sort-Object { Get-Random } ) {
	$fullurl = $list[0] + $list[1]

	Write-Host "   * $($lang.UpdateServerAddress -f $($list[0]))"

	if(TestURI $fullurl){
		$versionxmlloc = $fullurl
		$ServerTest = $true
		Write-Host "     - $($lang.UpdateServeravailable)" -ForegroundColor Green
		break
	} else {
		Write-Host "     - $($lang.UpdateServerUnavailable)`n" -ForegroundColor Red
	}
}

	if ($ServerTest) {
		Write-Host "   ---------------------------------------------------"
		Write-Host "     - $($lang.UpdatePriority)" -ForegroundColor Green
	} else {
		Write-Host "     - $($lang.UpdateServerTestFailed)" -ForegroundColor Red
		Write-Host "   ---------------------------------------------------"

		If ($Force) {
			return
		} else {
			ToMainpage -wait 6
		}
	}

	Write-host "`n   $($lang.UpdateQueryingUpdate)"

	# Check if remote version xml is available to the client
	$error.Clear()
	$time = Measure-Command { $request = Invoke-WebRequest -Uri $versionxmlloc } 2>$null

	if ($error.Count -eq 0) {
		Write-Host "`n   $($lang.UpdateQueryingTime -f $($time.TotalMilliseconds))"

	} else {
		Write-host "`n   $($lang.UpdateConnectFailed)"

		If ($Force) {
			return
		} else {
			ToMainpage -wait 6
		}
	}

	$getSerVer = try {
		(Invoke-WebRequest -Uri $versionxmlloc -Body $body -Method:Get -Headers $head -ContentType "application/xml" -TimeoutSec 15 -ErrorAction:stop)
	} catch {
		break
	}
	$IsCorrectAuVer = $false
	$chkLocalver = $($curver.versioninfo.version.minau)
	$chkRemovever = ([xml]$getSerVer.Content).versioninfo.version.minau
	$PPocess = "$PSScriptRoot\Post.Processing.bat"
	$PsPocess = "$PSScriptRoot\Post.Processing.ps1"

	If([String]::IsNullOrEmpty($chkRemovever)){
		$IsCorrectAuVer = $false
	} else {
		if ($chkRemovever -ge $chkLocalver) {
			$IsCorrectAuVer = $true
		} else {
			$IsCorrectAuVer = $false
		}
	}

	if ($IsCorrectAuVer) {
		Write-Host "`n   $($lang.UpdateMinimumVersion -f $($curver.versioninfo.version.minau))"
		$IsUpdateAvailable = $false
		$url = ([xml]$getSerVer.Content).versioninfo.download.url
		$output = "$PSScriptRoot\latest.zip"

		if (([xml]$getSerVer.Content).versioninfo.version.version -gt $($curver.versioninfo.version.version)) {
			$IsUpdateAvailable = $true
		} else {
			$IsUpdateAvailable = $false
		}

		if ($IsUpdateAvailable) {
			Write-host "`n   $($lang.UpdateVerifyAvailable)
   ---------------------------------------------------"

			Write-Host "   * $($lang.UpdateDownloadAddress)$($url)"
			if(TestURI $url){
				Write-Host "     - $($lang.UpdateAvailable)" -ForegroundColor Green
				Write-Host "   ---------------------------------------------------"
			} else {
				Write-Host "     - $($lang.UpdateUnavailable)" -ForegroundColor Red
				Write-Host "   ---------------------------------------------------"
				If ($Force) {
					return
				} else {
					ToMainpage -wait 6
				}
			}

			Write-host "`n   $($lang.UpdateCurrent)$($curver.versioninfo.version.version) - $($curver.versioninfo.version.buildstring)
   $($lang.UpdateLatest)$(([xml]$getSerVer.Content).versioninfo.version.version) - $(([xml]$getSerVer.Content).versioninfo.version.buildstring)
   
   $(([xml]$getSerVer.Content).versioninfo.changelog.title)
   $('-' * (([xml]$getSerVer.Content).versioninfo.changelog.title).Length)
$(([xml]$getSerVer.Content).versioninfo.changelog.'#text')"

			Write-host "   $($lang.UpdateNewLatest)`n" -ForegroundColor Green
			If ($Force) {
				$title = "   $($lang.UpdateForce)"
				$start_time = Get-Date
				remove-item -path $output -force -ErrorAction SilentlyContinue
				Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
				Write-Output "`n   $($lang.UpdateTimeUsed)$((Get-Date).Subtract($start_time).Seconds) (s)"
			} else {
				$title = "$($lang.UpdateInstall)"
				$message = "$($lang.UpdateInstallSel)"
				$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Yes"
				$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "No"
				$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
				$prompt=$host.ui.PromptForChoice($title, $message, $options, 0)
				Switch ($prompt)
				{
					0 {
						$start_time = Get-Date
						remove-item -path $output -force -ErrorAction SilentlyContinue
						Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction SilentlyContinue
						Write-Output "`n   $($lang.UpdateTimeUsed)$((Get-Date).Subtract($start_time).Seconds) (s)"
					}
					1 {
						Write-Host "`n   $($lang.UpdateUserCancel)"
						ToMainpage -wait 2
					}
				}
			}

			if ((Test-Path $output -PathType Leaf)) {
				Write-Output "`n   $($lang.UpdateUnpacking)$output"
				Archive -filename $output -to "$PSScriptRoot\..\"
				Write-Host "`n   * $($lang.UpdatePostProc)"
				if ($IsProcess) {
					Write-Host "     - $($lang.UpdateNotExecuted)" -ForegroundColor red
				} else {
					if ((Test-Path $PPocess -PathType Leaf)) {
						Start-Process -FilePath $PPocess -wait -WindowStyle Minimized
						remove-item -path $PPocess -force
						Write-Host "     - $($lang.UpdateComplete)" -ForegroundColor Green
					} else {
						Write-Host "     - $($lang.UpdateNoPost)" -ForegroundColor red
					}
					if ((Test-Path $PsPocess -PathType Leaf)) {
						Start-Process powershell -ArgumentList "-file $($PsPocess)" -Wait -WindowStyle Minimized
						remove-item -path $PsPocess -force
						Write-Host "     - $($lang.UpdateComplete)" -ForegroundColor Green
					} else {
						Write-Host "     - $($lang.UpdateNoPost)" -ForegroundColor red
					}
					PostProcessing
					Write-host "`n   Yi's Solution $($lang.UpdateDone)`n"
				}
			} else {
				Write-host "`n   $($lang.UpdateUpdateStop)"
			}
			remove-item -path $output -force -ErrorAction SilentlyContinue
		} else {
			Write-host "$($lang.UpdateNoUpdateAvailable)"
		}
	} else {
		Write-host "$($lang.UpdateNotSatisfied -f $($curver.versioninfo.version.minau))"
	}

	If ($Force) {
		return
	} else {
		ToMainpage -wait 6
	}
}

function PostProcessing {
	RefreshLanguage

	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Yi" -Name isDark -Force -ErrorAction SilentlyContinue

	RefreshStart
	HideDirectory
}
# Update End






